"""
Cave Keeper v2 - a Core Keeper style game in Pygame (2.x).
No external assets needed. Everything is drawn with pygame.draw.

Controls
  WASD / Arrows : move
  LEFT mouse    : hold on a wall to mine it, click a ripe crop to harvest
  RIGHT mouse   : use the selected hotbar item at the mouse tile
  1-4 / wheel   : select hotbar item (1 Torch, 2 Hoe, 3 Seeds, 4 Workbench)
  SPACE         : sword swing
  E             : open / close crafting menu (press 1-9 or click to craft)
  I / Bag button: open / close the bag to view all stored items
  G             : eat (bread first, then wheat)
  F5 / F9       : save / load      F10: new world
  R             : after dying, continue from last save (or new world)
  ESC           : close menu / quit (the game autosaves on quit)

Goal: mine ores in three biomes, upgrade your gear at a workbench, farm food,
and hunt down the Gloop King in the Ember Depths (follow the compass).
"""
import json
import math
import os
import random
import sys

import pygame

# ---------------------------------------------------------------- settings
W, H = 960, 640
FPS = 60
TILE = 32
MAP_W, MAP_H = 140, 140
REACH = 3.5 * TILE
PLAYER_SPEED = 170
BASE_HP = 100
LIGHT_PLAYER = 220
LIGHT_TORCH = 150
DARKNESS = 242
GROW_TIME = 40.0               # seconds for wheat to ripen
SAVE_NAME = "cave_keeper_save.json"

# tile ids (all single digits so the map saves as compact strings)
FLOOR, STONE, COPPER, ROOT, BORDER, IRON, GOLD, BENCH, SOIL = range(9)
WALKABLE = (FLOOR, SOIL)
HARDNESS = {STONE: 0.9, COPPER: 1.6, IRON: 2.2, GOLD: 3.0, ROOT: 0.6, BENCH: 0.5}
NEED_PICK = {COPPER: 1, IRON: 2, GOLD: 3}

# biomes
CAVE, FROST, EMBER = 0, 1, 2
BIOME_NAMES = ["Dust Caves", "Frost Hollows", "Ember Depths"]
FLOOR_COL = {CAVE: (74, 58, 44), FROST: (70, 84, 104), EMBER: (88, 44, 40)}
WALL_COL = {CAVE: (96, 96, 104), FROST: (150, 185, 205), EMBER: (86, 60, 66)}
SPECK_COL = {CAVE: (64, 50, 38), FROST: (88, 104, 126), EMBER: (106, 56, 48)}

MOBS = {
    CAVE: dict(name="Slime", hp=30, speed=(60, 85), dmg=10, col=(70, 190, 90), drop="copper"),
    FROST: dict(name="Frost Slime", hp=45, speed=(70, 95), dmg=12, col=(120, 200, 240), drop="iron"),
    EMBER: dict(name="Magma Slime", hp=70, speed=(85, 115), dmg=16, col=(240, 110, 50), drop="gold"),
}

DEFAULT_INV = {"stone": 0, "copper": 0, "iron": 0, "gold": 0, "wood": 3,
               "seeds": 3, "wheat": 0, "bread": 0, "torch": 4, "hoe": 0}

# order and labels used by the bag (inventory) panel
ITEM_INFO = [("stone", "Stone"), ("copper", "Copper"), ("iron", "Iron"), ("gold", "Gold"),
             ("wood", "Wood"), ("seeds", "Seeds"), ("wheat", "Wheat"), ("bread", "Bread"),
             ("torch", "Torch"), ("hoe", "Hoe")]
ITEM_COL = {"stone": (130, 130, 140), "copper": (214, 132, 70), "iron": (230, 230, 240),
            "gold": (250, 208, 60), "wood": (140, 100, 60), "seeds": (180, 150, 90),
            "wheat": (210, 180, 70), "bread": (200, 140, 70), "torch": (255, 170, 40),
            "hoe": (200, 200, 210)}


# ---------------------------------------------------------------- recipes
def give(item, n):
    return lambda p: p.inv.__setitem__(item, p.inv.get(item, 0) + n)


def upgrade(attr, level):
    return lambda p: setattr(p, attr, level)


RECIPES = [
    dict(name="Torches x4", cost={"wood": 1, "stone": 1}, bench=False,
         show=lambda p: True, apply=give("torch", 4)),
    dict(name="Hoe", cost={"wood": 3, "stone": 2}, bench=False,
         show=lambda p: p.inv["hoe"] == 0, apply=give("hoe", 1)),
    dict(name="Bread", cost={"wheat": 3}, bench=True,
         show=lambda p: True, apply=give("bread", 1)),
    dict(name="Pickaxe Lv.2", cost={"copper": 8, "wood": 4}, bench=True,
         show=lambda p: p.pick_level == 1, apply=upgrade("pick_level", 2)),
    dict(name="Pickaxe Lv.3", cost={"iron": 8, "copper": 4}, bench=True,
         show=lambda p: p.pick_level == 2, apply=upgrade("pick_level", 3)),
    dict(name="Pickaxe Lv.4", cost={"gold": 8, "iron": 4}, bench=True,
         show=lambda p: p.pick_level == 3, apply=upgrade("pick_level", 4)),
    dict(name="Sword Lv.2", cost={"copper": 6, "wood": 2}, bench=True,
         show=lambda p: p.sword_level == 1, apply=upgrade("sword_level", 2)),
    dict(name="Sword Lv.3", cost={"iron": 6, "copper": 4}, bench=True,
         show=lambda p: p.sword_level == 2, apply=upgrade("sword_level", 3)),
    dict(name="Sword Lv.4", cost={"gold": 6, "iron": 4}, bench=True,
         show=lambda p: p.sword_level == 3, apply=upgrade("sword_level", 4)),
]


# ---------------------------------------------------------------- world gen
def generate_world(seed=None):
    rnd = random.Random(seed)
    cx, cy = MAP_W // 2, MAP_H // 2

    # biome seeds (Voronoi regions). Spawn region is a favoured cave.
    seeds = [(cx, cy, CAVE, 0.7)]
    plan = [(FROST, 28), (FROST, 28), (FROST, 28), (EMBER, 45), (EMBER, 45),
            (EMBER, 45), (CAVE, 25), (CAVE, 25)]
    for kind, min_d in plan:
        x = y = 0
        for _ in range(300):
            x, y = rnd.randint(14, MAP_W - 15), rnd.randint(14, MAP_H - 15)
            if math.hypot(x - cx, y - cy) > min_d:
                break
        seeds.append((x, y, kind, 1.0))
    biome = [[min(seeds, key=lambda s: math.hypot(x - s[0], y - s[1]) * s[3])[2]
              for x in range(MAP_W)] for y in range(MAP_H)]

    # caves through cellular automata
    grid = [[STONE if rnd.random() < 0.46 else FLOOR for _ in range(MAP_W)]
            for _ in range(MAP_H)]
    for _ in range(4):
        new = [row[:] for row in grid]
        for y in range(1, MAP_H - 1):
            for x in range(1, MAP_W - 1):
                walls = sum(grid[y + dy][x + dx] == STONE
                            for dy in (-1, 0, 1) for dx in (-1, 0, 1))
                new[y][x] = STONE if walls >= 5 else FLOOR
        grid = new

    # ores depend on biome
    for y in range(MAP_H):
        for x in range(MAP_W):
            if grid[y][x] != STONE:
                continue
            r, b = rnd.random(), biome[y][x]
            if b == CAVE:
                grid[y][x] = COPPER if r < 0.05 else ROOT if r < 0.09 else STONE
            elif b == FROST:
                grid[y][x] = (IRON if r < 0.06 else COPPER if r < 0.08
                              else ROOT if r < 0.10 else STONE)
            else:
                grid[y][x] = (GOLD if r < 0.06 else IRON if r < 0.09
                              else ROOT if r < 0.10 else STONE)

    for x in range(MAP_W):
        grid[0][x] = grid[MAP_H - 1][x] = BORDER
    for y in range(MAP_H):
        grid[y][0] = grid[y][MAP_W - 1] = BORDER

    def clear_circle(px, py, r):
        for y in range(py - r, py + r + 1):
            for x in range(px - r, px + r + 1):
                if 0 < x < MAP_W - 1 and 0 < y < MAP_H - 1 and (x - px) ** 2 + (y - py) ** 2 <= r * r:
                    grid[y][x] = FLOOR

    clear_circle(cx, cy, 4)                         # spawn room
    embers = [s for s in seeds if s[2] == EMBER]
    far = max(embers, key=lambda s: math.hypot(s[0] - cx, s[1] - cy))
    clear_circle(far[0], far[1], 7)                 # boss arena
    for y in range(far[1] - 7, far[1] + 8):
        for x in range(far[0] - 7, far[0] + 8):
            if (x - far[0]) ** 2 + (y - far[1]) ** 2 <= 49:
                biome[y][x] = EMBER
    start = (cx * TILE + TILE // 2, cy * TILE + TILE // 2)
    home = (far[0] * TILE + TILE // 2, far[1] * TILE + TILE // 2)
    return grid, biome, start, home


# ---------------------------------------------------------------- entities
class Player:
    def __init__(self, pos):
        self.pos = pygame.Vector2(pos)
        self.size = 22
        self.max_hp = BASE_HP
        self.hp = BASE_HP
        self.hunger = 100.0
        self.facing = pygame.Vector2(1, 0)
        self.inv = dict(DEFAULT_INV)
        self.pick_level = 1
        self.sword_level = 1
        self.hurt_cd = 0.0
        self.swing_cd = 0.0
        self.swing_anim = 0.0
        self.starve = 0.0
        self.regen = 0.0

    def rect(self):
        r = pygame.Rect(0, 0, self.size, self.size)
        r.center = self.pos
        return r


class Mob:
    def __init__(self, pos, kind, hp=None):
        self.pos = pygame.Vector2(pos)
        self.kind = kind
        self.stats = MOBS[kind]
        self.size = 22
        self.hp = hp if hp is not None else self.stats["hp"]
        self.speed = random.uniform(*self.stats["speed"])
        self.bob = random.random() * 6.28
        self.flash = 0.0

    def rect(self):
        r = pygame.Rect(0, 0, self.size, self.size)
        r.center = self.pos
        return r


class Boss:
    def __init__(self, home):
        self.home = pygame.Vector2(home)
        self.pos = pygame.Vector2(home)
        self.size = 52
        self.max_hp = 700
        self.hp = self.max_hp
        self.dead = False
        self.active = False
        self.flash = 0.0
        self.ring_t = 2.0
        self.aim_t = 1.5
        self.bob = 0.0

    def rect(self):
        r = pygame.Rect(0, 0, self.size, self.size)
        r.center = self.pos
        return r


class Shot:
    def __init__(self, pos, vel):
        self.pos = pygame.Vector2(pos)
        self.vel = pygame.Vector2(vel)
        self.life = 4.0


class Torch:
    def __init__(self, tx, ty):
        self.tx, self.ty = tx, ty


# ---------------------------------------------------------------- game
class Game:
    def __init__(self, save_path=None):
        pygame.init()
        icon = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cave_keeper_icon.png")
        if os.path.exists(icon):
            pygame.display.set_icon(pygame.image.load(icon))
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("Cave Keeper")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("consolas,menlo,monospace", 18)
        self.small = pygame.font.SysFont("consolas,menlo,monospace", 14)
        self.big = pygame.font.SysFont("consolas,menlo,monospace", 48, bold=True)
        self.light_cache = {}
        self.dark = pygame.Surface((W, H), pygame.SRCALPHA)
        here = os.path.dirname(os.path.abspath(__file__))
        self.save_path = save_path or os.path.join(here, SAVE_NAME)
        self.menu_rects = []
        self.inv_open = False
        if not self.load(quiet=True):
            self.reset()

    # ---- state
    def reset(self):
        self.grid, self.biome, start, home = generate_world()
        self.player = Player(start)
        self.boss = Boss(home)
        self.mobs, self.shots, self.torches = [], [], []
        self.crops = {}
        self.mining = None
        self.spawn_timer = 2.0
        self.kills = 0
        self.time = 0.0
        self.sel = 0
        self.menu_open = False
        self.inv_open = False
        self.msg, self.msg_t = "", 0.0
        self.dead = False
        self.say("New world. Mine roots for wood, press E to craft.")

    def say(self, text):
        self.msg, self.msg_t = text, 2.5

    # ---- save / load
    def save(self, quiet=False):
        if self.dead:
            return False
        p, b = self.player, self.boss
        data = dict(
            v=2,
            grid=["".join(map(str, r)) for r in self.grid],
            biome=["".join(map(str, r)) for r in self.biome],
            player=dict(pos=[p.pos.x, p.pos.y], hp=p.hp, max_hp=p.max_hp, hunger=p.hunger,
                        inv=p.inv, pick=p.pick_level, sword=p.sword_level),
            torches=[[t.tx, t.ty] for t in self.torches],
            crops=[[x, y, t] for (x, y), t in self.crops.items()],
            mobs=[[m.pos.x, m.pos.y, m.kind, m.hp] for m in self.mobs],
            boss=dict(home=[b.home.x, b.home.y], hp=b.hp, dead=b.dead),
            time=self.time, kills=self.kills, sel=self.sel,
        )
        try:
            tmp = self.save_path + ".tmp"
            with open(tmp, "w") as f:
                json.dump(data, f)
            os.replace(tmp, self.save_path)
        except OSError as exc:
            self.say(f"Save failed: {exc}")
            return False
        if not quiet:
            self.say("World saved")
        return True

    def load(self, quiet=False):
        if not os.path.exists(self.save_path):
            if not quiet:
                self.say("No save file found")
            return False
        try:
            with open(self.save_path) as f:
                d = json.load(f)
            if d.get("v") != 2:
                raise ValueError("unsupported save version")
            # parse everything into locals first so a damaged file can't
            # leave the game half-loaded
            grid = [[int(c) for c in row] for row in d["grid"]]
            biome = [[int(c) for c in row] for row in d["biome"]]
            for rows in (grid, biome):
                if len(rows) != MAP_H or any(len(r) != MAP_W for r in rows):
                    raise ValueError("wrong map size")
            pd = d["player"]
            player = Player(pd["pos"])
            player.hp, player.max_hp, player.hunger = pd["hp"], pd["max_hp"], pd["hunger"]
            player.inv = {**DEFAULT_INV, **pd["inv"]}
            player.pick_level, player.sword_level = pd["pick"], pd["sword"]
            torches = [Torch(x, y) for x, y in d["torches"]]
            crops = {(x, y): t for x, y, t in d["crops"]}
            mobs = [Mob((x, y), k, hp) for x, y, k, hp in d["mobs"]]
            bd = d["boss"]
            boss = Boss(bd["home"])
            boss.hp, boss.dead = bd["hp"], bd["dead"]
            time_, kills, sel = d["time"], d["kills"], d["sel"]
        except (OSError, ValueError, KeyError, TypeError, AttributeError):
            if not quiet:
                self.say("Save file is damaged")
            return False
        self.grid, self.biome, self.player = grid, biome, player
        self.torches, self.crops, self.mobs, self.boss = torches, crops, mobs, boss
        self.time, self.kills, self.sel = time_, kills, sel
        self.shots = []
        self.mining = None
        self.spawn_timer = 2.0
        self.menu_open = False
        self.inv_open = False
        self.dead = False
        self.msg, self.msg_t = "", 0.0
        if not quiet:
            self.say("World loaded")
        else:
            self.say("Save loaded. F10 starts a new world.")
        return True

    # ---- helpers
    def light_sprite(self, radius):
        if radius not in self.light_cache:
            s = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
            for r in range(radius, 0, -3):
                a = int(DARKNESS * (1 - (r / radius) ** 1.6))
                pygame.draw.circle(s, (a, a, a, a), (radius, radius), r)
            self.light_cache[radius] = s
        return self.light_cache[radius]

    def in_map(self, tx, ty):
        return 0 <= tx < MAP_W and 0 <= ty < MAP_H

    def solid(self, tx, ty):
        return not self.in_map(tx, ty) or self.grid[ty][tx] not in WALKABLE

    def move_entity(self, ent, delta):
        for axis in (0, 1):
            ent.pos[axis] += delta[axis]
            r = ent.rect()
            for ty in range(r.top // TILE, r.bottom // TILE + 1):
                for tx in range(r.left // TILE, r.right // TILE + 1):
                    if self.solid(tx, ty):
                        t = pygame.Rect(tx * TILE, ty * TILE, TILE, TILE)
                        if r.colliderect(t):
                            if delta[axis] > 0:
                                ent.pos[axis] = (t.left if axis == 0 else t.top) - ent.size / 2
                            elif delta[axis] < 0:
                                ent.pos[axis] = (t.right if axis == 0 else t.bottom) + ent.size / 2
                            r = ent.rect()

    def cam(self):
        return pygame.Vector2(self.player.pos.x - W / 2, self.player.pos.y - H / 2)

    def mouse_tile(self):
        mx, my = pygame.mouse.get_pos()
        c = self.cam()
        return int((mx + c.x) // TILE), int((my + c.y) // TILE)

    def tile_center(self, tx, ty):
        return pygame.Vector2(tx * TILE + TILE / 2, ty * TILE + TILE / 2)

    def in_reach(self, tx, ty):
        return self.tile_center(tx, ty).distance_to(self.player.pos) <= REACH

    def near_bench(self):
        p = self.player
        px, py = int(p.pos.x // TILE), int(p.pos.y // TILE)
        for y in range(py - 4, py + 5):
            for x in range(px - 4, px + 5):
                if self.in_map(x, y) and self.grid[y][x] == BENCH:
                    return True
        return False

    def hurt(self, amount, force=False):
        p = self.player
        if self.dead or (p.hurt_cd > 0 and not force):
            return
        p.hp -= amount
        if not force:
            p.hurt_cd = 0.7
        if p.hp <= 0:
            p.hp = 0
            self.dead = True

    # ---- update
    def update(self, dt):
        if self.dead or self.menu_open or self.inv_open:
            return
        p = self.player
        self.time += dt
        keys = pygame.key.get_pressed()
        d = pygame.Vector2(
            (keys[pygame.K_d] or keys[pygame.K_RIGHT]) - (keys[pygame.K_a] or keys[pygame.K_LEFT]),
            (keys[pygame.K_s] or keys[pygame.K_DOWN]) - (keys[pygame.K_w] or keys[pygame.K_UP]),
        )
        if d.length_squared() > 0:
            d = d.normalize()
            p.facing = d.copy()
            self.move_entity(p, d * PLAYER_SPEED * dt)

        p.hurt_cd = max(0, p.hurt_cd - dt)
        p.swing_cd = max(0, p.swing_cd - dt)
        p.swing_anim = max(0, p.swing_anim - dt)
        self.msg_t = max(0, self.msg_t - dt)

        # hunger and regeneration
        p.hunger = max(0.0, p.hunger - dt / 3.5)
        if p.hunger <= 0:
            p.starve += dt
            if p.starve >= 1.5:
                p.starve = 0
                self.hurt(3, force=True)
        elif p.hunger > 60 and p.hp < p.max_hp:
            p.regen += dt
            if p.regen >= 2.5:
                p.regen = 0
                p.hp += 1

        # crops grow
        for k in self.crops:
            self.crops[k] += dt

        self.update_mining(dt)
        self.update_mobs(dt)
        self.update_boss(dt)
        self.update_shots(dt)

    def update_mining(self, dt):
        p = self.player
        if not pygame.mouse.get_pressed()[0]:
            self.mining = None
            return
        tx, ty = self.mouse_tile()
        if not self.in_map(tx, ty):
            self.mining = None
            return
        tile = self.grid[ty][tx]
        if tile not in HARDNESS or not self.in_reach(tx, ty):
            self.mining = None
            return
        if p.pick_level < NEED_PICK.get(tile, 1):
            if self.msg_t <= 0:
                self.say(f"Need Pickaxe Lv.{NEED_PICK[tile]} (craft at a workbench)")
            self.mining = None
            return
        prev = self.mining[2] if self.mining and self.mining[:2] == (tx, ty) else 0.0
        prog = prev + dt * (0.7 + 0.45 * p.pick_level)
        self.mining = (tx, ty, prog)
        if prog < HARDNESS[tile]:
            return
        self.grid[ty][tx] = FLOOR
        self.mining = None
        inv = p.inv
        if tile == STONE:
            inv["stone"] += 1
        elif tile == COPPER:
            inv["copper"] += random.randint(1, 2)
        elif tile == IRON:
            inv["iron"] += random.randint(1, 2)
        elif tile == GOLD:
            inv["gold"] += random.randint(1, 2)
        elif tile == ROOT:
            inv["wood"] += random.randint(1, 2)
            if random.random() < 0.3:
                inv["seeds"] += 1
        elif tile == BENCH:
            inv["wood"] += 5
            inv["stone"] += 5

    def update_mobs(self, dt):
        p = self.player
        self.spawn_timer -= dt
        if self.spawn_timer <= 0 and len(self.mobs) < 25:
            self.spawn_timer = max(1.2, 4.0 - self.time / 60)
            self.try_spawn()
        for e in self.mobs[:]:
            e.flash = max(0, e.flash - dt)
            e.bob += dt * 6
            to_p = p.pos - e.pos
            dist = to_p.length()
            if dist > 45 * TILE:
                self.mobs.remove(e)
                continue
            if 0 < dist < 8 * TILE:
                self.move_entity(e, to_p.normalize() * e.speed * dt)
            if dist < 22:
                self.hurt(e.stats["dmg"])
        for i, a in enumerate(self.mobs):
            for b in self.mobs[i + 1:]:
                v = a.pos - b.pos
                if 0 < v.length() < 18:
                    push = v.normalize() * 30 * dt
                    self.move_entity(a, push)
                    self.move_entity(b, -push)

    def try_spawn(self):
        p = self.player
        for _ in range(30):
            tx, ty = random.randint(1, MAP_W - 2), random.randint(1, MAP_H - 2)
            pos = self.tile_center(tx, ty)
            if (self.grid[ty][tx] == FLOOR and 10 * TILE < pos.distance_to(p.pos) < 22 * TILE
                    and pos.distance_to(self.boss.home) > 9 * TILE):
                self.mobs.append(Mob(pos, self.biome[ty][tx]))
                return

    def update_boss(self, dt):
        b, p = self.boss, self.player
        if b.dead:
            return
        b.flash = max(0, b.flash - dt)
        b.bob += dt * 4
        to_p = p.pos - b.pos
        dist = to_p.length()
        if dist < 12 * TILE:
            b.active = True
        elif dist > 26 * TILE:
            b.active = False
        if not b.active:
            b.hp = min(b.max_hp, b.hp + 5 * dt)
            back = b.home - b.pos
            if back.length() > 4:
                self.move_entity(b, back.normalize() * 60 * dt)
            return
        enraged = b.hp < b.max_hp * 0.5
        if dist > 0:
            self.move_entity(b, to_p.normalize() * (105 if enraged else 70) * dt)
        off = b.pos - b.home                      # keep the boss inside its arena
        if off.length() > 5.5 * TILE:
            b.pos = b.home + off.normalize() * 5.5 * TILE
        b.ring_t -= dt
        if b.ring_t <= 0:
            b.ring_t = 1.8 if enraged else 2.6
            n = 12 if enraged else 10
            off_a = random.random() * 6.28
            for i in range(n):
                a = off_a + i * 6.2832 / n
                self.shots.append(Shot(b.pos, (math.cos(a) * 150, math.sin(a) * 150)))
        if enraged:
            b.aim_t -= dt
            if b.aim_t <= 0 and dist > 0:
                b.aim_t = 1.6
                base = math.atan2(to_p.y, to_p.x)
                for off_a in (-0.25, 0, 0.25):
                    self.shots.append(Shot(b.pos, (math.cos(base + off_a) * 230,
                                                   math.sin(base + off_a) * 230)))
        if dist < b.size / 2 + 12 and p.hurt_cd <= 0 and dist > 0:
            self.hurt(15)
            step = to_p.normalize() * 8              # knockback away from the boss,
            for _ in range(6):                       # in small steps so it can't
                self.move_entity(p, step)            # tunnel through a wall

    def update_shots(self, dt):
        for s in self.shots[:]:
            s.pos += s.vel * dt
            s.life -= dt
            tx, ty = int(s.pos.x // TILE), int(s.pos.y // TILE)
            if s.life <= 0 or self.solid(tx, ty):
                self.shots.remove(s)
            elif s.pos.distance_to(self.player.pos) < 14:
                self.hurt(12)
                self.shots.remove(s)

    # ---- actions
    def swing(self):
        p = self.player
        if p.swing_cd > 0 or self.dead or self.menu_open:
            return
        p.swing_cd = 0.35
        p.swing_anim = 0.15
        dmg = 10 + 8 * p.sword_level
        hit = p.pos + p.facing * 26
        for e in self.mobs[:]:
            if e.pos.distance_to(hit) < 36:
                e.hp -= dmg
                e.flash = 0.15
                self.move_entity(e, p.facing * 14)
                if e.hp <= 0:
                    self.mobs.remove(e)
                    self.kills += 1
                    if random.random() < 0.4:
                        p.inv[e.stats["drop"]] += 1
        b = self.boss
        if not b.dead and b.pos.distance_to(hit) < 36 + b.size / 2:
            b.hp -= dmg
            b.flash = 0.12
            b.active = True
            if b.hp <= 0:
                b.dead = True
                self.shots.clear()
                p.max_hp += 25
                p.hp = p.max_hp
                p.inv["gold"] += 10
                self.say("The Gloop King is defeated! Max HP +25, 10 gold!")

    def harvest(self):
        tx, ty = self.mouse_tile()
        if (tx, ty) not in self.crops or not self.in_reach(tx, ty):
            return
        if self.crops[(tx, ty)] < GROW_TIME:
            self.say("Not ripe yet")
            return
        del self.crops[(tx, ty)]
        self.player.inv["wheat"] += 2
        self.player.inv["seeds"] += random.randint(1, 2)

    def use_item(self):
        p = self.player
        tx, ty = self.mouse_tile()
        if not self.in_map(tx, ty) or not self.in_reach(tx, ty):
            return
        tile = self.grid[ty][tx]
        has_torch = any(t.tx == tx and t.ty == ty for t in self.torches)
        if self.sel == 0:                                    # torch
            if tile != FLOOR or has_torch:
                return
            if p.inv["torch"] < 1:
                self.say("No torches. Craft some with E")
                return
            p.inv["torch"] -= 1
            self.torches.append(Torch(tx, ty))
        elif self.sel == 1:                                  # hoe
            if p.inv["hoe"] < 1:
                self.say("Craft a hoe first (E)")
            elif tile == FLOOR and not has_torch:
                self.grid[ty][tx] = SOIL
        elif self.sel == 2:                                  # seeds
            if tile != SOIL or (tx, ty) in self.crops:
                return
            if p.inv["seeds"] < 1:
                self.say("No seeds")
                return
            p.inv["seeds"] -= 1
            self.crops[(tx, ty)] = 0.0
        elif self.sel == 3:                                  # workbench
            if tile != FLOOR or has_torch:
                return
            if p.inv["wood"] < 5 or p.inv["stone"] < 5:
                self.say("Workbench needs 5 wood and 5 stone")
                return
            r = pygame.Rect(tx * TILE, ty * TILE, TILE, TILE)
            if (r.colliderect(p.rect()) or any(r.colliderect(m.rect()) for m in self.mobs)
                    or (not self.boss.dead and r.colliderect(self.boss.rect()))):
                return
            p.inv["wood"] -= 5
            p.inv["stone"] -= 5
            self.grid[ty][tx] = BENCH

    def eat(self):
        p = self.player
        if self.dead or self.menu_open:
            return
        if p.hunger >= 99:
            self.say("You are not hungry")
        elif p.inv["bread"] > 0:
            p.inv["bread"] -= 1
            p.hunger = min(100, p.hunger + 45)
            p.hp = min(p.max_hp, p.hp + 5)
        elif p.inv["wheat"] > 0:
            p.inv["wheat"] -= 1
            p.hunger = min(100, p.hunger + 12)
        else:
            self.say("No food. Grow wheat and bake bread")

    def visible_recipes(self):
        return [r for r in RECIPES if r["show"](self.player)]

    def craft(self, recipe):
        p = self.player
        if recipe["bench"] and not self.near_bench():
            self.say("Stand near a workbench (within 4 tiles)")
            return
        if any(p.inv[k] < n for k, n in recipe["cost"].items()):
            self.say("Not enough materials")
            return
        for k, n in recipe["cost"].items():
            p.inv[k] -= n
        recipe["apply"](p)
        self.say(f"Crafted {recipe['name']}")

    # ---- draw
    def draw_tile(self, scr, tx, ty, cam):
        t, b = self.grid[ty][tx], self.biome[ty][tx]
        r = pygame.Rect(tx * TILE - cam.x, ty * TILE - cam.y, TILE, TILE)
        if t in (FLOOR, BENCH):
            pygame.draw.rect(scr, FLOOR_COL[b], r)
            if (tx * 7 + ty * 13) % 5 == 0:
                pygame.draw.circle(scr, SPECK_COL[b], r.center, 3)
            if t == BENCH:
                pygame.draw.rect(scr, (110, 74, 42), (r.x + 3, r.y + 10, 26, 16))
                pygame.draw.rect(scr, (176, 134, 84), (r.x + 3, r.y + 6, 26, 7))
                pygame.draw.rect(scr, (60, 40, 24), (r.x + 3, r.y + 6, 26, 20), 1)
                pygame.draw.line(scr, (210, 210, 220), (r.x + 9, r.y + 4), (r.x + 15, r.y + 9), 2)
        elif t == SOIL:
            pygame.draw.rect(scr, (62, 38, 26), r)
            for i in (8, 16, 24):
                pygame.draw.line(scr, (44, 26, 18), (r.x + 2, r.y + i), (r.right - 3, r.y + i), 2)
            g = self.crops.get((tx, ty))
            if g is not None:
                self.draw_crop(scr, r, g / GROW_TIME)
        elif t == BORDER:
            pygame.draw.rect(scr, (28, 28, 34), r)
        else:
            pygame.draw.rect(scr, WALL_COL[b], r)
            pygame.draw.rect(scr, (0, 0, 0), r, 1)
            ore = {COPPER: (214, 132, 70), IRON: (230, 230, 240), GOLD: (250, 208, 60)}.get(t)
            if ore:
                for ox, oy in ((8, 9), (20, 12), (13, 22)):
                    pygame.draw.circle(scr, ore, (r.x + ox, r.y + oy), 4)
                    pygame.draw.circle(scr, (30, 30, 30), (r.x + ox, r.y + oy), 4, 1)
            elif t == ROOT:
                pygame.draw.line(scr, (140, 100, 60), (r.x + 6, r.y + 26), (r.x + 26, r.y + 6), 4)
                pygame.draw.line(scr, (140, 100, 60), (r.x + 6, r.y + 8), (r.x + 22, r.y + 28), 3)

    def draw_crop(self, scr, r, frac):
        if frac < 0.34:
            pygame.draw.line(scr, (90, 190, 80), (r.centerx, r.bottom - 6), (r.centerx, r.bottom - 12), 2)
        elif frac < 1:
            for ox in (-6, 0, 6):
                pygame.draw.line(scr, (90, 190, 80), (r.centerx + ox, r.bottom - 5),
                                 (r.centerx + ox, r.bottom - 18), 2)
        else:
            for ox in (-7, 0, 7):
                pygame.draw.line(scr, (210, 180, 70), (r.centerx + ox, r.bottom - 5),
                                 (r.centerx + ox, r.bottom - 22), 2)
                pygame.draw.circle(scr, (240, 205, 80), (r.centerx + ox, r.bottom - 23), 3)

    def draw(self):
        scr = self.screen
        scr.fill((12, 10, 10))
        cam = self.cam()
        x0, y0 = max(0, int(cam.x // TILE)), max(0, int(cam.y // TILE))
        x1 = min(MAP_W, int((cam.x + W) // TILE) + 1)
        y1 = min(MAP_H, int((cam.y + H) // TILE) + 1)
        for ty in range(y0, y1):
            for tx in range(x0, x1):
                self.draw_tile(scr, tx, ty, cam)

        if self.mining:
            tx, ty, prog = self.mining
            frac = min(1, prog / HARDNESS[self.grid[ty][tx]])
            r = pygame.Rect(tx * TILE - cam.x, ty * TILE - cam.y, TILE, TILE)
            pygame.draw.rect(scr, (255, 255, 255), r, 2)
            pygame.draw.rect(scr, (255, 220, 80), (r.x, r.bottom - 5, int(TILE * frac), 4))

        # highlight tile under mouse when it is in reach
        mtx, mty = self.mouse_tile()
        if self.in_map(mtx, mty) and self.in_reach(mtx, mty):
            r = pygame.Rect(mtx * TILE - cam.x, mty * TILE - cam.y, TILE, TILE)
            pygame.draw.rect(scr, (255, 255, 255), r, 1)

        for t in self.torches:
            c = (t.tx * TILE + TILE // 2 - cam.x, t.ty * TILE + TILE // 2 - cam.y)
            pygame.draw.rect(scr, (110, 70, 40), (c[0] - 2, c[1] - 2, 4, 12))
            flick = 4 + math.sin(self.time * 12 + t.tx) * 1.5
            pygame.draw.circle(scr, (255, 170, 40), (c[0], c[1] - 4), flick)
            pygame.draw.circle(scr, (255, 230, 120), (c[0], c[1] - 4), flick * 0.5)

        for e in self.mobs:
            sx, sy = e.pos.x - cam.x, e.pos.y - cam.y
            squash = math.sin(e.bob) * 2
            col = (255, 255, 255) if e.flash > 0 else e.stats["col"]
            body = pygame.Rect(0, 0, 24 + squash, 20 - squash)
            body.center = (sx, sy)
            pygame.draw.ellipse(scr, col, body)
            pygame.draw.circle(scr, (20, 20, 20), (sx - 4, sy - 2), 2)
            pygame.draw.circle(scr, (20, 20, 20), (sx + 4, sy - 2), 2)

        self.draw_boss(scr, cam)

        for s in self.shots:
            c = (s.pos.x - cam.x, s.pos.y - cam.y)
            pygame.draw.circle(scr, (255, 120, 40), c, 7)
            pygame.draw.circle(scr, (255, 230, 150), c, 3)

        p = self.player
        px, py = p.pos.x - cam.x, p.pos.y - cam.y
        blink = p.hurt_cd > 0 and int(self.time * 20) % 2 == 0
        pygame.draw.rect(scr, (240, 240, 240) if blink else (80, 140, 230),
                         (px - 11, py - 11, 22, 22), border_radius=5)
        eye = p.facing * 5
        pygame.draw.circle(scr, (255, 255, 255), (px + eye.x - 3, py + eye.y - 2), 2)
        pygame.draw.circle(scr, (255, 255, 255), (px + eye.x + 3, py + eye.y - 2), 2)
        if p.swing_anim > 0:
            tip = (px + p.facing.x * 38, py + p.facing.y * 38)
            pygame.draw.line(scr, (230, 230, 240), (px, py), tip, 5)

        # darkness with light holes
        self.dark.fill((0, 0, 0, DARKNESS))
        spr = self.light_sprite(LIGHT_PLAYER)
        self.dark.blit(spr, (px - LIGHT_PLAYER, py - LIGHT_PLAYER), special_flags=pygame.BLEND_RGBA_SUB)
        tspr = self.light_sprite(LIGHT_TORCH)
        for t in self.torches:
            cx = t.tx * TILE + TILE // 2 - cam.x
            cy = t.ty * TILE + TILE // 2 - cam.y
            if -LIGHT_TORCH < cx < W + LIGHT_TORCH and -LIGHT_TORCH < cy < H + LIGHT_TORCH:
                self.dark.blit(tspr, (cx - LIGHT_TORCH, cy - LIGHT_TORCH),
                               special_flags=pygame.BLEND_RGBA_SUB)
        if not self.boss.dead and self.boss.active:
            bx, by = self.boss.pos.x - cam.x, self.boss.pos.y - cam.y
            self.dark.blit(tspr, (bx - LIGHT_TORCH, by - LIGHT_TORCH),
                           special_flags=pygame.BLEND_RGBA_SUB)
        scr.blit(self.dark, (0, 0))

        self.draw_hud()
        if self.menu_open:
            self.draw_menu()
        if self.inv_open:
            self.draw_inventory()
        if self.dead:
            self.draw_game_over()
        pygame.display.flip()

    def draw_boss(self, scr, cam):
        b = self.boss
        if b.dead:
            return
        sx, sy = b.pos.x - cam.x, b.pos.y - cam.y
        squash = math.sin(b.bob) * 3
        col = (255, 255, 255) if b.flash > 0 else (140, 50, 170)
        body = pygame.Rect(0, 0, 56 + squash, 48 - squash)
        body.center = (sx, sy)
        pygame.draw.ellipse(scr, col, body)
        pygame.draw.ellipse(scr, (50, 10, 70), body, 3)
        for ex in (-10, 10):
            pygame.draw.circle(scr, (255, 70, 70), (sx + ex, sy - 4), 5)
            pygame.draw.circle(scr, (30, 0, 0), (sx + ex, sy - 4), 2)
        pygame.draw.polygon(scr, (250, 208, 60), [(sx - 16, sy - 22), (sx - 10, sy - 34),
                                                   (sx - 3, sy - 24), (sx, sy - 36),
                                                   (sx + 3, sy - 24), (sx + 10, sy - 34),
                                                   (sx + 16, sy - 22)])

    def draw_bar(self, x, y, w, h, frac, col, back=(40, 14, 14)):
        pygame.draw.rect(self.screen, back, (x, y, w, h))
        pygame.draw.rect(self.screen, col, (x + 2, y + 2, int((w - 4) * max(0, min(1, frac))), h - 4))
        pygame.draw.rect(self.screen, (255, 255, 255), (x, y, w, h), 1)

    def draw_hud(self):
        scr, p = self.screen, self.player
        self.draw_bar(14, 14, 204, 18, p.hp / p.max_hp, (210, 50, 50))
        self.draw_bar(14, 36, 204, 12, p.hunger / 100, (230, 150, 50), (50, 30, 10))
        i = p.inv
        lines = [
            f"Stone {i['stone']}  Copper {i['copper']}  Iron {i['iron']}  Gold {i['gold']}",
            f"Wood {i['wood']}  Wheat {i['wheat']}  Bread {i['bread']}",
            f"Pick Lv.{p.pick_level}  Sword Lv.{p.sword_level}  Kills {self.kills}",
        ]
        for n, line in enumerate(lines):
            scr.blit(self.font.render(line, True, (240, 240, 240)), (14, 54 + n * 21))

        tx, ty = int(p.pos.x // TILE), int(p.pos.y // TILE)
        name = BIOME_NAMES[self.biome[ty][tx]] if self.in_map(tx, ty) else ""
        t = self.font.render(name, True, (255, 240, 200))
        scr.blit(t, (W - t.get_width() - 14, 14))
        b = self.boss
        if not b.dead:
            v = b.home - p.pos
            names = ["E", "SE", "S", "SW", "W", "NW", "N", "NE"]
            ang = math.degrees(math.atan2(v.y, v.x))
            txt = f"Gloop King: {int(v.length() / TILE)} tiles {names[int(((ang + 22.5) % 360) // 45)]}"
            t = self.small.render(txt, True, (230, 170, 255))
            scr.blit(t, (W - t.get_width() - 14, 38))
            if b.active:
                self.draw_bar(W // 2 - 200, 14, 400, 16, b.hp / b.max_hp, (150, 50, 190))
                t = self.small.render("Gloop King", True, (255, 255, 255))
                scr.blit(t, (W // 2 - t.get_width() // 2, 32))
        else:
            t = self.small.render("Gloop King defeated", True, (150, 230, 150))
            scr.blit(t, (W - t.get_width() - 14, 38))

        # hotbar
        slots = [("Torch", str(i["torch"])), ("Hoe", "owned" if i["hoe"] else "none"),
                 ("Seeds", str(i["seeds"])), ("Bench", "5w 5s")]
        x0 = W // 2 - (len(slots) * 72) // 2
        for n, (label, cnt) in enumerate(slots):
            r = pygame.Rect(x0 + n * 72, H - 66, 66, 40)
            pygame.draw.rect(scr, (24, 22, 26), r)
            pygame.draw.rect(scr, (255, 220, 90) if n == self.sel else (110, 110, 120), r, 2)
            scr.blit(self.small.render(f"{n + 1} {label}", True, (240, 240, 240)), (r.x + 4, r.y + 4))
            scr.blit(self.small.render(cnt, True, (200, 200, 120)), (r.x + 4, r.y + 21))
        # bag button (opens the inventory panel)
        r = self.bag_button_rect()
        hover = r.collidepoint(pygame.mouse.get_pos())
        pygame.draw.rect(scr, (52, 44, 30) if hover or self.inv_open else (24, 22, 26), r)
        pygame.draw.rect(scr, (200, 180, 120), r, 2)
        self.draw_bag_icon(scr, r.x + 14, r.centery)
        scr.blit(self.small.render("Bag", True, (240, 240, 240)), (r.x + 28, r.y + 4))
        scr.blit(self.small.render("I", True, (200, 200, 120)), (r.x + 28, r.y + 21))

        hint = "LMB mine/harvest | SPACE attack | RMB use | E craft | I bag | G eat | F5 save | F9 load"
        t = self.small.render(hint, True, (190, 190, 190))
        scr.blit(t, (W // 2 - t.get_width() // 2, H - 20))
        if self.msg_t > 0:
            t = self.font.render(self.msg, True, (255, 230, 120))
            scr.blit(t, (W // 2 - t.get_width() // 2, H - 100))

    def draw_menu(self):
        scr = self.screen
        recs = self.visible_recipes()
        w, h = 540, 90 + len(recs) * 40
        panel = pygame.Rect(W // 2 - w // 2, H // 2 - h // 2, w, h)
        pygame.draw.rect(scr, (22, 20, 28), panel, border_radius=8)
        pygame.draw.rect(scr, (200, 180, 120), panel, 2, border_radius=8)
        near = self.near_bench()
        title = "Crafting  (workbench nearby)" if near else "Crafting  (no workbench nearby)"
        scr.blit(self.font.render(title, True, (255, 230, 150) if near else (230, 140, 140)),
                 (panel.x + 16, panel.y + 12))
        self.menu_rects = []
        p = self.player
        for n, rec in enumerate(recs):
            r = pygame.Rect(panel.x + 12, panel.y + 46 + n * 40, w - 24, 34)
            ok = all(p.inv[k] >= c for k, c in rec["cost"].items()) and (near or not rec["bench"])
            pygame.draw.rect(scr, (40, 60, 44) if ok else (40, 36, 40), r, border_radius=5)
            cost = ", ".join(f"{c} {k}" for k, c in rec["cost"].items())
            tag = "" if not rec["bench"] else "  [bench]"
            scr.blit(self.font.render(f"{n + 1}. {rec['name']}{tag}", True,
                                      (255, 255, 255) if ok else (150, 150, 150)), (r.x + 8, r.y + 7))
            c = self.small.render(cost, True, (200, 220, 160) if ok else (150, 120, 120))
            scr.blit(c, (r.right - c.get_width() - 10, r.y + 10))
            self.menu_rects.append((r, rec))
        t = self.small.render("Press a number or click to craft. E or ESC to close.", True, (170, 170, 170))
        scr.blit(t, (panel.x + 16, panel.bottom - 22))

    def bag_button_rect(self):
        x0 = W // 2 - (4 * 72) // 2               # same layout as the hotbar
        return pygame.Rect(x0 + 4 * 72 + 12, H - 66, 66, 40)

    def draw_bag_icon(self, scr, cx, cy):
        pygame.draw.rect(scr, (150, 105, 60), (cx - 8, cy - 5, 16, 14), border_radius=3)
        pygame.draw.rect(scr, (90, 60, 34), (cx - 8, cy - 5, 16, 14), 1, border_radius=3)
        pygame.draw.arc(scr, (90, 60, 34), (cx - 5, cy - 11, 10, 10), 0, math.pi, 2)

    def draw_item_icon(self, scr, key, c):
        col = ITEM_COL[key]
        x, y = c
        if key in ("copper", "iron", "gold"):
            for ox, oy in ((-6, -3), (5, -5), (0, 6)):
                pygame.draw.circle(scr, col, (x + ox, y + oy), 5)
                pygame.draw.circle(scr, (30, 30, 30), (x + ox, y + oy), 5, 1)
        elif key == "stone":
            pygame.draw.polygon(scr, col, [(x - 11, y + 7), (x - 7, y - 7), (x + 5, y - 9),
                                           (x + 11, y + 2), (x + 6, y + 9)])
        elif key == "wood":
            pygame.draw.line(scr, col, (x - 10, y + 8), (x + 10, y - 8), 6)
        elif key == "seeds":
            for ox, oy in ((-5, 2), (3, -4), (5, 5)):
                pygame.draw.ellipse(scr, col, (x + ox - 3, y + oy - 2, 6, 4))
        elif key == "wheat":
            for ox in (-5, 0, 5):
                pygame.draw.line(scr, col, (x + ox, y + 10), (x + ox, y - 6), 2)
                pygame.draw.circle(scr, (240, 205, 80), (x + ox, y - 7), 3)
        elif key == "bread":
            pygame.draw.ellipse(scr, col, (x - 12, y - 7, 24, 14))
            pygame.draw.ellipse(scr, (120, 70, 30), (x - 12, y - 7, 24, 14), 1)
        elif key == "torch":
            pygame.draw.rect(scr, (110, 70, 40), (x - 2, y - 2, 4, 13))
            pygame.draw.circle(scr, col, (x, y - 5), 5)
            pygame.draw.circle(scr, (255, 230, 120), (x, y - 5), 2)
        elif key == "hoe":
            pygame.draw.line(scr, (140, 100, 60), (x - 8, y + 10), (x + 6, y - 8), 3)
            pygame.draw.line(scr, col, (x + 1, y - 9), (x + 10, y - 4), 4)

    def draw_inventory(self):
        scr, p = self.screen, self.player
        cols, cell_w, cell_h, gap = 5, 96, 74, 8
        rows = (len(ITEM_INFO) + cols - 1) // cols
        w = cols * cell_w + (cols - 1) * gap + 32
        h = 64 + rows * (cell_h + gap) + 70
        panel = pygame.Rect(W // 2 - w // 2, H // 2 - h // 2, w, h)
        pygame.draw.rect(scr, (22, 20, 28), panel, border_radius=8)
        pygame.draw.rect(scr, (200, 180, 120), panel, 2, border_radius=8)
        self.draw_bag_icon(scr, panel.x + 26, panel.y + 24)
        scr.blit(self.font.render("Bag", True, (255, 230, 150)), (panel.x + 42, panel.y + 13))
        total = sum(p.inv.get(k, 0) for k, _ in ITEM_INFO)
        t = self.small.render(f"{total} items", True, (170, 170, 170))
        scr.blit(t, (panel.right - t.get_width() - 16, panel.y + 16))

        for n, (key, label) in enumerate(ITEM_INFO):
            cx = panel.x + 16 + (n % cols) * (cell_w + gap)
            cy = panel.y + 48 + (n // cols) * (cell_h + gap)
            r = pygame.Rect(cx, cy, cell_w, cell_h)
            cnt = p.inv.get(key, 0)
            pygame.draw.rect(scr, (40, 38, 46) if cnt else (30, 28, 34), r, border_radius=5)
            pygame.draw.rect(scr, (90, 86, 100), r, 1, border_radius=5)
            self.draw_item_icon(scr, key, (r.centerx, r.y + 24))
            name_col = (240, 240, 240) if cnt else (120, 120, 120)
            t = self.small.render(label, True, name_col)
            scr.blit(t, (r.centerx - t.get_width() // 2, r.y + 42))
            txt = ("owned" if cnt else "none") if key == "hoe" else str(cnt)
            t = self.small.render(txt, True, (200, 200, 120) if cnt else (110, 110, 110))
            scr.blit(t, (r.centerx - t.get_width() // 2, r.y + 57))

        gy = panel.bottom - 62
        pygame.draw.line(scr, (90, 86, 100), (panel.x + 16, gy - 6), (panel.right - 16, gy - 6))
        gear = (f"Pickaxe Lv.{p.pick_level}   Sword Lv.{p.sword_level}   "
                f"HP {int(p.hp)}/{p.max_hp}   Food {int(p.hunger)}%")
        scr.blit(self.font.render(gear, True, (230, 230, 230)), (panel.x + 16, gy))
        t = self.small.render("I, ESC or click Bag to close.", True, (170, 170, 170))
        scr.blit(t, (panel.x + 16, panel.bottom - 22))

    def draw_game_over(self):
        ov = pygame.Surface((W, H), pygame.SRCALPHA)
        ov.fill((0, 0, 0, 170))
        self.screen.blit(ov, (0, 0))
        t = self.big.render("YOU DIED", True, (230, 70, 70))
        s = self.font.render(f"Kills {self.kills}   Survived {int(self.time)}s   "
                             "Press R to continue from your last save", True, (240, 240, 240))
        self.screen.blit(t, (W // 2 - t.get_width() // 2, H // 2 - 50))
        self.screen.blit(s, (W // 2 - s.get_width() // 2, H // 2 + 10))

    # ---- loop
    def handle_event(self, ev):
        """Returns False when the game should quit."""
        if ev.type == pygame.QUIT:
            return False
        if ev.type == pygame.KEYDOWN:
            k = ev.key
            if k == pygame.K_ESCAPE:
                if self.menu_open or self.inv_open:
                    self.menu_open = self.inv_open = False
                else:
                    return False
            elif k == pygame.K_e and not self.dead:
                self.menu_open = not self.menu_open
                self.inv_open = False
            elif k == pygame.K_i and not self.dead:
                self.toggle_inventory()
            elif k == pygame.K_F5:
                self.save()
            elif k == pygame.K_F9:
                self.load()
            elif k == pygame.K_F10:
                self.reset()
            elif k == pygame.K_r and self.dead:
                if not self.load(quiet=True):
                    self.reset()
            elif self.menu_open and pygame.K_1 <= k <= pygame.K_9:
                recs = self.visible_recipes()
                if k - pygame.K_1 < len(recs):
                    self.craft(recs[k - pygame.K_1])
            elif not self.menu_open and not self.inv_open and not self.dead:
                if k == pygame.K_SPACE:
                    self.swing()
                elif k == pygame.K_g:
                    self.eat()
                elif pygame.K_1 <= k <= pygame.K_4:
                    self.sel = k - pygame.K_1
        elif ev.type == pygame.MOUSEWHEEL and not self.menu_open and not self.inv_open:
            self.sel = (self.sel - ev.y) % 4
        elif ev.type == pygame.MOUSEBUTTONDOWN and not self.dead:
            if ev.button == 1 and self.bag_button_rect().collidepoint(ev.pos):
                self.toggle_inventory()
            elif self.inv_open:
                pass                                   # panel is open: ignore world clicks
            elif self.menu_open and ev.button == 1:
                for r, rec in self.menu_rects:
                    if r.collidepoint(ev.pos):
                        self.craft(rec)
            elif not self.menu_open and ev.button == 3:
                self.use_item()
            elif not self.menu_open and ev.button == 1:
                self.harvest()
        return True

    def toggle_inventory(self):
        self.inv_open = not self.inv_open
        self.menu_open = False
        self.mining = None

    def run(self, max_frames=None):
        frames = 0
        while True:
            dt = min(self.clock.tick(FPS) / 1000, 0.05)
            for ev in pygame.event.get():
                if not self.handle_event(ev):
                    self.save(quiet=True)
                    return
            self.update(dt)
            self.draw()
            frames += 1
            if max_frames and frames >= max_frames:
                return


if __name__ == "__main__":
    Game().run()
    pygame.quit()
    sys.exit()
