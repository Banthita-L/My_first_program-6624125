"""Draws the Cave Keeper icon with pygame and writes cave_keeper.ico (and .png).

Run:  python make_icon.py
The .ico stores PNG images at 16, 32, 48 and 256 px (supported on Windows Vista+).
"""
import io
import os
import struct

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
import pygame

HERE = os.path.dirname(os.path.abspath(__file__))


def draw_icon(size=256):
    s = pygame.Surface((size, size), pygame.SRCALPHA)
    k = size / 256

    def R(x, y, w, h):
        return pygame.Rect(round(x * k), round(y * k), round(w * k), round(h * k))

    def P(x, y):
        return round(x * k), round(y * k)

    # rounded dark cave tile with a warm glow
    pygame.draw.rect(s, (28, 22, 20), R(0, 0, 256, 256), border_radius=round(44 * k))
    glow = pygame.Surface((size, size), pygame.SRCALPHA)
    for r in range(120, 40, -4):                  # many faint rings = smooth glow
        pygame.draw.circle(glow, (255, 170, 60, 7), P(128, 140), round(r * k))
        s.blit(glow, (0, 0))
        glow.fill((0, 0, 0, 0))
    # stone walls with ore
    for x, y in ((14, 18), (54, 18), (190, 26), (14, 58), (202, 186), (162, 206)):
        pygame.draw.rect(s, (96, 96, 104), R(x, y, 40, 40), border_radius=round(5 * k))
        pygame.draw.rect(s, (40, 40, 46), R(x, y, 40, 40), max(1, round(2 * k)), border_radius=round(5 * k))
    for (x, y), col in (((28, 30), (214, 132, 70)), ((66, 34), (214, 132, 70)),
                        ((206, 42), (250, 208, 60)), ((216, 200), (230, 230, 240))):
        pygame.draw.circle(s, col, P(x, y), round(6 * k))
    # player cube
    pygame.draw.rect(s, (80, 140, 230), R(78, 92, 100, 100), border_radius=round(20 * k))
    pygame.draw.rect(s, (40, 80, 160), R(78, 92, 100, 100), max(1, round(5 * k)), border_radius=round(20 * k))
    for ex in (112, 144):
        pygame.draw.circle(s, (255, 255, 255), P(ex, 132), round(10 * k))
        pygame.draw.circle(s, (20, 30, 60), P(ex + 3, 133), round(5 * k))
    # pickaxe
    pygame.draw.line(s, (140, 100, 60), P(170, 214), P(216, 98), max(2, round(10 * k)))
    pygame.draw.arc(s, (210, 210, 220), R(184, 92, 64, 50), 0.3, 2.9, max(2, round(10 * k)))
    return s


def png_bytes(surf):
    buf = io.BytesIO()
    pygame.image.save(surf, buf, "icon.png")
    return buf.getvalue()


def main():
    pygame.init()
    big = draw_icon(256)
    images = [png_bytes(draw_icon(n) if n >= 48 else pygame.transform.smoothscale(big, (n, n)))
              for n in (16, 32, 48, 256)]
    sizes = (16, 32, 48, 256)
    header = struct.pack("<HHH", 0, 1, len(images))
    offset = 6 + 16 * len(images)
    entries, data = b"", b""
    for n, img in zip(sizes, images):
        dim = 0 if n == 256 else n                # 0 means 256 in the ICO format
        entries += struct.pack("<BBBBHHII", dim, dim, 0, 0, 1, 32, len(img), offset)
        offset += len(img)
        data += img
    with open(os.path.join(HERE, "cave_keeper.ico"), "wb") as f:
        f.write(header + entries + data)
    pygame.image.save(big, os.path.join(HERE, "cave_keeper_icon.png"))
    print("wrote cave_keeper.ico and cave_keeper_icon.png")
    pygame.quit()


if __name__ == "__main__":
    main()
