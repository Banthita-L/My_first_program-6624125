"""
coords.py — UTM to latitude/longitude conversion.

Written out in full rather than pulling in pyproj, so the program installs
with nothing but Flask and stays easy to read for a geoscience write-up.

The formulas are the standard Krueger series on the WGS 84 ellipsoid, the
same ones used by the USGS and by most survey software. Accuracy is a few
millimetres inside a zone, which is far finer than a borehole collar is ever
surveyed.

Thailand sits in UTM zones 47N and 48N.
"""

from __future__ import annotations

import math

# WGS 84 ellipsoid
SEMI_MAJOR_AXIS = 6378137.0
FLATTENING = 1 / 298.257223563
ECCENTRICITY_SQ = FLATTENING * (2 - FLATTENING)

SCALE_FACTOR = 0.9996          # UTM central-meridian scale
FALSE_EASTING = 500000.0
FALSE_NORTHING = 10000000.0    # applied in the southern hemisphere only


class CoordinateError(ValueError):
    """Raised when the given UTM values cannot describe a real place."""


def validate_zone(zone):
    zone = int(zone)
    if not 1 <= zone <= 60:
        raise CoordinateError("UTM zone must be between 1 and 60.")
    return zone


def utm_to_latlon(easting, northing, zone, hemisphere="N"):
    """
    Convert UTM easting/northing to (latitude, longitude) in decimal degrees.

    hemisphere is "N" or "S" (case-insensitive).
    """
    try:
        easting = float(easting)
        northing = float(northing)
    except (TypeError, ValueError):
        raise CoordinateError("Easting and northing must be numbers.")

    zone = validate_zone(zone)
    north = str(hemisphere or "N").strip().upper().startswith("N")

    if not 100000 <= easting <= 900000:
        raise CoordinateError(
            "Easting looks wrong: UTM eastings run from 100,000 to 900,000 m."
        )
    if not 0 <= northing <= 10000000:
        raise CoordinateError(
            "Northing looks wrong: UTM northings run from 0 to 10,000,000 m."
        )

    x = easting - FALSE_EASTING
    y = northing if north else northing - FALSE_NORTHING

    e2 = ECCENTRICITY_SQ
    e1 = (1 - math.sqrt(1 - e2)) / (1 + math.sqrt(1 - e2))
    ep2 = e2 / (1 - e2)

    m = y / SCALE_FACTOR
    mu = m / (SEMI_MAJOR_AXIS * (1 - e2 / 4 - 3 * e2**2 / 64 - 5 * e2**3 / 256))

    phi1 = (
        mu
        + (3 * e1 / 2 - 27 * e1**3 / 32) * math.sin(2 * mu)
        + (21 * e1**2 / 16 - 55 * e1**4 / 32) * math.sin(4 * mu)
        + (151 * e1**3 / 96) * math.sin(6 * mu)
        + (1097 * e1**4 / 512) * math.sin(8 * mu)
    )

    sin_phi1 = math.sin(phi1)
    cos_phi1 = math.cos(phi1)
    tan_phi1 = math.tan(phi1)

    c1 = ep2 * cos_phi1**2
    t1 = tan_phi1**2
    n1 = SEMI_MAJOR_AXIS / math.sqrt(1 - e2 * sin_phi1**2)
    r1 = SEMI_MAJOR_AXIS * (1 - e2) / (1 - e2 * sin_phi1**2) ** 1.5
    d = x / (n1 * SCALE_FACTOR)

    latitude = phi1 - (n1 * tan_phi1 / r1) * (
        d**2 / 2
        - (5 + 3 * t1 + 10 * c1 - 4 * c1**2 - 9 * ep2) * d**4 / 24
        + (61 + 90 * t1 + 298 * c1 + 45 * t1**2 - 252 * ep2 - 3 * c1**2) * d**6 / 720
    )

    longitude = (
        d
        - (1 + 2 * t1 + c1) * d**3 / 6
        + (5 - 2 * c1 + 28 * t1 - 3 * c1**2 + 8 * ep2 + 24 * t1**2) * d**5 / 120
    ) / cos_phi1

    central_meridian = math.radians((zone - 1) * 6 - 180 + 3)

    return (
        round(math.degrees(latitude), 8),
        round(math.degrees(longitude) + math.degrees(central_meridian), 8),
    )


def latlon_to_utm(latitude, longitude):
    """
    Convert latitude/longitude in decimal degrees to UTM.

    Returns (easting, northing, zone, hemisphere). Mainly here so the app can
    show a borehole's UTM position back to the user after they typed
    latitude and longitude.
    """
    try:
        latitude = float(latitude)
        longitude = float(longitude)
    except (TypeError, ValueError):
        raise CoordinateError("Latitude and longitude must be numbers.")

    validate_latlon(latitude, longitude)

    zone = int((longitude + 180) / 6) + 1
    central_meridian = math.radians((zone - 1) * 6 - 180 + 3)

    phi = math.radians(latitude)
    lam = math.radians(longitude)

    e2 = ECCENTRICITY_SQ
    ep2 = e2 / (1 - e2)

    n = SEMI_MAJOR_AXIS / math.sqrt(1 - e2 * math.sin(phi) ** 2)
    t = math.tan(phi) ** 2
    c = ep2 * math.cos(phi) ** 2
    a = math.cos(phi) * (lam - central_meridian)

    m = SEMI_MAJOR_AXIS * (
        (1 - e2 / 4 - 3 * e2**2 / 64 - 5 * e2**3 / 256) * phi
        - (3 * e2 / 8 + 3 * e2**2 / 32 + 45 * e2**3 / 1024) * math.sin(2 * phi)
        + (15 * e2**2 / 256 + 45 * e2**3 / 1024) * math.sin(4 * phi)
        - (35 * e2**3 / 3072) * math.sin(6 * phi)
    )

    easting = SCALE_FACTOR * n * (
        a + (1 - t + c) * a**3 / 6
        + (5 - 18 * t + t**2 + 72 * c - 58 * ep2) * a**5 / 120
    ) + FALSE_EASTING

    northing = SCALE_FACTOR * (
        m + n * math.tan(phi) * (
            a**2 / 2
            + (5 - t + 9 * c + 4 * c**2) * a**4 / 24
            + (61 - 58 * t + t**2 + 600 * c - 330 * ep2) * a**6 / 720
        )
    )

    hemisphere = "N"
    if latitude < 0:
        northing += FALSE_NORTHING
        hemisphere = "S"

    return round(easting, 2), round(northing, 2), zone, hemisphere


def validate_latlon(latitude, longitude):
    """Raise a friendly error when a coordinate cannot exist."""
    try:
        latitude = float(latitude)
        longitude = float(longitude)
    except (TypeError, ValueError):
        raise CoordinateError("Latitude and longitude must be numbers.")

    if not -90 <= latitude <= 90:
        raise CoordinateError("Latitude must be between -90 and 90 degrees.")
    if not -180 <= longitude <= 180:
        raise CoordinateError("Longitude must be between -180 and 180 degrees.")
    return latitude, longitude


def resolve(record):
    """
    Work out a borehole's latitude/longitude from whatever the user supplied.

    Accepts a dict holding either latitude/longitude, or utm_easting /
    utm_northing / utm_zone / utm_hemisphere. Latitude and longitude win when
    both are present, since they need no conversion.

    Returns (latitude, longitude) or (None, None) when nothing usable is there.
    """
    latitude = record.get("latitude")
    longitude = record.get("longitude")

    if latitude not in (None, "") and longitude not in (None, ""):
        return validate_latlon(latitude, longitude)

    easting = record.get("utm_easting")
    northing = record.get("utm_northing")
    zone = record.get("utm_zone")

    if easting not in (None, "") and northing not in (None, "") and zone not in (None, ""):
        return utm_to_latlon(
            easting, northing, zone, record.get("utm_hemisphere") or "N"
        )

    return (None, None)
