"""
app.py — Geochemistry Sample Management Program
Senior Project, Geoscience Program, Mahidol University.

Run it:
    pip install -r requirements.txt
    python app.py
then open http://127.0.0.1:5000 in a browser.

Three pages:
    /collection   Page 1 — enter, import, and edit samples and boreholes
    /analysis     Page 2 — browse, filter and review saved samples
    /map          Page 3 — borehole map, core column, depth vs CEC step plot
"""

from __future__ import annotations

import io
import json
import os
import re
import uuid

from flask import (
    Flask,
    abort,
    jsonify,
    render_template,
    request,
    send_file,
    send_from_directory,
)
from werkzeug.utils import secure_filename

import coords
import database
import geochem
import numpy as np

import clay_id
import importer
import xrd
import xrd_data

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".pdf"}
TABLE_EXTENSIONS = {".csv", ".xlsx", ".xlsm", ".xls"}
MAX_UPLOAD_BYTES = 32 * 1024 * 1024

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_BYTES
app.config["UPLOAD_FOLDER"] = UPLOAD_DIR

# Never let the browser cache the program's own CSS and JavaScript. Without
# this a browser can keep showing an old version of a page for hours after
# the file on disk has changed, which looks exactly like a bug that was not
# fixed. The cost is nothing: the files are served from this same computer.
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0


@app.after_request
def no_cache_static(response):
    if request.path.startswith("/static/"):
        response.headers["Cache-Control"] = "no-store, max-age=0"
    return response

os.makedirs(UPLOAD_DIR, exist_ok=True)
database.init_db()


# ==========================================================================
# Helpers
# ==========================================================================
def to_float(value):
    """Blank-tolerant float conversion — the form sends '' for empty inputs."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if text == "":
        return None
    try:
        return float(text)
    except ValueError:
        return None


def to_int(value):
    number = to_float(value)
    return int(number) if number is not None else None


def payload_of(req):
    """Read the JSON body, whether posted as JSON or inside a form field."""
    if req.is_json:
        return req.get_json(silent=True) or {}
    raw = req.form.get("payload")
    if not raw:
        return {}
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return {}


def clean_payload(payload: dict) -> dict:
    """Normalise whatever the browser posted into the shape the database wants."""
    cec_sets = []
    for raw in payload.get("cec_sets") or []:
        row = {key: to_float(raw.get(key))
               for key in ("trial1", "trial2", "trial3", "w_clay", "w_meb")}
        if any(value is not None for value in row.values()):
            cec_sets.append(row)

    minerals = []
    for raw in payload.get("minerals") or []:
        name = (raw.get("mineral") or "").strip()
        percent = to_float(raw.get("percent"))
        if name or percent is not None:
            minerals.append({
                "mineral": name,
                "percent": percent,
                "source": raw.get("source") or "manual",
                "confidence": to_float(raw.get("confidence")),
            })

    beds = []
    for raw in payload.get("lithology") or []:
        description = (raw.get("description") or "").strip()
        depth_from = to_float(raw.get("depth_from"))
        depth_to = to_float(raw.get("depth_to"))
        if description or depth_from is not None or depth_to is not None:
            beds.append({
                "depth_from": depth_from,
                "depth_to": depth_to,
                "description": description,
                "color": (raw.get("color") or "").strip(),
            })

    return {
        "sample_name": (payload.get("sample_name") or "").strip(),
        "area_code": (payload.get("area_code") or "").strip(),
        "borehole_code": (payload.get("borehole_code") or "").strip(),
        "depth_from": to_float(payload.get("depth_from")),
        "depth_to": to_float(payload.get("depth_to")),
        "mt_resistivity": to_float(payload.get("mt_resistivity")),
        "clay_type_override": (payload.get("clay_type_override") or "").strip(),
        "notes": (payload.get("notes") or "").strip(),
        "cec_imported": 1 if payload.get("cec_imported") else 0,
        "cec_from_file": to_float(payload.get("cec_from_file")),
        "import_batch": (payload.get("import_batch") or "").strip(),
        "cec_sets": cec_sets,
        "minerals": minerals,
        "lithology": beds,
    }


def validate(data: dict) -> list[str]:
    """Friendly, human-readable validation messages."""
    errors = []

    if not data["sample_name"]:
        errors.append("Please enter a Sample Name — for example D:2.00 or SS.4.")
    if not data["borehole_code"]:
        errors.append("Please enter a Borehole Code — for example BH_1.")

    depth_from, depth_to = data["depth_from"], data["depth_to"]
    if depth_from is not None and depth_from < 0:
        errors.append("Depth From cannot be a negative number.")
    if depth_to is not None and depth_to < 0:
        errors.append("Depth To cannot be a negative number.")
    if depth_from is not None and depth_to is not None and depth_to < depth_from:
        errors.append("Depth To must be deeper than (or equal to) Depth From.")

    for index, cec_set in enumerate(data["cec_sets"], start=1):
        label = f"Titration set {index}"
        trials = [cec_set["trial1"], cec_set["trial2"], cec_set["trial3"]]
        if any(value is not None and value < 0 for value in trials):
            errors.append(f"{label}: titration readings cannot be negative.")
        if cec_set["w_clay"] is not None and cec_set["w_clay"] <= 0:
            errors.append(f"{label}: W_clay must be greater than zero.")
        if cec_set["w_meb"] is not None and cec_set["w_meb"] < 0:
            errors.append(f"{label}: W_MeB cannot be a negative number.")
        if any(value is not None for value in trials):
            if cec_set["w_clay"] is None:
                errors.append(f"{label}: enter W_clay (g) so the CEC can be calculated.")
            if cec_set["w_meb"] is None:
                errors.append(f"{label}: enter W_MeB (g) so the CEC can be calculated.")

    for mineral in data["minerals"]:
        if mineral["percent"] is not None and not (0 <= mineral["percent"] <= 100):
            name = mineral["mineral"] or "unnamed mineral"
            errors.append(f"XRD percentage for “{name}” must be between 0 and 100.")

    for index, bed in enumerate(data["lithology"], start=1):
        if (bed["depth_from"] is not None and bed["depth_to"] is not None
                and bed["depth_to"] < bed["depth_from"]):
            errors.append(f"Lithology row {index}: Depth To is shallower than Depth From.")

    return errors


def save_upload(file_storage, allowed=IMAGE_EXTENSIONS, kind="XRD spectrum") -> str:
    """Store an uploaded file under a collision-proof name."""
    original = secure_filename(file_storage.filename or "")
    extension = os.path.splitext(original)[1].lower()
    if extension not in allowed:
        nice = ", ".join(sorted(allowed))
        raise ValueError(f"The {kind} file must be one of: {nice}")
    stored_name = f"{uuid.uuid4().hex}{extension}"
    file_storage.save(os.path.join(UPLOAD_DIR, stored_name))
    return stored_name


def remove_upload(filename: str | None) -> None:
    if not filename:
        return
    path = os.path.join(UPLOAD_DIR, os.path.basename(filename))
    if os.path.isfile(path):
        try:
            os.remove(path)
        except OSError:
            pass  # a leftover file is harmless; never break the request over it


def public_sample(sample: dict) -> dict:
    """A sample plus every derived value, ready for the browser."""
    enriched = geochem.enrich_sample(sample)

    # A CEC taken from an imported file still needs to drive the classification
    if enriched.get("average_cec") is None and sample.get("cec_from_file") is not None:
        enriched["average_cec"] = sample["cec_from_file"]
        matches = geochem.classify_clay(enriched["average_cec"])
        override = enriched.get("clay_type_override")
        enriched["clay_matches"] = matches
        enriched["clay_label"] = geochem.clay_label(matches, override)
        enriched["clay_names"] = geochem.clay_names(matches, override)

    enriched["cec_imported"] = bool(sample.get("cec_imported"))
    enriched["xrd_image_url"] = (
        f"/uploads/{sample['xrd_image']}" if sample.get("xrd_image") else None
    )
    enriched["xrd_image_is_pdf"] = bool(
        sample.get("xrd_image") and sample["xrd_image"].lower().endswith(".pdf")
    )
    enriched["clay_color"] = geochem.clay_color(
        (enriched.get("clay_names") or [geochem.NOT_CLASSIFIED])[0]
    )
    return enriched


def all_public_samples() -> list[dict]:
    return [public_sample(sample) for sample in database.list_samples()]


# ==========================================================================
# Pages
# ==========================================================================
@app.route("/")
def home():
    return render_template("collection.html", page="collection")


@app.route("/collection")
def collection():
    return render_template("collection.html", page="collection")


@app.route("/analysis")
def analysis():
    return render_template("analysis.html", page="analysis")


@app.route("/map")
def borehole_map():
    return render_template("map.html", page="map")


@app.route("/xrd")
def xrd_page():
    return render_template("xrd.html", page="xrd")


@app.route("/samples/<int:sample_id>/report")
def report(sample_id: int):
    """Printable one-page report — use the browser's Print dialog to save as PDF."""
    sample = database.get_sample(sample_id)
    if sample is None:
        abort(404)
    return render_template("report.html", sample=public_sample(sample), page="analysis")


@app.route("/boreholes/<code>/report")
def borehole_report(code: str):
    """Printable borehole report: column, transitions and sample table."""
    data = borehole_detail(code, request.args.get("area"))
    if data is None:
        abort(404)
    return render_template("borehole_report.html", borehole=data, page="map")


@app.route("/uploads/<path:filename>")
def uploads(filename: str):
    return send_from_directory(UPLOAD_DIR, filename)


# ==========================================================================
# Reference tables
# ==========================================================================
@app.get("/api/reference")
def api_reference():
    """Classification table and clay colours, so the pages never hard-code them."""
    return jsonify({
        "clay_ranges": [
            {"name": name, "code": code, "min": low, "max": high,
             "color": geochem.clay_color(name)}
            for (name, code, low, high) in geochem.CLAY_RANGES
        ],
        "not_classified": geochem.NOT_CLASSIFIED,
        "clay_colors": geochem.CLAY_COLORS,
        "meb_molecular_weight": geochem.MEB_MOLECULAR_WEIGHT,
        "import_fields": [
            {"field": key, "label": label}
            for key, label in importer.FIELD_LABELS.items()
        ],
    })


@app.get("/api/mineral-reference")
def api_get_mineral_reference():
    return jsonify(database.list_mineral_reference())


@app.post("/api/mineral-reference")
def api_set_mineral_reference():
    payload = payload_of(request)
    if payload.get("reset"):
        database.reset_mineral_reference()
        return jsonify({"message": "Reference table reset to the starting values.",
                        "rows": database.list_mineral_reference()})

    rows = []
    for raw in payload.get("rows") or []:
        name = (raw.get("mineral") or "").strip()
        if not name:
            continue
        rows.append({
            "mineral": name,
            "reflection": (raw.get("reflection") or "").strip(),
            "d_spacing": to_float(raw.get("d_spacing")),
            "two_theta": to_float(raw.get("two_theta")),
            "tolerance": to_float(raw.get("tolerance")),
            "rir": to_float(raw.get("rir")),
        })

    if not rows:
        return jsonify({"errors": ["Keep at least one mineral in the reference table."]}), 400

    database.replace_mineral_reference(rows)
    return jsonify({"message": "Reference table saved.",
                    "rows": database.list_mineral_reference()})


# ==========================================================================
# Samples
# ==========================================================================
@app.get("/api/samples")
def api_list_samples():
    return jsonify(all_public_samples())


@app.get("/api/samples/<int:sample_id>")
def api_get_sample(sample_id: int):
    sample = database.get_sample(sample_id)
    if sample is None:
        return jsonify({"error": "That sample could not be found."}), 404
    return jsonify(public_sample(sample))


@app.post("/api/samples")
def api_create_sample():
    return _save_sample(None)


@app.post("/api/samples/<int:sample_id>")
def api_update_sample(sample_id: int):
    return _save_sample(sample_id)


def _save_sample(sample_id: int | None):
    """
    Shared create/update handler.

    The browser posts multipart/form-data with a single JSON 'payload' field
    plus the optional image, so repeatable rows survive the round-trip intact.
    """
    payload = payload_of(request)
    if not payload:
        return jsonify({"errors": ["The form could not be read. Please try saving again."]}), 400

    data = clean_payload(payload)
    errors = validate(data)
    if errors:
        return jsonify({"errors": errors}), 400

    existing = database.get_sample(sample_id) if sample_id else None
    if sample_id and existing is None:
        return jsonify({"errors": ["That sample could not be found."]}), 404

    old_image = existing["xrd_image"] if existing else None
    data["xrd_image"] = old_image or ""

    upload = request.files.get("xrd_image")
    if upload and upload.filename:
        try:
            data["xrd_image"] = save_upload(upload)
        except ValueError as exc:
            return jsonify({"errors": [str(exc)]}), 400
        if old_image and old_image != data["xrd_image"]:
            remove_upload(old_image)
    elif payload.get("xrd_image_name"):
        # An image already uploaded through the XRD review screen
        data["xrd_image"] = os.path.basename(payload["xrd_image_name"])
        if old_image and old_image != data["xrd_image"]:
            remove_upload(old_image)
    elif payload.get("remove_image"):
        data["xrd_image"] = ""
        remove_upload(old_image)

    if sample_id:
        database.update_sample(sample_id, data)
        saved_id = sample_id
        message = f"Sample “{data['sample_name']}” was updated."
    else:
        saved_id = database.create_sample(data)
        message = f"Sample “{data['sample_name']}” was saved."

    scan = payload.get("xrd_scan")
    if scan and scan.get("curve"):
        database.save_xrd_scan(saved_id, scan, payload.get("xrd_peaks") or [])
    elif payload.get("remove_image") or payload.get("clear_xrd_scan"):
        database.clear_xrd_scan(saved_id)

    _ensure_borehole(data["borehole_code"], data["area_code"])

    saved = public_sample(database.get_sample(saved_id))
    warnings = [w for w in [saved.get("mineral_warning")] if w]
    if not _has_position(data["borehole_code"], data["area_code"]):
        warnings.append(
            f"Borehole {hole_label(data['area_code'], data['borehole_code'])} has no "
            f"coordinates yet, so it will not appear on the map. Add them in the "
            f"Borehole Information section."
        )

    return jsonify({"id": saved_id, "message": message, "warnings": warnings, "sample": saved})


@app.delete("/api/samples/<int:sample_id>")
def api_delete_sample(sample_id: int):
    found, image = database.delete_sample(sample_id)
    if not found:
        return jsonify({"error": "That sample could not be found."}), 404
    remove_upload(image)
    return jsonify({"message": "Sample deleted."})


@app.post("/api/samples/delete")
def api_delete_samples():
    """Delete several samples at once — the Analysis page's "Delete selected"."""
    payload = payload_of(request)
    ids = []
    for raw in payload.get("ids") or []:
        value = to_int(raw)
        if value is not None and value not in ids:
            ids.append(value)
    if not ids:
        return jsonify({"errors": ["No samples were selected."]}), 400

    deleted = missing = 0
    for sample_id in ids:
        found, image = database.delete_sample(sample_id)
        if found:
            deleted += 1
            remove_upload(image)
        else:
            missing += 1

    message = f"{deleted} sample{'' if deleted == 1 else 's'} deleted."
    if missing:
        message += f" {missing} could not be found (already deleted?)."
    return jsonify({"message": message, "deleted": deleted, "missing": missing})


@app.get("/api/samples/<int:sample_id>/xrd.csv")
def api_xrd_csv(sample_id: int):
    sample = database.get_sample(sample_id)
    if sample is None or not sample.get("xrd_scan"):
        abort(404)
    body = xrd.to_csv(sample["xrd_scan"]["curve"])
    return send_file(
        io.BytesIO(body.encode("utf-8")),
        mimetype="text/csv",
        as_attachment=True,
        download_name=f"{sample['sample_name'] or 'sample'}_xrd.csv",
    )


def hole_label(area_code, code) -> str:
    """'CRI1 BH_1', or just 'BH_1' when there is no area."""
    area = database.norm_area(area_code)
    return f"{area} {code}" if area else (code or "")


def _ensure_borehole(code: str, area_code: str) -> None:
    """Make sure every hole (area + code) named by a sample has a record to hold coordinates."""
    code = (code or "").strip()
    if not code:
        return
    if database.get_borehole(code, area_code or "", fallback=False) is None:
        database.save_borehole({"borehole_code": code, "area_code": area_code or "",
                                "utm_hemisphere": "N"})


def _has_position(code: str, area_code: str | None = None) -> bool:
    record = database.get_borehole(code, area_code)
    if not record:
        return False
    try:
        latitude, longitude = coords.resolve(record)
    except coords.CoordinateError:
        return False
    return latitude is not None and longitude is not None


# ==========================================================================
# Boreholes
# ==========================================================================
def borehole_rows() -> list[dict]:
    """
    Every hole, one row per area + borehole code, with its position resolved
    and its own samples summarised. BH_1 in CRI1 and BH_1 in PCMI2 are two rows.
    """
    samples = all_public_samples()
    by_hole = {}
    for sample in samples:
        key = (database.norm_area(sample.get("area_code")), (sample.get("borehole_code") or "").strip())
        by_hole.setdefault(key, []).append(sample)

    rows = []
    seen = set()
    for record in database.list_boreholes():
        code = record["borehole_code"]
        area = database.norm_area(record.get("area_code"))
        seen.add((area, code))
        row = dict(record)
        try:
            latitude, longitude = coords.resolve(record)
            row["coordinate_error"] = None
        except coords.CoordinateError as exc:
            latitude = longitude = None
            row["coordinate_error"] = str(exc)

        row["area_code"] = area
        row["label"] = hole_label(area, code)
        row["latitude_resolved"] = latitude
        row["longitude_resolved"] = longitude
        row["has_position"] = latitude is not None and longitude is not None
        row.update(geochem.borehole_summary(code, by_hole.get((area, code), [])))
        rows.append(row)

    # Holes named only by samples, with no record of their own yet
    for (area, code), group in by_hole.items():
        if not code or (area, code) in seen:
            continue
        row = {"borehole_code": code, "area_code": area, "label": hole_label(area, code),
               "latitude_resolved": None, "longitude_resolved": None,
               "has_position": False, "coordinate_error": None}
        row.update(geochem.borehole_summary(code, group))
        rows.append(row)

    rows.sort(key=lambda r: (r["area_code"] == "", _natural_key(r["area_code"]),
                             _natural_key(r["borehole_code"])))
    return rows


@app.get("/api/boreholes")
def api_list_boreholes():
    rows = borehole_rows()
    return jsonify({
        "boreholes": rows,
        "missing_coordinates": [r["label"] for r in rows if not r["has_position"]],
    })


@app.post("/api/boreholes")
def api_save_borehole():
    payload = payload_of(request)
    code = (payload.get("borehole_code") or "").strip()
    if not code:
        return jsonify({"errors": ["Please enter a Borehole Code, for example BH_1."]}), 400

    record = {
        "borehole_code": code,
        "area_code": database.norm_area(payload.get("area_code")),
        "latitude": to_float(payload.get("latitude")),
        "longitude": to_float(payload.get("longitude")),
        "utm_easting": to_float(payload.get("utm_easting")),
        "utm_northing": to_float(payload.get("utm_northing")),
        "utm_zone": to_int(payload.get("utm_zone")),
        "utm_hemisphere": (payload.get("utm_hemisphere") or "N").strip().upper()[:1] or "N",
        "ground_elevation": to_float(payload.get("ground_elevation")),
        "total_depth": to_float(payload.get("total_depth")),
        "notes": (payload.get("notes") or "").strip(),
    }

    try:
        latitude, longitude = coords.resolve(record)
    except coords.CoordinateError as exc:
        return jsonify({"errors": [str(exc)]}), 400

    database.save_borehole(record)
    message = f"Borehole {hole_label(record['area_code'], code)} saved."
    if latitude is None:
        message += " It has no coordinates yet, so it will not appear on the map."

    return jsonify({
        "message": message,
        "borehole_code": code,
        "latitude": latitude,
        "longitude": longitude,
        "boreholes": borehole_rows(),
    })


@app.delete("/api/boreholes/<code>")
def api_delete_borehole(code: str):
    """
    Remove a borehole's record. Its samples are untouched: deleting a map pin
    must never delete lab results.
    """
    area = request.args.get("area")          # which area's hole; omit for every area
    if not database.delete_borehole(code, area):
        return jsonify({"error": "That borehole could not be found."}), 404
    label = hole_label(area, code) if area is not None else code
    return jsonify({"message": f"Borehole {label} removed from the map. Its samples are "
                               f"still saved.", "boreholes": borehole_rows()})


@app.post("/api/boreholes/import")
def api_import_boreholes():
    upload = request.files.get("file")
    if not upload or not upload.filename:
        return jsonify({"errors": ["Please choose a file to import."]}), 400

    extension = os.path.splitext(upload.filename)[1].lower()
    if extension not in TABLE_EXTENSIONS:
        return jsonify({"errors": ["Borehole coordinates must be a .csv or .xlsx file."]}), 400

    try:
        parsed = importer.parse_borehole_file(
            upload.read(), upload.filename, request.form.get("sheet")
        )
    except importer.ImportError_ as exc:
        return jsonify({"errors": [str(exc)]}), 400

    saved, problems, placed = 0, [], []
    for row in parsed["rows"]:
        label = hole_label(row.get("area_code"), row["borehole_code"])
        try:
            latitude, _ = coords.resolve(row)
        except coords.CoordinateError as exc:
            problems.append(f"{label}: {exc}")
            continue
        database.save_borehole(row)
        saved += 1
        if latitude is not None:
            placed.append(label)

    # Holes that have samples but still no position after this import
    still_missing = [r["label"] for r in borehole_rows()
                     if r.get("sample_count") and not r["has_position"]]
    if still_missing:
        problems.append("Still no coordinates for: " + ", ".join(still_missing) +
                        ". Check the names and area codes in the file match the samples.")

    return jsonify({
        "message": f"{saved} borehole{'' if saved == 1 else 's'} imported"
                   f"{f', {len(placed)} placed on the map' if placed else ''}.",
        "warnings": problems,
        "boreholes": borehole_rows(),
    })


# ==========================================================================
# Map and stratigraphy
# ==========================================================================
def _same_area(sample: dict, area: str) -> bool:
    return (sample.get("area_code") or "").strip().upper() == (area or "").strip().upper()


def borehole_detail(code: str, area: str | None = None, everything: list | None = None):
    """
    Everything Page 3 needs for one borehole.

    The same borehole code can be reused in different areas (BH_2 in CRI1 and
    BH_2 in PCMI2 are different holes), so `area` narrows it down to one.
    `everything` lets a caller pass the sample list it already loaded.
    """
    pool = everything if everything is not None else all_public_samples()
    samples = [s for s in pool if s["borehole_code"] == code]
    if area is not None:
        samples = [s for s in samples if _same_area(s, area)]
    record = database.get_borehole(code, area)
    if record is None and not samples:
        return None

    beds = database.list_lithology(code, area)
    column = geochem.stratigraphic_column(samples, beds)

    detail = {
        "borehole_code": code,
        "record": dict(record) if record else None,
        "samples": geochem.sort_down_hole(samples),
        "column": column,
        "transitions": column["transitions"],
        "steps": geochem.step_plot_points(samples),
        "clay_colors": geochem.CLAY_COLORS,
    }
    detail.update(geochem.borehole_summary(code, samples))

    if record:
        try:
            latitude, longitude = coords.resolve(record)
        except coords.CoordinateError:
            latitude = longitude = None
        detail["latitude"] = latitude
        detail["longitude"] = longitude
        detail["ground_elevation"] = record["ground_elevation"]
        detail["total_depth"] = record["total_depth"]
        detail["area_code"] = record["area_code"]
    else:
        detail["latitude"] = detail["longitude"] = None
        detail["area_code"] = samples[0].get("area_code") if samples else ""

    if area is not None:
        detail["area_code"] = area
    return detail


@app.get("/api/map")
def api_map():
    rows = borehole_rows()
    return jsonify({
        "boreholes": rows,
        "positioned": [r for r in rows if r["has_position"]],
        "missing_coordinates": [r["label"] for r in rows if not r["has_position"]],
        "clay_colors": geochem.CLAY_COLORS,
        "clay_ranges": [
            {"name": name, "code": code, "min": low, "max": high,
             "color": geochem.clay_color(name)}
            for (name, code, low, high) in geochem.CLAY_RANGES
        ],
    })


def _natural_key(text: str):
    """BH_2 before BH_10."""
    return [int(part) if part.isdigit() else part.lower()
            for part in re.split(r"(\d+)", text or "")]


@app.get("/api/stratigraphy")
def api_stratigraphy():
    """
    Every hole, one per area + borehole code, never merged across areas.

    Numbered the way the report reads:
        1    CRI1          (area)
        1.1    BH_1        (borehole in that area)
        1.2    BH_2
        2    PCMI2
        2.1    BH_1
    """
    samples = all_public_samples()
    holes = {}
    for sample in samples:
        code = (sample.get("borehole_code") or "").strip()
        if not code:
            continue
        area = (sample.get("area_code") or "").strip().upper()
        holes.setdefault(area, set()).add(code)

    # Areas in order, blank area last
    area_order = sorted(holes, key=lambda a: (a == "", _natural_key(a)))

    areas = []
    for area_number, area in enumerate(area_order, start=1):
        boreholes = []
        for hole_number, code in enumerate(sorted(holes[area], key=_natural_key), start=1):
            detail = borehole_detail(code, area, everything=samples)
            if detail is None:
                continue
            boreholes.append({
                "number": f"{area_number}.{hole_number}",
                "borehole_code": code,
                "area_code": area,
                "detail": detail,
            })
        areas.append({"number": str(area_number), "area_code": area, "boreholes": boreholes})

    return jsonify({
        "areas": areas,
        "hole_count": sum(len(a["boreholes"]) for a in areas),
        "clay_colors": geochem.CLAY_COLORS,
        "clay_ranges": [
            {"name": name, "code": code, "min": low, "max": high,
             "color": geochem.clay_color(name)}
            for (name, code, low, high) in geochem.CLAY_RANGES
        ],
    })


@app.get("/api/boreholes/<code>/detail")
def api_borehole_detail(code: str):
    area = request.args.get("area")          # optional: one area's hole only
    detail = borehole_detail(code, area)
    if detail is None:
        return jsonify({"error": "That borehole could not be found."}), 404
    return jsonify(detail)


@app.get("/api/steps")
def api_steps():
    """Step-plot series for several boreholes at once, for the overlay."""
    codes = [c for c in (request.args.get("boreholes") or "").split(",") if c.strip()]
    samples = all_public_samples()
    if not codes:
        codes = sorted({s["borehole_code"] for s in samples if s["borehole_code"]})

    series = []
    for code in codes:
        group = [s for s in samples if s["borehole_code"] == code]
        if not group:
            continue
        series.append({
            "borehole_code": code,
            "steps": geochem.step_plot_points(group),
            "samples": geochem.sort_down_hole(group),
            "transitions": geochem.clay_transitions(group),
        })

    return jsonify({"series": series, "clay_colors": geochem.CLAY_COLORS})


# ==========================================================================
# Bulk import
# ==========================================================================
@app.post("/api/import/sheets")
def api_import_sheets():
    upload = request.files.get("file")
    if not upload or not upload.filename:
        return jsonify({"errors": ["Please choose a file."]}), 400
    try:
        return jsonify({"sheets": importer.list_sheets(upload.read(), upload.filename)})
    except importer.ImportError_ as exc:
        return jsonify({"errors": [str(exc)]}), 400


@app.post("/api/import/inspect")
def api_import_inspect():
    """
    Read a lab file and return everything the review screen needs.

    Nothing is saved here. The browser keeps the preview and posts the rows it
    wants back to /api/import/commit.
    """
    upload = request.files.get("file")
    if not upload or not upload.filename:
        return jsonify({"errors": ["Please choose a file to import."]}), 400

    extension = os.path.splitext(upload.filename)[1].lower()
    if extension not in TABLE_EXTENSIONS:
        return jsonify({"errors": [
            "The lab results file must be .csv, .xlsx or .xls. "
            "If you have an old .xls file, open it in Excel and save it as .xlsx."
        ]}), 400

    data = upload.read()
    sheet = request.form.get("sheet") or None
    overrides = {}
    raw_overrides = request.form.get("mapping")
    if raw_overrides:
        try:
            overrides = {k: v for k, v in json.loads(raw_overrides).items()}
        except json.JSONDecodeError:
            overrides = {}

    try:
        sheets = importer.list_sheets(data, upload.filename)
        grid = importer.read_grid(data, upload.filename, sheet)
    except importer.ImportError_ as exc:
        return jsonify({"errors": [str(exc)]}), 400

    if not grid:
        return jsonify({"errors": ["That file appears to be empty."]}), 400

    structure = importer.detect_structure(grid)
    mapping = importer.map_columns(structure["header_row"], overrides)

    connection = database.get_connection()
    try:
        def lookup(borehole, name, depth_from, area_code=None):
            return database.find_duplicate(borehole, name, depth_from, area_code,
                                           conn=connection)
        preview = importer.build_preview(
            grid, structure, mapping, lookup,
            sheet_name=sheet or (sheets[0] if sheets else None),
            default_area=request.form.get("default_area") or "",
        )
    finally:
        connection.close()
    preview["default_area"] = (request.form.get("default_area") or "").strip().upper()

    preview["sheets"] = sheets
    preview["sheet"] = sheet
    preview["filename"] = upload.filename
    preview["needs_mapping"] = "sample_name" not in mapping
    preview["grid_preview"] = grid[:12]
    return jsonify(preview)


@app.post("/api/import/commit")
def api_import_commit():
    """Save the rows the user approved on the review screen."""
    payload = payload_of(request)
    rows = payload.get("rows") or []
    policy = (payload.get("duplicate_policy") or "skip").lower()
    batch = uuid.uuid4().hex[:8]

    if not rows:
        return jsonify({"errors": ["There is nothing to import."]}), 400

    created = updated = skipped = 0
    boreholes = set()
    areas = set()
    holes = set()
    connection = database.get_connection()

    try:
        for row in rows:
            if row.get("action") == "skip":
                skipped += 1
                continue

            name = (row.get("sample_name") or "").strip()
            if not name:
                skipped += 1
                continue

            borehole = (row.get("borehole_code") or "").strip()
            area_code = (row.get("area_code") or "").strip().upper()
            depth_from = to_float(row.get("depth_from"))
            boreholes.add(borehole)
            areas.add(area_code)
            holes.add((area_code, borehole))

            trials = {key: to_float(row.get(key)) for key in ("trial1", "trial2", "trial3")}
            w_clay = to_float(row.get("w_clay"))
            w_meb = to_float(row.get("w_meb"))
            cec_sets = []
            if any(value is not None for value in trials.values()) or w_clay or w_meb:
                cec_sets.append({**trials, "w_clay": w_clay, "w_meb": w_meb})

            data = {
                "sample_name": name,
                "area_code": area_code,
                "borehole_code": borehole,
                "depth_from": depth_from,
                "depth_to": to_float(row.get("depth_to")),
                "mt_resistivity": to_float(row.get("mt_resistivity")),
                "clay_type_override": "",
                "xrd_image": "",
                "notes": "",
                "cec_imported": 1 if row.get("cec_imported") else 0,
                "cec_from_file": to_float(row.get("cec_file")),
                "import_batch": batch,
                "cec_sets": cec_sets,
                "minerals": [],
                "lithology": [],
            }

            existing = database.find_duplicate(borehole, name, depth_from, area_code,
                                               conn=connection)
            if existing:
                if policy == "skip":
                    skipped += 1
                    continue
                if policy == "overwrite":
                    database.update_sample(existing["id"], data, conn=connection)
                    updated += 1
                    continue
                # "keep both" falls through to a plain insert

            database.create_sample(data, conn=connection)
            created += 1

        connection.commit()
    finally:
        connection.close()

    for area_code, code in sorted(h for h in holes if h[1]):
        _ensure_borehole(code, area_code)

    without_position = [hole_label(area_code, code) for area_code, code in sorted(holes)
                        if code and not _has_position(code, area_code)]

    parts = []
    if created:
        parts.append(f"{created} sample{'' if created == 1 else 's'} imported")
    if updated:
        parts.append(f"{updated} updated")
    if skipped:
        parts.append(f"{skipped} skipped")
    summary = ", ".join(parts) if parts else "Nothing was imported"
    hole_count = len([c for c in boreholes if c])
    summary += f", {hole_count} borehole code{'' if hole_count == 1 else 's'}"
    named_areas = sorted(a for a in areas if a)
    if named_areas:
        summary += f" in area{'' if len(named_areas) == 1 else 's'} {', '.join(named_areas)}"
    summary += "."

    warnings = []
    if without_position:
        warnings.append(
            "No coordinates yet for " + ", ".join(without_position) +
            ". Add them in Borehole Information so they appear on the map."
        )

    return jsonify({
        "message": summary,
        "created": created, "updated": updated, "skipped": skipped,
        "batch": batch,
        "warnings": warnings,
        "missing_coordinates": without_position,
    })


@app.get("/api/import/template.xlsx")
def api_import_template():
    try:
        data = importer.build_template_xlsx()
    except importer.ImportError_ as exc:
        return jsonify({"errors": [str(exc)]}), 400
    return send_file(
        io.BytesIO(data),
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="Lab results template.xlsx",
    )


@app.get("/api/export.xlsx")
def api_export():
    """Everything in the database, back out as a workbook."""
    try:
        import openpyxl
    except ImportError:
        return jsonify({"errors": ["Exporting needs openpyxl. Run: pip install -r requirements.txt"]}), 400

    from openpyxl.styles import Font

    samples = all_public_samples()
    book = openpyxl.Workbook()

    sheet = book.active
    sheet.title = "Samples"
    headers = ["Sample Name", "Area Code", "Borehole Code", "Depth From (m)", "Depth To (m)",
               "Depth", "V_MeB (ml)", "W_clay (g)", "W_MeB (g)", "CEC (meq/100g)",
               "Average CEC", "CEC source", "Type of Clay Mineral",
               "DC Resistivity (Ohm.m)", "Notes"]
    sheet.append(headers)
    for cell in sheet[1]:
        cell.font = Font(bold=True)

    for sample in samples:
        first = (sample.get("cec_sets") or [{}])[0]
        sheet.append([
            sample["sample_name"], sample["area_code"], sample["borehole_code"],
            sample["depth_from"], sample["depth_to"], sample["depth_display"],
            first.get("v_meb"), first.get("w_clay"), first.get("w_meb"), first.get("cec"),
            sample.get("average_cec"),
            "imported from file" if sample.get("cec_imported") else "calculated",
            ", ".join(sample.get("clay_names") or []),
            sample.get("mt_resistivity"), sample.get("notes"),
        ])

    minerals = book.create_sheet("XRD minerals")
    minerals.append(["Sample Name", "Borehole Code", "Mineral", "Percent", "Source", "Confidence"])
    for cell in minerals[1]:
        cell.font = Font(bold=True)
    for sample in samples:
        for mineral in sample.get("minerals") or []:
            minerals.append([sample["sample_name"], sample["borehole_code"],
                             mineral.get("mineral"), mineral.get("percent"),
                             mineral.get("source"), mineral.get("confidence")])

    holes = book.create_sheet("Boreholes")
    holes.append(["Borehole Code", "Area Code", "Latitude", "Longitude", "UTM Easting",
                  "UTM Northing", "Zone", "Hemisphere", "Ground Elevation (m)",
                  "Total Depth (m)", "Samples", "Average CEC", "Dominant Clay"])
    for cell in holes[1]:
        cell.font = Font(bold=True)
    for row in borehole_rows():
        holes.append([row["borehole_code"], row.get("area_code"),
                      row.get("latitude_resolved"), row.get("longitude_resolved"),
                      row.get("utm_easting"), row.get("utm_northing"), row.get("utm_zone"),
                      row.get("utm_hemisphere"), row.get("ground_elevation"),
                      row.get("total_depth"), row.get("sample_count"),
                      row.get("average_cec"), row.get("dominant_clay")])

    for worksheet in book.worksheets:
        for column_cells in worksheet.columns:
            width = max((len(str(cell.value or "")) for cell in column_cells), default=10)
            letter = openpyxl.utils.get_column_letter(column_cells[0].column)
            worksheet.column_dimensions[letter].width = min(max(width + 2, 10), 42)

    buffer = io.BytesIO()
    book.save(buffer)
    buffer.seek(0)
    return send_file(
        buffer,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name="Geochemistry data.xlsx",
    )


# ==========================================================================
# XRD image reading
# ==========================================================================
@app.post("/api/xrd/upload")
def api_xrd_upload():
    """Store the image and suggest where the plot area is."""
    upload = request.files.get("image")
    if not upload or not upload.filename:
        return jsonify({"errors": ["Please choose an XRD image."]}), 400

    try:
        stored = save_upload(upload, {".png", ".jpg", ".jpeg"}, "XRD")
    except ValueError:
        return jsonify({"errors": [
            "Automatic reading works on .png and .jpg images. A PDF can still be "
            "attached to the sample, but it cannot be digitised."
        ]}), 400

    path = os.path.join(UPLOAD_DIR, stored)
    try:
        image = xrd.load_image(path)
        box = xrd.guess_plot_box(image)
    except Exception as exc:                        # noqa: BLE001 - user-facing message
        remove_upload(stored)
        return jsonify({"errors": [f"That image could not be opened: {exc}"]}), 400

    return jsonify({
        "filename": stored,
        "url": f"/uploads/{stored}",
        "width": image.width,
        "height": image.height,
        "plot_box": box,
        "reference": database.list_mineral_reference(),
    })


@app.post("/api/xrd/analyse")
def api_xrd_analyse():
    payload = payload_of(request)
    filename = os.path.basename(payload.get("filename") or "")
    path = os.path.join(UPLOAD_DIR, filename)

    if not filename or not os.path.isfile(path):
        return jsonify({"errors": ["Please upload the XRD image again."]}), 400

    reference = payload.get("reference") or database.list_mineral_reference()

    try:
        result = xrd.analyse(
            path,
            payload.get("calibration"),
            payload.get("plot_box"),
            reference,
            wavelength=to_float(payload.get("wavelength")) or xrd.DEFAULT_WAVELENGTH,
            background=payload.get("background") or "light",
            smooth_window=int(to_float(payload.get("smooth_window")) or 9),
            min_prominence_ratio=to_float(payload.get("sensitivity")) or 0.05,
        )
    except xrd.XRDError as exc:
        return jsonify({"errors": [str(exc)]}), 400
    except Exception as exc:                        # noqa: BLE001 - user-facing message
        return jsonify({"errors": [f"The image could not be analysed: {exc}"]}), 400

    return jsonify(result)


@app.post("/api/xrd/reidentify")
def api_xrd_reidentify():
    """
    Re-run only the matching step after the user edited the peaks.

    Keeps the digitised curve untouched, so moving one peak never re-reads the
    whole image.
    """
    payload = payload_of(request)
    peaks = payload.get("peaks") or []
    wavelength = to_float(payload.get("wavelength")) or xrd.DEFAULT_WAVELENGTH
    reference = payload.get("reference") or database.list_mineral_reference()

    cleaned = []
    for peak in peaks:
        position = to_float(peak.get("two_theta"))
        if position is None:
            continue
        cleaned.append({
            "two_theta": position,
            "intensity": to_float(peak.get("intensity")) or 0.0,
            "area": to_float(peak.get("area")) or 0.0,
            "width": to_float(peak.get("width")) or 0.0,
            "edited": bool(peak.get("edited")),
        })

    identified = xrd.identify(cleaned, reference, wavelength)

    # A mineral the user typed in by hand always wins over the lookup
    for original, result in zip(peaks, identified):
        if original.get("mineral_locked") and original.get("mineral"):
            result["mineral"] = original["mineral"]
            result["confidence"] = None
            result["mineral_locked"] = True

    estimates = xrd.flag_low_confidence(xrd.estimate_percentages(identified))
    return jsonify({
        "peaks": identified,
        "estimates": estimates,
        "note": ("These percentages are estimated from a picture of the pattern. "
                 "They are a guide only and do not replace proper quantitative "
                 "XRD refinement."),
    })


# ==========================================================================
# Measured XRD patterns (.jas / .chi) — the XRD page
# ==========================================================================
@app.get("/api/xrd-patterns")
def api_list_xrd_patterns():
    """Every imported pattern; ?data=1 includes the measured arrays."""
    with_data = request.args.get("data") in ("1", "true", "yes")
    return jsonify({
        "patterns": database.list_xrd_patterns(with_data=with_data),
        "cu_wavelength": xrd_data.CU_KALPHA,
        "reference_wavelength": xrd_data.REFERENCE_WAVELENGTH,
    })


@app.post("/api/xrd-patterns/import")
def api_import_xrd_patterns():
    """
    Bulk import: any number of .jas and .chi files in one go.

    Files are paired by name (Sample_A_00001.jas + Sample_A_00001.chi), and a
    file whose name says capillary / empty / blank is marked as the capillary.
    Re-importing a name replaces that pattern.
    """
    uploads = [f for f in request.files.getlist("files") if f and f.filename]
    if not uploads:
        return jsonify({"errors": ["Please choose the .jas and .chi files to import."]}), 400

    files = [(secure_filename(f.filename) or f.filename, f.read()) for f in uploads]
    patterns, problems = xrd_data.read_upload_set(files)
    if not patterns:
        return jsonify({"errors": problems or ["No XRD patterns could be read from those files."]}), 400

    added, replaced = [], []
    for pattern in patterns:
        _, was_replaced = database.save_xrd_pattern(pattern)
        (replaced if was_replaced else added).append(pattern["name"])
        for note in pattern["notes"]:
            problems.append(f"{pattern['name']}: {note}")

    capillaries = [p["name"] for p in database.list_xrd_patterns() if p["role"] == "capillary"]
    if not capillaries:
        problems.append("No capillary pattern yet, so nothing is subtracted. Import the capillary "
                        "file (its name should contain 'capillary'), or mark one as the capillary "
                        "in the table.")

    parts = []
    if added:
        parts.append(f"{len(added)} pattern{'' if len(added) == 1 else 's'} imported")
    if replaced:
        parts.append(f"{len(replaced)} updated")
    return jsonify({
        "message": (", ".join(parts) or "Nothing imported") + f" from {len(files)} file"
                   f"{'' if len(files) == 1 else 's'}.",
        "warnings": problems,
        "added": added,
        "replaced": replaced,
        "patterns": database.list_xrd_patterns(with_data=True),
    })


@app.post("/api/xrd-patterns/<int:pattern_id>")
def api_update_xrd_pattern(pattern_id: int):
    payload = payload_of(request)
    role = payload.get("role")
    if role not in (None, "sample", "capillary"):
        return jsonify({"errors": ["Role must be sample or capillary."]}), 400
    treatment = payload.get("treatment")
    if treatment not in (None, "", "AD", "EG", "H400", "H550"):
        return jsonify({"errors": ["Treatment must be AD, EG, H400 or H550."]}), 400
    try:
        changed = database.update_xrd_pattern(
            pattern_id, role=role, name=payload.get("name"),
            sample_group=payload.get("sample_group"), treatment=treatment)
    except Exception:                                  # noqa: BLE001 - duplicate name
        return jsonify({"errors": ["Another pattern already has that name."]}), 400
    if not changed:
        return jsonify({"errors": ["That pattern could not be found."]}), 404
    return jsonify({"message": "Saved.", "patterns": database.list_xrd_patterns()})


@app.get("/api/xrd-identify")
def api_xrd_identify():
    """
    Identify the clay minerals of one sample from its four treatments.

        ?sample=<sample name>   which sample (all its patterns are used)
        &capillary=<id>         subtract this capillary first (optional)
        &intensity=bgsub|raw    column 4 (default) or column 5

    The capillary is subtracted exactly as on the graph: its intensity is
    interpolated onto each pattern's 2θ (1 Å) points, then taken away.
    """
    group = request.args.get("sample") or ""
    patterns = [p for p in database.get_xrd_patterns(sample_group=group) if p["role"] == "sample"]
    if not patterns:
        return jsonify({"errors": [f"No patterns for sample “{group}”."]}), 404

    key = "raw" if request.args.get("intensity") == "raw" else "bgsub"
    sensitivity = min(max(to_float(request.args.get("sensitivity")) or 0.03, 0.005), 0.3)
    capillary = None
    cap_id = to_int(request.args.get("capillary"))
    if cap_id is not None:
        found = database.get_xrd_patterns(ids=[cap_id])
        capillary = found[0] if found else None

    by_treatment, used, notes = {}, {}, []
    for pattern in patterns:
        treatment = pattern["treatment"] or "AD"
        if not pattern["treatment"]:
            notes.append(f"{pattern['name']}: treatment not set, read as air-dried.")
        if treatment in by_treatment:
            notes.append(f"{pattern['name']}: a second {clay_id.TREATMENT_LABELS[treatment]} "
                         f"pattern; only {used[treatment]} is used.")
            continue

        data = pattern["data"]
        values = data.get(key) or data.get("raw")
        x = np.array(data["x1a"], dtype=float)
        y = np.array([np.nan if v is None else v for v in values], dtype=float)
        cap_values = capillary and (capillary["data"].get(key) or None)
        if cap_values:
            cx = np.array(capillary["data"]["x1a"], dtype=float)
            cy = np.array([np.nan if v is None else v for v in cap_values], dtype=float)
            y = y - np.interp(x, cx, cy, left=np.nan, right=np.nan)

        by_treatment[treatment] = clay_id.find_peaks(x, y, min_relative=sensitivity)
        used[treatment] = pattern["name"]

    result = clay_id.identify(by_treatment)
    result["notes"] = notes + result["notes"]
    if capillary is None:
        result["notes"].insert(0, "No capillary subtracted: weak peaks from the glass capillary "
                                  "may be mixed in.")
    result["peaks"] = by_treatment
    result["patterns"] = used
    result["treatments"] = [{"code": c, "label": l} for c, l in clay_id.TREATMENTS]
    return jsonify(result)


@app.post("/api/xrd-patterns/delete")
def api_delete_xrd_patterns():
    payload = payload_of(request)
    ids = [i for i in (to_int(v) for v in payload.get("ids") or []) if i is not None]
    if not ids:
        return jsonify({"errors": ["No patterns were selected."]}), 400
    count = database.delete_xrd_patterns(ids)
    return jsonify({"message": f"{count} pattern{'' if count == 1 else 's'} deleted.",
                    "patterns": database.list_xrd_patterns()})


@app.errorhandler(413)
def too_large(_error):
    return jsonify({"errors": ["That file is too large. Please keep uploads under 32 MB."]}), 413


@app.errorhandler(404)
def not_found(error):
    if request.path.startswith("/api/"):
        return jsonify({"error": "Not found."}), 404
    return error.get_response()


if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
