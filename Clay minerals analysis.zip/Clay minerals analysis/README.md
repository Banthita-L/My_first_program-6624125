# Geochemistry Sample Management Program

Senior Project, Geoscience Program, Mahidol University.

A web application for recording, importing and interpreting geochemistry data
from borehole samples: methylene-blue (AFNOR) titration, cation exchange
capacity, clay mineral classification, XRD composition read from spectrum
images, DC resistivity, and the stratigraphy of each hole.

Three pages:

| Page | Address | What it is for |
|---|---|---|
| Data Collection | `/collection` | Type a sample, import a lab file, record borehole positions |
| Analysis | `/analysis` | Browse, search, sort and review saved samples |
| Map & Stratigraphy | `/map` | Borehole map, core column, clay transitions, depth vs CEC |

---

## Running it

```bash
pip install -r requirements.txt
python app.py
```

Then open **http://127.0.0.1:5000**, or double-click
**Start Geochemistry Program.bat**.

Everything persists between sessions: samples go into `instance/geochem.db`
(SQLite), and uploaded spectrum images into `static/uploads/`. To start over,
delete the `instance` folder.

**Upgrading from the first version is safe.** The program adds the new tables
and columns to an existing database on startup and never drops anything, so
samples entered with the old version are still there.

### What gets installed

| Package | Why |
|---|---|
| Flask | the web server |
| openpyxl | reading and writing .xlsx files |
| numpy | the XRD peak maths |
| Pillow | reading the XRD image |

No internet connection is needed to run the program. Leaflet is bundled in
`static/vendor/`, so the map works offline; only the map *tiles* (the
background picture) need the internet, and the borehole markers still appear
without them.

---

## Page 1 — Data Collection

### Manual entry

CEC is calculated as you type:

```
CEC (meq/100 g) = (100 / W_clay) × V_MeB × (W_MeB / 320)
```

- **V_MeB** is the average of whichever titration readings were entered. A
  blank reading is ignored rather than counted as zero.
- **W_clay** is the weight of the clay/soil sample powder (g).
- **W_MeB** is the weight of methylene blue powder used (g).
- **320** is the molecular weight of methylene blue.

A sample can hold more than one titration set; **Average of CEC** is that one
set's value when there is only one, and the mean across sets when there are
several.

**Lithology rows** are optional. When filled in, they draw the bed names
beside the core column on the Map page.

### Bulk import

Drop in the lab results file (.csv or .xlsx). The program reads the layout
your lab actually uses: a title row with the area name and sample count,
then a borehole code on its own row, a column header row, and the sample rows
underneath, repeating for each borehole. Two-line headers are handled, so the
bare `1 2 3` under a merged "Titration (ml.)" cell are treated as part of the
header rather than as a sample.

Before anything is saved you get a preview with every problem highlighted:
missing values, text where a number should be, depths that run backwards,
samples already in the database, and any row where the file's CEC disagrees
with the recalculated value.

The example lab file has no W_clay or W_MeB columns. Those rows keep the CEC
from the file and are marked **"imported, not recalculated"**; fill in the two
weights later and the program recalculates with the formula.

Duplicates can be skipped, overwritten, or kept alongside the originals.
**Download blank template** gives you an .xlsx in the expected shape.

### XRD reading from an image

Upload a .png or .jpg of the diffractogram and press **Read this image**.

1. **Calibrate** — click two points on the x axis and type their 2θ values,
   then two on the y axis with their intensities. The plot area is detected
   automatically from the axis lines.
2. **Review** — the program digitises the curve, subtracts the background,
   finds the peaks, converts each to a d-spacing with Bragg's law
   (`d = λ / 2sinθ`), and matches them against the mineral reference table.
   Peaks can be added by clicking the image, removed, or renamed. The
   estimated percentages fill the mineral rows when you press Accept.

The reference table is editable, and the X-ray source can be changed (Cu, Co,
Fe or Mo Kα); changing it moves every expected angle correctly.

> **Read this before using the percentages in your report.** They are
> estimated from a picture of a plot: peak areas divided by a reference
> intensity ratio, normalised to 100 %. That is a guide, not a quantification,
> and it does not replace Rietveld or RIR refinement on the raw data. The
> program says so on screen next to every result.
>
> One limit worth knowing: the low-angle clay reflections sit very close
> together. Chlorite (001, ~14 Å, 6.3°) and air-dried smectite (~12-15 Å,
> ~6.5°) often merge into a single peak that no peak-finder can separate.
> When a peak falls inside two windows the program says **"could also be…"**
> rather than quietly picking one. Separating those two properly needs
> glycolation or heating, not better software.

The digitised curve is stored with the sample and can be downloaded as CSV.

### Borehole information

The map needs a position for each hole. Type latitude and longitude, or UTM
easting/northing with a zone and the program converts it (Chiang Mai is zone
47N). Positions can also be imported from a one-row-per-borehole file. A
borehole record is created automatically whenever a new code appears, so the
app can tell you which holes still need coordinates.

Deleting a borehole removes its map position only. Its samples are never
touched.

---

## Page 2 — Analysis

All samples grouped by borehole, with search, filters and click-to-sort on any
column. Clicking a sample name opens a read-only pop-up grouped into General
Info, AFNOR/CEC, Clay Mineralogy, Resistivity and XRD Composition, including
the spectrum image (click to zoom), the digitised pattern with its peaks
marked, and the mineral breakdown. **Export as PDF** opens a printable report.

---

## Page 3 — Map & Stratigraphy

Markers for every borehole with coordinates, coloured either by dominant clay
mineral or by average CEC, on a street or satellite base map.

Clicking a marker opens that hole:

- **Core column** — each sample interval filled with the colour of its clay
  mineral type, with lithology names beside it where they exist.
- **Clay mineral transitions** — wherever the type changes between one sample
  and the next. The exact depth is not knowable: the change happens somewhere
  between the bottom of the upper sample and the top of the lower one, so the
  program gives the range (`12.45 – 15 m`) as well as the midpoint
  (`about 13.7 m`), on the column and in a table.
- **Depth vs CEC step plot** — each sample holds its value across its own
  interval and then steps. No smooth lines are drawn between samples, because
  nothing is known about what happens between them. The clay mineral CEC
  ranges are shaded behind it, and other boreholes can be overlaid for
  comparison. **Save step plot as PNG** exports it.

Both drawings share one depth scale so they line up side by side.

---

## What each file does

```
app.py                     Flask routes, validation, uploads
geochem.py                 CEC, classification, transitions, step plot   (no I/O)
importer.py                CSV/XLSX structure detection and validation   (no I/O)
xrd.py                     Image digitising, peak finding, identification (no I/O)
coords.py                  UTM <-> latitude/longitude                     (no I/O)
database.py                SQLite schema, migrations and queries
templates/
  base.html                Layout and the three-page navigation
  collection.html          Page 1, with its three tabs and the XRD screen
  analysis.html            Page 2
  map.html                 Page 3
  report.html              Printable single-sample report
  borehole_report.html     Printable borehole report
static/
  css/style.css            All styling, light and dark, desktop and tablet
  js/common.js             Shared helpers
  js/collection.js         The sample form and live CEC calculation
  js/import.js             The bulk import screen
  js/boreholes.js          Borehole records and coordinates
  js/xrd-review.js         The two-step XRD reading screen
  js/analysis.js           Filtering, sorting, deleting
  js/sample-detail.js      The sample pop-up, shared by pages 2 and 3
  js/charts.js             The two summary charts on page 2
  js/strat.js              Core column and step plot drawing
  js/map.js                The map and the borehole panel
  vendor/                  Leaflet, bundled so the map works offline
tests/                     The test suite
instance/geochem.db        Created on first run
static/uploads/            Uploaded XRD images
```

The four calculation modules have no Flask or database code in them, so they
can be tested, read and cited on their own.

---

## Clay mineral classification

| Alteration mineral | CEC range (meq/100 g) |
|---|---|
| Kaolinite (Kln) | 2 – 10 |
| Smectite (Sme) | 80 – 150 |
| Illite (Ilt) | 20 – 30 |
| Chlorite (Chl) | 20 – 30 |
| Vermiculite (Vrm) | 100 – 150 |
| Mixed-layer (Mix) | 3 – 100 |

Ranges overlap on purpose, so a sample can match several minerals and all
matches are shown. Nothing matching shows **None-classified**. A manual
override always wins.

> **One thing worth checking.** In the example table in the requirements,
> samples D:15.00 (CEC 13.31) and D:18.00 (CEC 12.15) are listed as
> "Kln, Mix", but both sit above Kaolinite's stated range of 2 – 10, so the
> table can only return Mixed-layer. The program follows the classification
> table. If Kaolinite should extend past 10 meq/100 g, change its range in
> `CLAY_RANGES` at the top of `geochem.py`; if those two rows were hand-typed,
> the manual override covers them.

---

## Running the tests

```bash
python tests/run_all.py
```

or, with pytest installed:

```bash
python -m pytest tests -q
```

Three files, 54 tests:

- `test_geochem.py` reproduces all nine lab rows from the requirements
  (W_clay = 0.9 g, W_MeB = 10 g), plus blank trials, division-by-zero
  protection, overlapping ranges and inclusive boundaries.
- `test_importer.py` covers the file structure detection, two-line headers,
  the Thai title row, column matching, depth and number parsing, duplicates,
  encodings, and every validation message.
- `test_strat_coords_xrd.py` covers the transition ranges, the step plot
  (including a check that it never invents a slope between samples), the UTM
  conversion round-trip to the millimetre, Bragg's law against the reference
  table, peak finding on a known signal, background removal, and the
  confidence and percentage maths.
