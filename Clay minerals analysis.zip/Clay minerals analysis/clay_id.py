"""
clay_id.py — automatic clay mineral identification from oriented XRD patterns.

One sample is measured four ways, the standard clay preparation:

    AD    air-dried
    EG    ethylene glycol solvated
    H400  heated to 400 °C
    H550  heated to 550 °C

Each clay mineral's basal (00l) reflection responds to those treatments in
its own way, which is how they are told apart (Moore & Reynolds, 1997,
"X-ray Diffraction and the Identification and Analysis of Clay Minerals"):

    Smectite      12–15 Å air-dried, swells to ~17 Å with glycol, collapses
                  to ~10 Å on heating
    Vermiculite   ~14.4 Å, does not swell with glycol, collapses to ~10 Å
                  at 400 °C
    Chlorite      14.2 Å (with 7.1, 4.7, 3.54 Å), unchanged by glycol, the
                  14 Å peak survives 550 °C
    Illite        10 Å (with 5.0, 3.33 Å), unchanged by every treatment
    Kaolinite     7.15 Å (with 3.58 Å), unchanged by glycol, destroyed at
                  550 °C
    Mixed-layer   illite/smectite: a peak between 10 and 17 Å that moves
                  only part of the way when glycolated

The d(060) reflection then says whether the clay is dioctahedral or
trioctahedral (Table 7.4, after Bailey 1980 and Brindley 1980).

Everything here works in d-spacing (Å), so it does not matter which
wavelength the 2θ axis was recorded at.

These are rules of thumb that a clay mineralogist applies by eye. The
result is a well-founded suggestion, shown with its evidence, not a
replacement for the analyst's judgement.
"""

from __future__ import annotations

import math
import re

import numpy as np

# --------------------------------------------------------------------------
# Treatments
# --------------------------------------------------------------------------
TREATMENTS = [
    ("AD", "Air-dried"),
    ("EG", "Ethylene glycol"),
    ("H400", "Heated 400 °C"),
    ("H550", "Heated 550 °C"),
]
TREATMENT_LABELS = dict(TREATMENTS)
TREATMENT_ORDER = {code: index for index, (code, _) in enumerate(TREATMENTS)}

_SEP = r"(?:^|(?<=[\s_\-.()\[\]]))"
_END = r"(?=$|[\s_\-.()\[\]])"
TREATMENT_PATTERNS = [
    ("EG", re.compile(_SEP + r"(?:eg|egs|glycol(?:ated)?|ethylene[\s_\-]*glycol|ethyleneglycol|gly)" + _END, re.I)),
    ("H550", re.compile(_SEP + r"(?:h|heat(?:ed)?|t)?[\s_\-]*550(?:\s*°?\s*c|degc|deg)?" + _END, re.I)),
    ("H400", re.compile(_SEP + r"(?:h|heat(?:ed)?|t)?[\s_\-]*400(?:\s*°?\s*c|degc|deg)?" + _END, re.I)),
    ("AD", re.compile(_SEP + r"(?:ad|air[\s_\-]*dried|airdried|air|untreated|nat(?:ural)?)" + _END, re.I)),
]


def detect_treatment(name: str) -> tuple[str, str]:
    """
    Split a pattern name into (sample, treatment code).

        'BH1_2m_AD'        -> ('BH1_2m', 'AD')
        'BH1_2m_EG'        -> ('BH1_2m', 'EG')
        'BH1 2m heat550'   -> ('BH1 2m', 'H550')
        'Sample_OMWCNT_1'  -> ('Sample_OMWCNT_1', '')     no treatment in the name
    """
    text = (name or "").strip()
    for code, pattern in TREATMENT_PATTERNS:
        match = pattern.search(text)
        if match:
            sample = (text[:match.start()] + " " + text[match.end():])
            sample = re.sub(r"[\s_\-.]+", "_", sample).strip("_ -.")
            return (sample or text), code
    return text, ""


# --------------------------------------------------------------------------
# Bragg's law
# --------------------------------------------------------------------------
def d_from_two_theta(two_theta, wavelength=1.0):
    two_theta = np.asarray(two_theta, dtype=float)
    sine = np.sin(np.radians(two_theta / 2))
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(sine > 0, wavelength / (2 * sine), np.inf)


def two_theta_from_d(d, wavelength=1.0):
    ratio = wavelength / (2 * float(d))
    if not 0 < ratio <= 1:
        return None
    return math.degrees(2 * math.asin(ratio))


# --------------------------------------------------------------------------
# Peak finding
# --------------------------------------------------------------------------
D_MIN, D_MAX = 1.40, 20.0       # Å: from the 060 region up to glycolated smectite


def _smooth(values, window=7):
    if window < 3 or len(values) < window:
        return np.asarray(values, dtype=float)
    padded = np.pad(values, window // 2, mode="edge")
    return np.convolve(padded, np.ones(window) / window, mode="valid")


def _prominence(y, index):
    """True topographic prominence: how far the peak stands above the higher of
    the lowest points on each side, before reaching higher ground or the edge."""
    peak = y[index]
    left = index - 1
    left_min = peak
    while left >= 0 and y[left] <= peak:
        left_min = min(left_min, y[left])
        left -= 1
    right = index + 1
    right_min = peak
    while right < len(y) and y[right] <= peak:
        right_min = min(right_min, y[right])
        right += 1
    return peak - max(left_min, right_min)


def find_peaks(two_theta_1a, intensity, min_relative=0.03, min_separation=0.12):
    """
    Peaks in a pattern recorded at λ = 1 Å, returned with their d-spacing.

    min_relative    a peak must rise at least this fraction of the strongest
                    peak above its surroundings (and well clear of the noise)
    min_separation  degrees 2θ (1 Å); closer peaks are merged into the taller
    """
    x = np.asarray(two_theta_1a, dtype=float)
    y_raw = np.asarray(intensity, dtype=float)
    finite = np.isfinite(x) & np.isfinite(y_raw)
    x, y_raw = x[finite], y_raw[finite]
    if x.size < 10:
        return []

    d = d_from_two_theta(x)
    window = (d >= D_MIN) & (d <= D_MAX)
    if window.sum() < 10:
        return []
    x, y_raw, d = x[window], y_raw[window], d[window]

    y = _smooth(y_raw, 7)
    noise = 1.4826 * float(np.median(np.abs(y_raw - y))) or 1e-9
    span = float(np.max(y) - np.min(y)) or 1e-9

    candidates = []
    for i in range(1, y.size - 1):
        if y[i] >= y[i - 1] and y[i] > y[i + 1]:
            prominence = _prominence(y, i)
            candidates.append((i, prominence))
    if not candidates:
        return []

    strongest = max(p for _, p in candidates)
    threshold = max(min_relative * strongest, 5 * noise, 0.002 * span)
    kept = []
    for i, prominence in sorted(candidates, key=lambda c: -c[1]):
        if prominence < threshold:
            break
        if any(abs(x[i] - x[j]) < min_separation for j, _ in kept):
            continue
        kept.append((i, prominence))

    peaks = []
    for i, prominence in sorted(kept, key=lambda c: x[c[0]]):
        peaks.append({
            "d": round(float(d[i]), 3),
            "two_theta_1a": round(float(x[i]), 3),
            "intensity": round(float(y[i]), 2),
            "prominence": round(float(prominence), 2),
            "relative": round(100 * prominence / strongest, 1),
        })
    return peaks


# --------------------------------------------------------------------------
# d(060): Table 7.4 (Moore & Reynolds), after Bailey (1980) and Brindley (1980)
# --------------------------------------------------------------------------
D060_TABLE = [
    # mineral, d(060) low, high (Å), 2θ Cu Kα as printed in the table
    ("Kaolinite",          1.490, 1.490, "62.31"),
    ("Montmorillonite",    1.492, 1.504, "62.22–61.67"),
    ("Illite (Muscovite)", 1.499, 1.499, "61.90"),
    ("Glauconite",         1.511, 1.511, "61.35"),
    ("Saponite",           1.520, 1.520, "60.95"),
    ("Nontronite",         1.521, 1.521, "60.91"),
    ("Hectorite",          1.530, 1.530, "60.51"),
    ("Serpentines",        1.531, 1.538, "60.47–60.16"),
    ("Biotite",            1.538, 1.538, "60.16"),
    ("Chlorites",          1.538, 1.549, "60.16–59.69"),
    ("Sepiolite",          1.540, 1.550, "60.07–59.65"),
    ("Vermiculite",        1.541, 1.541, "60.03"),
    ("Berthierine",        1.555, 1.555, "59.44"),
    ("Palygorskite",       1.560, 1.560, "59.23"),
]
D060_TOLERANCE = 0.004   # Å either side of the table value
D060_SOURCE = ("Table 7.4, d(060) of micas and clay minerals (Moore & Reynolds 1997); "
               "data from Bailey (1980), smectites from Brindley (1980).")


def match_d060(d_value: float) -> dict:
    matches = []
    for name, low, high, two_theta in D060_TABLE:
        if low - D060_TOLERANCE <= d_value <= high + D060_TOLERANCE:
            centre = (low + high) / 2
            matches.append({
                "mineral": name,
                "d060": f"{low:.3f}" if low == high else f"{low:.3f}–{high:.3f}",
                "two_theta_cu": two_theta,
                "difference": round(abs(d_value - centre), 4),
            })
    matches.sort(key=lambda m: m["difference"])
    if d_value <= 1.507:
        octahedral = "dioctahedral"
    elif d_value >= 1.515:
        octahedral = "trioctahedral"
    else:
        octahedral = "between dioctahedral and trioctahedral"
    return {"d": round(d_value, 4), "octahedral": octahedral, "matches": matches}


# --------------------------------------------------------------------------
# The identification rules
# --------------------------------------------------------------------------
class _Peaks:
    """Peaks per treatment, with a lookup by d-spacing window."""

    def __init__(self, by_treatment: dict[str, list[dict]]):
        self.by = by_treatment
        self.have = {t for t, peaks in by_treatment.items() if peaks is not None}

    def find(self, treatment, low, high, min_relative=2.0):
        """The strongest peak of `treatment` with low <= d <= high, or None."""
        best = None
        for peak in self.by.get(treatment) or []:
            if low <= peak["d"] <= high and peak["relative"] >= min_relative:
                if best is None or peak["prominence"] > best["prominence"]:
                    best = peak
        return best


def _fmt(peak):
    return f"{peak['d']:.2f} Å" if peak else "—"


def identify(by_treatment: dict[str, list[dict]]) -> dict:
    """
    Name the clay minerals from the peaks of each treatment.

    `by_treatment` maps 'AD' / 'EG' / 'H400' / 'H550' to that pattern's peaks
    (from find_peaks); a treatment that was not measured is simply left out.

    Returns {'minerals': [...], 'd060': {...} or None, 'notes': [...]}. Each
    mineral carries a status ('identified' or 'possible'), the evidence in
    words, and the peaks to mark on the graph.
    """
    p = _Peaks(by_treatment)
    have = p.have
    minerals = []
    notes = []

    missing = [TREATMENT_LABELS[t] for t, _ in TREATMENTS if t not in have]
    if missing:
        notes.append("Not measured: " + ", ".join(missing) + ". Minerals that need those "
                     "treatments to be told apart are shown as 'possible'.")

    def add(name, code, status, evidence, marks, clay=True):
        minerals.append({"mineral": name, "code": code, "status": status, "clay": clay,
                         "evidence": evidence,
                         "marks": [{"treatment": t, "d": pk["d"], "label": f"{code} {pk['d']:.2f}"}
                                   for t, pk in marks if pk]})

    # ---- Smectite: swells to ~17 Å with glycol --------------------------------
    sme_ad = p.find("AD", 12.0, 15.6)
    sme_eg = p.find("EG", 16.3, 18.0)
    sme_hot = p.find("H400", 9.6, 10.3) or p.find("H550", 9.6, 10.3)
    if sme_eg:
        evidence = [f"Ethylene glycol: {_fmt(sme_eg)} (smectite swells to ~17 Å)"]
        if sme_ad:
            evidence.insert(0, f"Air-dried: {_fmt(sme_ad)}")
        if sme_hot:
            evidence.append(f"Heated: collapses to {_fmt(sme_hot)}")
        add("Smectite", "Sme", "identified", evidence,
            [("AD", sme_ad), ("EG", sme_eg), ("H400", p.find("H400", 9.6, 10.3))])
    elif sme_ad and "EG" not in have:
        add("Smectite", "Sme", "possible",
            [f"Air-dried: {_fmt(sme_ad)}", "Needs the ethylene glycol pattern: smectite would move to ~17 Å"],
            [("AD", sme_ad)])

    # ---- 14 Å minerals: chlorite or vermiculite ------------------------------
    c14_ad = p.find("AD", 13.6, 14.9)
    c14_eg = p.find("EG", 13.6, 14.9)
    c14_400 = p.find("H400", 13.6, 14.6)
    c14_550 = p.find("H550", 13.6, 14.6)
    c10_400 = p.find("H400", 9.6, 10.4)
    fourteen = c14_ad or c14_eg
    # An air-dried 14 Å peak that is gone with glycol, while a 17 Å peak has
    # appeared, was smectite: there is no separate 14 Å mineral.
    if fourteen and "EG" in have and sme_eg and not c14_eg:
        fourteen = None
    if fourteen:
        chl_extra = [pk for pk in (p.find("AD", 7.03, 7.13), p.find("AD", 4.70, 4.76),
                                   p.find("AD", 3.52, 3.555)) if pk]
        if c14_550:
            evidence = [f"14 Å peak: {_fmt(fourteen)}",
                        f"Heated 550 °C: still {_fmt(c14_550)} (chlorite survives heating)"]
            if c14_eg:
                evidence.append(f"Ethylene glycol: unchanged at {_fmt(c14_eg)}")
            if chl_extra:
                evidence.append("Higher orders: " + ", ".join(_fmt(pk) for pk in chl_extra))
            add("Chlorite", "Chl", "identified", evidence,
                [("AD", c14_ad), ("EG", c14_eg), ("H550", c14_550)])
        elif "H400" in have and not c14_400 and c10_400 and (c14_eg or "EG" not in have):
            add("Vermiculite", "Vrm", "identified",
                [f"14 Å peak: {_fmt(fourteen)}",
                 f"Ethylene glycol: {'stays at ' + _fmt(c14_eg) if c14_eg else 'not measured'} (no swelling)",
                 f"Heated 400 °C: collapses to {_fmt(c10_400)}"],
                [("AD", c14_ad), ("EG", c14_eg), ("H400", c10_400)])
        elif "H550" in have and not c14_550 and "H400" in have and not c14_400:
            add("Vermiculite", "Vrm", "possible",
                [f"14 Å peak: {_fmt(fourteen)}", "Gone after heating, but no clear 10 Å peak at 400 °C"],
                [("AD", c14_ad), ("EG", c14_eg)])
        else:
            reason =("Heat to 550 °C: chlorite's 14 Å peak survives, vermiculite's collapses to 10 Å"
                      if "H550" not in have and "H400" not in have else
                      "The heated patterns do not settle it")
            add("Chlorite or vermiculite", "Chl/Vrm", "possible",
                [f"14 Å peak: {_fmt(fourteen)}"] +
                ([f"Ethylene glycol: unchanged at {_fmt(c14_eg)}"] if c14_eg else []) + [reason],
                [("AD", c14_ad), ("EG", c14_eg)])

    # ---- Illite: 10 Å, unchanged by glycol -----------------------------------
    ill_ad = p.find("AD", 9.85, 10.2)
    ill_eg = p.find("EG", 9.85, 10.2)
    ill_002 = p.find("AD", 4.96, 5.04) or p.find("EG", 4.96, 5.04)
    if ill_ad and ill_eg:
        evidence = [f"Air-dried: {_fmt(ill_ad)}", f"Ethylene glycol: unchanged at {_fmt(ill_eg)}"]
        if ill_002:
            evidence.append(f"Second order: {_fmt(ill_002)}")
        add("Illite", "Ilt", "identified", evidence, [("AD", ill_ad), ("EG", ill_eg)])
    elif (ill_ad or ill_eg) and "EG" not in have:
        add("Illite", "Ilt", "possible",
            [f"10 Å peak: {_fmt(ill_ad or ill_eg)}"] +
            ([f"Second order: {_fmt(ill_002)}"] if ill_002 else []) +
            ["Needs the ethylene glycol pattern to rule out mixed-layer illite/smectite"],
            [("AD", ill_ad), ("EG", ill_eg)])

    # ---- Kaolinite: 7.15 Å, destroyed at 550 °C -------------------------------
    kln_ad = p.find("AD", 7.08, 7.25) or p.find("EG", 7.08, 7.25)
    kln_002 = p.find("AD", 3.56, 3.60) or p.find("EG", 3.56, 3.60)
    chl_004 = p.find("AD", 3.52, 3.555) or p.find("EG", 3.52, 3.555)
    seven_550 = p.find("H550", 7.0, 7.25)
    if kln_ad:
        if "H550" in have and not seven_550:
            evidence = [f"7 Å peak: {_fmt(kln_ad)}", "Heated 550 °C: gone (kaolinite is destroyed)"]
            if kln_002:
                evidence.append(f"3.58 Å (002): {_fmt(kln_002)}")
            add("Kaolinite", "Kln", "identified", evidence,
                [("AD", p.find("AD", 7.08, 7.25)), ("EG", p.find("EG", 7.08, 7.25))])
        elif kln_002 and not chl_004:
            add("Kaolinite", "Kln", "identified" if "H550" not in have or not seven_550 else "possible",
                [f"7 Å peak: {_fmt(kln_ad)}", f"3.58 Å (002): {_fmt(kln_002)}, not chlorite's 3.54 Å"] +
                ([f"Heated 550 °C: a 7 Å peak remains ({_fmt(seven_550)}), so chlorite may also be present"]
                 if seven_550 else []),
                [("AD", p.find("AD", 7.08, 7.25)), ("EG", p.find("EG", 7.08, 7.25)), ("AD", kln_002)])
        elif not any(m["code"] == "Chl" for m in minerals) or not seven_550:
            add("Kaolinite", "Kln", "possible",
                [f"7 Å peak: {_fmt(kln_ad)}",
                 "Could be chlorite's 002 reflection: heat to 550 °C (kaolinite disappears) "
                 "or check 3.58 Å (kaolinite) against 3.54 Å (chlorite)"],
                [("AD", p.find("AD", 7.08, 7.25))])

    # ---- Mixed-layer illite/smectite ----------------------------------------
    mix_eg = p.find("EG", 10.4, 16.2)
    explained = mix_eg and any(abs(mix_eg["d"] - m["d"]) < 0.3
                               for mineral in minerals for m in mineral["marks"])
    if mix_eg and not explained:
        mix_ad = p.find("AD", 10.2, 12.5)
        add("Mixed-layer illite/smectite", "I/S", "possible",
            ([f"Air-dried: {_fmt(mix_ad)}"] if mix_ad else []) +
            [f"Ethylene glycol: {_fmt(mix_eg)}, between illite (10 Å) and smectite (17 Å)"],
            [("AD", mix_ad), ("EG", mix_eg)])

    # ---- Quartz (not a clay, but nearly always there) -----------------------
    for t in ("AD", "EG", "H400", "H550"):
        qz1 = p.find(t, 4.24, 4.28, 1.0)
        qz2 = p.find(t, 3.33, 3.35, 1.0)
        if qz1 and qz2:
            add("Quartz", "Qz", "identified",
                [f"{TREATMENT_LABELS[t]}: {_fmt(qz1)} and {_fmt(qz2)}, unchanged by any treatment"],
                [(t, qz1), (t, qz2)], clay=False)
            break

    # ---- d(060) ------------------------------------------------------------
    d060 = None
    for t in ("AD", "EG", "H400", "H550"):
        peak = p.find(t, 1.47, 1.575, 0.5)
        if peak:
            d060 = match_d060(peak["d"])
            d060["treatment"] = TREATMENT_LABELS[t]
            d060["peak"] = peak
            d060["source"] = D060_SOURCE
            break
    if d060 is None:
        notes.append("No d(060) peak found near 1.49–1.56 Å, so dioctahedral and trioctahedral "
                     "clays cannot be told apart. Oriented mounts often hide it; a random powder "
                     "shows it best.")

    if not minerals:
        notes.append("No clay mineral reflections were recognised.")

    order = {"identified": 0, "possible": 1}
    minerals.sort(key=lambda m: (order[m["status"]], not m["clay"]))
    return {"minerals": minerals, "d060": d060, "notes": notes}
