"""
xrd.py — Reading an XRD pattern out of a picture.

The input is a PNG or JPG of a diffractogram: a plot of intensity against
2-theta. The output is a list of numbers, a list of peaks, and a rough
estimate of how much of each mineral is present.

The pipeline:

  1. CALIBRATE   the user clicks two points of known value on each axis, so
                 pixels can be converted into 2-theta and intensity
  2. DIGITISE    for every pixel column inside the plot, find the curve and
                 read off its height
  3. BASELINE    estimate and subtract the slowly-varying background
  4. PEAKS       find local maxima that stand far enough above the noise
  5. IDENTIFY    convert each peak to a d-spacing with Bragg's law and match
                 it against the editable mineral reference table
  6. ESTIMATE    turn matched peak areas into percentages, normalised to 100

Everything here is a numerical estimate taken from a picture of a plot. It is
not a Rietveld or reference-intensity-ratio quantification, and the app says
so next to the result. The user reviews and edits every number before it is
saved.

Only Pillow and NumPy are needed; both install with pip on any platform.
"""

from __future__ import annotations

import math

import numpy as np
from PIL import Image

# NumPy renamed trapz to trapezoid in version 2. Support both so the program
# runs on whatever NumPy the user already has.
_integrate = getattr(np, "trapezoid", None) or np.trapz

# Cu K-alpha, the usual laboratory source
DEFAULT_WAVELENGTH = 1.5406      # angstroms

MAX_IMAGE_EDGE = 2400            # downscale anything bigger, for speed


class XRDError(ValueError):
    """Raised when an image cannot be read as a diffractogram."""


# ==========================================================================
# 1. Calibration
# ==========================================================================
class AxisCalibration:
    """
    Maps pixels to data values, from two known points per axis.

    The user clicks a point on the x axis whose 2-theta they know, then a
    second one; same for the y axis with intensity. Two points define the
    straight line, which is all a linear axis needs.
    """

    def __init__(self, x_points, y_points, plot_box=None):
        self.x_points = self._clean(x_points, "x")
        self.y_points = self._clean(y_points, "y")
        self.plot_box = plot_box

    @staticmethod
    def _clean(points, axis):
        if not points or len(points) < 2:
            raise XRDError(
                f"Please click two points on the {axis} axis and type the value of each."
            )
        cleaned = []
        for point in points[:2]:
            try:
                cleaned.append((float(point["pixel"]), float(point["value"])))
            except (KeyError, TypeError, ValueError):
                raise XRDError(
                    f"Each {axis} axis point needs a position on the image and a value."
                )
        if abs(cleaned[0][0] - cleaned[1][0]) < 1e-6:
            raise XRDError(
                f"The two {axis} axis points are at the same place on the image. "
                f"Please click two different positions."
            )
        if abs(cleaned[0][1] - cleaned[1][1]) < 1e-9:
            raise XRDError(
                f"The two {axis} axis points have the same value. "
                f"Please use two different values."
            )
        return cleaned

    def x_to_value(self, pixel):
        (p0, v0), (p1, v1) = self.x_points
        return v0 + (pixel - p0) * (v1 - v0) / (p1 - p0)

    def y_to_value(self, pixel):
        (p0, v0), (p1, v1) = self.y_points
        return v0 + (pixel - p0) * (v1 - v0) / (p1 - p0)

    def to_dict(self):
        return {
            "x_points": [{"pixel": p, "value": v} for p, v in self.x_points],
            "y_points": [{"pixel": p, "value": v} for p, v in self.y_points],
            "plot_box": self.plot_box,
        }

    @classmethod
    def from_dict(cls, data):
        data = data or {}
        return cls(data.get("x_points"), data.get("y_points"), data.get("plot_box"))


# ==========================================================================
# 2. Digitising the curve
# ==========================================================================
def load_image(path):
    image = Image.open(path)
    image = image.convert("RGB")
    if max(image.size) > MAX_IMAGE_EDGE:
        scale = MAX_IMAGE_EDGE / max(image.size)
        image = image.resize(
            (max(1, int(image.width * scale)), max(1, int(image.height * scale))),
            Image.LANCZOS,
        )
    return image


def guess_plot_box(image):
    """
    A first guess at the rectangle holding the plot.

    Axes are near-black lines running most of the way across the image, so
    they are found by looking for rows and columns that are almost entirely
    ink. The test has to be strict: a pale gridline covers just as many
    pixels as an axis, and only its darkness tells the two apart.

    Each edge is looked for in its own half of the image, and any edge that
    is not found (many plots have no top or right border) falls back to a
    sensible inset on its own. Detected edges are then nudged inwards so the
    axis line itself is not mistaken for the curve.
    """
    grey = np.asarray(image.convert("L"), dtype=np.float32)
    height, width = grey.shape

    median = float(np.median(grey))
    if median >= 128:                       # dark ink on a light plot
        ink = grey < max(median - 60.0, 40.0)
    else:                                   # light ink on a dark plot
        ink = grey > min(median + 60.0, 215.0)

    column_score = ink.sum(axis=0) / height
    row_score = ink.sum(axis=1) / width

    def find(scores, lo, hi, minimum=0.30):
        """The strongest line inside a band, if any line is strong enough."""
        window = scores[lo:hi]
        if window.size == 0:
            return None
        index = int(np.argmax(window))
        return (lo + index) if window[index] >= minimum else None

    left = find(column_score, 0, max(int(width * 0.4), 1))
    right = find(column_score, int(width * 0.6), width)
    top = find(row_score, 0, max(int(height * 0.4), 1))
    bottom = find(row_score, int(height * 0.6), height)

    inset = 2
    left = int(width * 0.10) if left is None else left + inset
    top = int(height * 0.05) if top is None else top + inset
    right = int(width * 0.97) if right is None else right - inset
    bottom = int(height * 0.88) if bottom is None else bottom - inset

    # Anything degenerate falls back to a plain inset rather than failing
    if right - left < width * 0.25 or bottom - top < height * 0.25:
        left, top = int(width * 0.10), int(height * 0.05)
        right, bottom = int(width * 0.97), int(height * 0.88)

    return {"left": int(left), "top": int(top), "right": int(right), "bottom": int(bottom)}


def digitise(image, calibration, plot_box=None, background="light"):
    """
    Read the curve out of the plot area, one pixel column at a time.

    Returns a list of [two_theta, intensity] pairs, left to right.

    For each column the darkest run of pixels is taken to be the trace, and
    its topmost edge is the curve height. Taking the top edge rather than the
    middle matters: a thick line would otherwise bias every peak downwards.
    """
    box = plot_box or calibration.plot_box or guess_plot_box(image)
    left, top = int(box["left"]), int(box["top"])
    right, bottom = int(box["right"]), int(box["bottom"])

    if right - left < 10 or bottom - top < 10:
        raise XRDError(
            "The plot area is too small to read. Please drag the box around the "
            "plot itself, inside the axes."
        )

    pixels = np.asarray(image.convert("L"), dtype=np.float32)
    region = pixels[top:bottom + 1, left:right + 1]

    # Ink is dark on a light plot; invert when the plot is white-on-black
    ink = (255.0 - region) if background == "light" else region
    ink = ink - np.median(ink)
    ink[ink < 0] = 0.0

    threshold = max(ink.max() * 0.22, ink.std() * 1.5, 1.0)

    points = []
    last_row = None
    for column in range(ink.shape[1]):
        rows = np.flatnonzero(ink[:, column] > threshold)
        if rows.size == 0:
            continue

        # When the column holds several marks (gridline plus curve), take the
        # run closest to the previous column's curve, which keeps the trace
        # continuous across gridlines.
        runs = _split_runs(rows)
        if last_row is None:
            chosen = min(runs, key=lambda run: run[0])
        else:
            chosen = min(runs, key=lambda run: abs(run[0] - last_row))
        last_row = chosen[0]

        x_pixel = left + column
        y_pixel = top + chosen[0]
        points.append([
            round(float(calibration.x_to_value(x_pixel)), 4),
            round(float(calibration.y_to_value(y_pixel)), 4),
        ])

    if len(points) < 20:
        raise XRDError(
            "Almost no curve was found inside the plot area. Check that the box "
            "covers the plot, and that the pattern is a dark line on a light "
            "background."
        )

    points.sort(key=lambda p: p[0])
    return _dedupe_x(points)


def _split_runs(rows):
    """Group consecutive row indices into runs of touching pixels."""
    runs = []
    start = previous = rows[0]
    for row in rows[1:]:
        if row - previous > 2:
            runs.append((int(start), int(previous)))
            start = row
        previous = row
    runs.append((int(start), int(previous)))
    return runs


def _dedupe_x(points):
    """Average duplicate x values so the curve is a proper function."""
    out = []
    for x, y in points:
        if out and abs(out[-1][0] - x) < 1e-9:
            out[-1][1] = (out[-1][1] + y) / 2
        else:
            out.append([x, y])
    return out


# ==========================================================================
# 3. Smoothing and background
# ==========================================================================
def smooth(values, window=9):
    """Moving average, with the window shrunk at the two ends."""
    values = np.asarray(values, dtype=np.float64)
    if window < 3 or values.size < window:
        return values
    if window % 2 == 0:
        window += 1

    padded = np.pad(values, window // 2, mode="edge")
    kernel = np.ones(window) / window
    return np.convolve(padded, kernel, mode="valid")


def estimate_background(values, window=None):
    """
    A slowly-varying baseline, found by rolling minimum then rolling mean.

    This is the "rolling ball" idea in its simplest form: the background can
    never rise above the data, and it cannot follow a sharp peak because the
    window is far wider than any peak.
    """
    values = np.asarray(values, dtype=np.float64)
    if values.size < 5:
        return np.zeros_like(values)

    window = window or max(9, int(values.size * 0.08) | 1)
    half = window // 2
    padded = np.pad(values, half, mode="edge")

    minima = np.empty_like(values)
    for index in range(values.size):
        minima[index] = padded[index:index + window].min()

    return smooth(minima, window)


def prepare_curve(points, smooth_window=9):
    """
    Take raw digitised points to a clean, background-subtracted signal.

    Returns (two_theta, corrected_intensity, background).
    """
    array = np.asarray(points, dtype=np.float64)
    if array.ndim != 2 or array.shape[0] < 10:
        raise XRDError("The digitised curve is too short to analyse.")

    two_theta = array[:, 0]
    intensity = smooth(array[:, 1], smooth_window)
    background = estimate_background(intensity)

    corrected = intensity - background
    corrected[corrected < 0] = 0.0
    return two_theta, corrected, background


# ==========================================================================
# 4. Peak detection
# ==========================================================================
def find_peaks(two_theta, intensity, min_prominence_ratio=0.05, min_separation=0.25):
    """
    Local maxima that stand clearly above their surroundings.

    `min_prominence_ratio` is a fraction of the tallest peak, so the setting
    means the same thing whatever the counts scale happens to be.
    `min_separation` is in degrees 2-theta, which stops one broad clay
    reflection being reported as three peaks.

    Each peak gets an area, integrated out to where it falls back to the
    baseline, because area is a better measure of abundance than height for
    the broad reflections clays give.
    """
    two_theta = np.asarray(two_theta, dtype=np.float64)
    intensity = np.asarray(intensity, dtype=np.float64)
    if intensity.size < 5 or intensity.max() <= 0:
        return []

    threshold = intensity.max() * min_prominence_ratio
    candidates = []

    for index in range(1, intensity.size - 1):
        if intensity[index] < threshold:
            continue
        if intensity[index] >= intensity[index - 1] and intensity[index] > intensity[index + 1]:
            prominence = _prominence(intensity, index)
            if prominence >= threshold:
                candidates.append((index, prominence))

    candidates.sort(key=lambda item: -intensity[item[0]])

    kept = []
    for index, prominence in candidates:
        position = two_theta[index]
        if any(abs(position - two_theta[other]) < min_separation for other, _ in kept):
            continue
        kept.append((index, prominence))

    peaks = []
    for index, prominence in sorted(kept, key=lambda item: two_theta[item[0]]):
        left, right = _peak_limits(intensity, index)
        area = float(_integrate(intensity[left:right + 1], two_theta[left:right + 1]))
        peaks.append({
            "two_theta": round(float(two_theta[index]), 3),
            "intensity": round(float(intensity[index]), 3),
            "prominence": round(float(prominence), 3),
            "area": round(abs(area), 3),
            "width": round(abs(float(two_theta[right] - two_theta[left])), 3),
        })

    return peaks


def _prominence(intensity, index):
    """How far a peak stands above the higher of the two valleys beside it."""
    peak = intensity[index]

    left = index
    left_min = peak
    while left > 0 and intensity[left - 1] <= intensity[left]:
        left -= 1
        left_min = min(left_min, intensity[left])

    right = index
    right_min = peak
    while right < intensity.size - 1 and intensity[right + 1] <= intensity[right]:
        right += 1
        right_min = min(right_min, intensity[right])

    return peak - max(left_min, right_min)


def _peak_limits(intensity, index, floor_ratio=0.1):
    """Where a peak meets the baseline on each side."""
    floor = intensity[index] * floor_ratio

    left = index
    while left > 0 and intensity[left - 1] < intensity[left] and intensity[left] > floor:
        left -= 1

    right = index
    while (right < intensity.size - 1 and intensity[right + 1] < intensity[right]
           and intensity[right] > floor):
        right += 1

    return left, right


# ==========================================================================
# 5. Mineral identification
# ==========================================================================
def d_spacing(two_theta, wavelength=DEFAULT_WAVELENGTH):
    """
    Bragg's law: d = lambda / (2 sin(theta)).

    two_theta is in degrees. Returns None at or below zero, where the formula
    has no meaning.
    """
    try:
        theta = math.radians(float(two_theta) / 2.0)
    except (TypeError, ValueError):
        return None
    sine = math.sin(theta)
    if sine <= 1e-9:
        return None
    return wavelength / (2.0 * sine)


def two_theta_for_d(spacing, wavelength=DEFAULT_WAVELENGTH):
    """The inverse of Bragg's law, for drawing reference lines."""
    try:
        spacing = float(spacing)
    except (TypeError, ValueError):
        return None
    if spacing <= 0:
        return None
    ratio = wavelength / (2.0 * spacing)
    if not -1.0 <= ratio <= 1.0:
        return None
    return math.degrees(2.0 * math.asin(ratio))


def identify(peaks, reference, wavelength=DEFAULT_WAVELENGTH):
    """
    Attach a mineral name to each peak, where one matches.

    `reference` is the editable table: rows of mineral, d_spacing, two_theta
    and tolerance. A row's expected 2-theta is used when given, otherwise it
    is computed from the d-spacing and the chosen wavelength, so changing the
    wavelength moves the expected positions correctly.

    Confidence is 1.0 for a dead-on match and falls to 0 at the edge of the
    tolerance window, so the user can see which assignments are shaky.
    """
    expected = []
    for row in reference or []:
        name = (row.get("mineral") or "").strip()
        if not name:
            continue
        position = row.get("two_theta")
        if position in (None, ""):
            position = two_theta_for_d(row.get("d_spacing"), wavelength)
        elif abs(wavelength - DEFAULT_WAVELENGTH) > 1e-6 and row.get("d_spacing"):
            # The stored angle belongs to Cu K-alpha; recompute for this source
            position = two_theta_for_d(row.get("d_spacing"), wavelength)
        if position is None:
            continue
        expected.append({
            "mineral": name,
            "two_theta": float(position),
            "tolerance": float(row.get("tolerance") or 0.4),
            "rir": float(row.get("rir") or 1.0),
            "reflection": row.get("reflection") or "",
        })

    identified = []
    for peak in peaks:
        enriched = dict(peak)
        spacing = d_spacing(peak["two_theta"], wavelength)
        enriched["d_spacing"] = round(spacing, 4) if spacing else None
        enriched["mineral"] = ""
        enriched["confidence"] = None
        enriched["rir"] = 1.0
        enriched["alternatives"] = []

        scored = []
        for candidate in expected:
            gap = abs(peak["two_theta"] - candidate["two_theta"])
            if gap <= candidate["tolerance"]:
                scored.append((1.0 - (gap / candidate["tolerance"]), candidate))

        scored.sort(key=lambda item: -item[0])

        if scored:
            score, candidate = scored[0]
            enriched["mineral"] = candidate["mineral"]
            enriched["confidence"] = round(score, 3)
            enriched["rir"] = candidate["rir"]
            enriched["reflection"] = candidate["reflection"]
            enriched["expected_two_theta"] = round(candidate["two_theta"], 3)

            # Low-angle clay reflections sit close together, so one peak often
            # falls inside two windows at once. Saying so is more useful than
            # quietly picking the nearer one: separating them needs glycolation
            # or heating, not a better peak-finder.
            enriched["alternatives"] = [
                {"mineral": other["mineral"], "confidence": round(other_score, 3)}
                for other_score, other in scored[1:]
            ]
            enriched["ambiguous"] = bool(enriched["alternatives"])

        identified.append(enriched)

    return identified


# ==========================================================================
# 6. Semi-quantitative estimate
# ==========================================================================
def estimate_percentages(peaks, min_confidence=0.0):
    """
    Turn matched peak areas into percentages that add up to 100.

    Each mineral's area is divided by its reference intensity ratio, the usual
    first-order correction for the fact that quartz diffracts far more
    strongly than a clay at the same abundance. The result is a rough
    proportion, not a quantification: the caller must label it as estimated.

    Confidence per mineral is the area-weighted mean of its peaks'
    confidences, so a mineral resting on one shaky peak is visibly shaky.
    """
    totals = {}
    for peak in peaks:
        mineral = (peak.get("mineral") or "").strip()
        if not mineral:
            continue
        confidence = peak.get("confidence")
        if confidence is not None and confidence < min_confidence:
            continue

        area = float(peak.get("area") or 0.0)
        if area <= 0:
            area = float(peak.get("intensity") or 0.0)
        if area <= 0:
            continue

        rir = float(peak.get("rir") or 1.0) or 1.0
        entry = totals.setdefault(mineral, {"weighted": 0.0, "area": 0.0, "conf": 0.0, "peaks": 0})
        entry["weighted"] += area / rir
        entry["area"] += area
        entry["conf"] += area * (confidence if confidence is not None else 0.5)
        entry["peaks"] += 1

    grand_total = sum(entry["weighted"] for entry in totals.values())
    if grand_total <= 0:
        return []

    results = []
    for mineral, entry in totals.items():
        results.append({
            "mineral": mineral,
            "percent": round(100.0 * entry["weighted"] / grand_total, 2),
            "peak_count": entry["peaks"],
            "confidence": round(entry["conf"] / entry["area"], 3) if entry["area"] else None,
            "source": "estimated",
        })

    results.sort(key=lambda row: -row["percent"])

    # Make the rounded numbers add to exactly 100 by absorbing the remainder
    # into the largest one, so the form's total check does not complain.
    drift = round(100.0 - sum(row["percent"] for row in results), 2)
    if results and abs(drift) >= 0.01:
        results[0]["percent"] = round(results[0]["percent"] + drift, 2)

    return results


LOW_CONFIDENCE = 0.45


def flag_low_confidence(estimates):
    """Mark estimates that the user should look at twice."""
    for row in estimates:
        confidence = row.get("confidence")
        row["low_confidence"] = confidence is not None and confidence < LOW_CONFIDENCE
    return estimates


# ==========================================================================
# The whole pipeline in one call
# ==========================================================================
def analyse(image_path, calibration_dict, plot_box=None, reference=None,
            wavelength=DEFAULT_WAVELENGTH, background="light",
            smooth_window=9, min_prominence_ratio=0.05):
    """
    Run everything and return what the review screen needs.

    Raises XRDError with a sentence the user can act on when something is
    wrong with the image or the calibration.
    """
    image = load_image(image_path)
    calibration = AxisCalibration.from_dict(calibration_dict)

    curve = digitise(image, calibration, plot_box, background)
    two_theta, corrected, baseline = prepare_curve(curve, smooth_window)

    peaks = find_peaks(two_theta, corrected, min_prominence_ratio)
    peaks = identify(peaks, reference or [], wavelength)
    estimates = flag_low_confidence(estimate_percentages(peaks))

    return {
        "image_size": {"width": image.width, "height": image.height},
        "plot_box": plot_box or calibration.plot_box or guess_plot_box(image),
        "wavelength": wavelength,
        "curve": [[round(float(x), 4), round(float(y), 4)]
                  for x, y in zip(two_theta, corrected)],
        "raw_curve": curve,
        "baseline": [round(float(value), 4) for value in baseline],
        "peaks": peaks,
        "estimates": estimates,
        "note": ("These percentages are estimated from a picture of the pattern. "
                 "They are a guide only and do not replace proper quantitative "
                 "XRD refinement."),
    }


def to_csv(curve) -> str:
    """The digitised curve as CSV, for the download button."""
    lines = ["two_theta_deg,intensity"]
    for x, y in curve or []:
        lines.append(f"{x},{y}")
    return "\n".join(lines) + "\n"
