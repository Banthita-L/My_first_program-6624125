"""
xrd_data.py — reading measured XRD patterns (.jas and .chi files).

This is separate from xrd.py, which digitises a *picture* of a pattern.
These files are the real measured numbers from the diffractometer.

.jas  six columns, no header:
        1  2θ at 1 Å wavelength
        2  2θ at Cu Kα wavelength (1.5418 Å)
        3  intensity normalised to 100, after background subtraction
        4  intensity after background subtraction
        5  raw intensity
        6  calculated background
.chi  a short text header, then two columns:
        1  2θ at 1 Å (same as .jas column 1)
        2  intensity (same as .jas column 5)

The reported patterns use column 1 against column 4, after subtracting the
capillary's column 4 from each sample's column 4. That subtraction is done
in the browser (static/js/xrd-page.js) so the user can switch the capillary
on and off; this module only reads, checks and stores the files.
"""

from __future__ import annotations

import math
import re

import numpy as np

from clay_id import detect_treatment

REFERENCE_WAVELENGTH = 1.0   # Å, .jas column 1 and the .chi file
# Cu Kα weighted mean. With this value Bragg's law reproduces .jas column 2
# exactly; 1.5406 Å (Kα1 alone) is off by up to 0.08°.
CU_KALPHA = 1.5418

CAPILLARY_WORDS = ("capillary", "capilar", "capillare", "empty", "blank")


class XrdFileError(ValueError):
    """A file that cannot be read as a .jas or .chi pattern."""


def pattern_name(filename: str) -> str:
    """'Sample_OMWCNT_1_00001.jas' -> 'Sample_OMWCNT_1' (drops the scan number)."""
    stem = re.sub(r"\.(jas|chi)$", "", filename or "", flags=re.I)
    stem = stem.replace("\\", "/").rsplit("/", 1)[-1]
    return re.sub(r"_\d{3,}$", "", stem) or stem


def looks_like_capillary(name: str) -> bool:
    lower = (name or "").lower()
    return any(word in lower for word in CAPILLARY_WORDS)


def _decode(data: bytes) -> str:
    for encoding in ("utf-8-sig", "utf-8", "latin-1"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _numeric_rows(text: str, columns: int) -> np.ndarray:
    """Every line holding exactly `columns` numbers; header lines are skipped."""
    rows = []
    for line in text.splitlines():
        parts = line.split()
        if len(parts) != columns:
            continue
        try:
            rows.append([float(p) for p in parts])
        except ValueError:
            continue
    if not rows:
        return np.empty((0, columns))
    array = np.array(rows, dtype=float)
    return array[np.argsort(array[:, 0], kind="stable")]


def read_jas(data: bytes, filename: str = "") -> np.ndarray:
    """All six columns of a .jas file, sorted by 2θ."""
    array = _numeric_rows(_decode(data), 6)
    if len(array) < 10:
        raise XrdFileError(f"{filename}: no six-column data found. A .jas file holds 2θ (1 Å), "
                           f"2θ (Cu), I normalised, I background-subtracted, I raw and background.")
    return array


def read_chi(data: bytes, filename: str = "") -> np.ndarray:
    """The two data columns of a .chi file (2θ at 1 Å, raw intensity), sorted by 2θ."""
    array = _numeric_rows(_decode(data), 2)
    if len(array) < 10:
        raise XrdFileError(f"{filename}: no two-column data found after the header.")
    return array


def two_theta_to_cu(two_theta_1a) -> np.ndarray:
    """2θ at 1 Å to 2θ at Cu Kα, through Bragg's law (the d-spacing is the same)."""
    theta = np.radians(np.asarray(two_theta_1a, dtype=float) / 2)
    sine = np.clip(np.sin(theta) * CU_KALPHA / REFERENCE_WAVELENGTH, -1, 1)
    return 2 * np.degrees(np.arcsin(sine))


def build_pattern(name: str, jas: np.ndarray | None, chi: np.ndarray | None) -> dict:
    """
    One stored pattern from a .jas file, a .chi file, or both.

    With a .jas file everything comes from it and the .chi file (if any) is
    only used as a check. A .chi file on its own has the raw intensity only,
    so there is no background-subtracted column; that is flagged.
    """
    notes = []

    if jas is not None:
        x1a = jas[:, 0]
        xcu = jas[:, 1]
        bgsub = jas[:, 3]
        raw = jas[:, 4]
        source = "jas"

        expected = two_theta_to_cu(x1a)
        gap = float(np.max(np.abs(expected - xcu)))
        if gap > 0.01:
            notes.append(f"column 2 differs from Bragg's law (Cu {CU_KALPHA} Å) by up to {gap:.3f}°")

        if chi is not None:
            source = "jas+chi"
            chi_on_grid = np.interp(x1a, chi[:, 0], chi[:, 1])
            scale = np.maximum(np.abs(raw), 1e-9)
            median = float(np.median(np.abs(chi_on_grid - raw) / scale)) * 100
            if median > 0.5:
                notes.append(f"the .chi intensity differs from .jas column 5 by {median:.1f} % "
                             f"(median): are these two files the same scan?")
    elif chi is not None:
        keep = chi[:, 1] != 0          # .chi files start with a run of zeros below the detector edge
        if keep.any():
            first = int(np.argmax(keep))
            chi = chi[first:]
        x1a = chi[:, 0]
        xcu = two_theta_to_cu(x1a)
        raw = chi[:, 1]
        bgsub = None
        source = "chi"
        notes.append("only a .chi file: raw intensity, no background subtraction. "
                     "Add the .jas file for the reported (column 4) pattern.")
    else:
        raise XrdFileError(f"{name}: no data.")

    def clean(values, digits):
        if values is None:
            return None
        return [None if not math.isfinite(v) else round(float(v), digits) for v in values]

    sample_group, treatment = detect_treatment(name)
    return {
        "name": name,
        "sample_group": sample_group,
        "treatment": treatment,
        "role": "capillary" if looks_like_capillary(name) else "sample",
        "source": source,
        "points": int(len(x1a)),
        "two_theta_min": float(x1a[0]),
        "two_theta_max": float(x1a[-1]),
        "notes": notes,
        "data": {
            "x1a": clean(x1a, 5),
            "xcu": clean(xcu, 5),
            "bgsub": clean(bgsub, 3),
            "raw": clean(raw, 3),
        },
    }


def read_upload_set(files: list[tuple[str, bytes]]) -> tuple[list[dict], list[str]]:
    """
    Turn a bulk upload into patterns. Files are paired by name, so
    'Sample_A_00001.jas' and 'Sample_A_00001.chi' make one pattern.

    Returns (patterns, problems); a bad file is reported, never fatal.
    """
    groups: dict[str, dict] = {}
    problems = []

    for filename, data in files:
        lower = (filename or "").lower()
        if lower.endswith(".jas"):
            kind = "jas"
        elif lower.endswith(".chi"):
            kind = "chi"
        else:
            problems.append(f"{filename}: skipped, only .jas and .chi files are read.")
            continue
        name = pattern_name(filename)
        try:
            array = read_jas(data, filename) if kind == "jas" else read_chi(data, filename)
        except XrdFileError as exc:
            problems.append(str(exc))
            continue
        groups.setdefault(name, {})[kind] = array

    patterns = []
    for name in sorted(groups, key=lambda n: [int(p) if p.isdigit() else p.lower()
                                              for p in re.split(r"(\d+)", n)]):
        pair = groups[name]
        try:
            patterns.append(build_pattern(name, pair.get("jas"), pair.get("chi")))
        except XrdFileError as exc:
            problems.append(str(exc))
    return patterns, problems
