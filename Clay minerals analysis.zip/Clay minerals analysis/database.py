"""
database.py — SQLite storage for the geochemistry sample program.

One file, no server to install. The database lives at instance/geochem.db and
uploaded XRD spectrum images live in static/uploads/, so everything persists
between sessions.

Version 2 adds boreholes (for the map), lithology beds (for the core column),
digitised XRD curves and peaks, and an editable mineral reference table.
An existing version 1 database is migrated in place: columns and tables are
added, nothing is dropped, and no sample is ever lost.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import sqlite3
from datetime import datetime

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
INSTANCE_DIR = os.path.join(BASE_DIR, "instance")
DB_PATH = os.path.join(INSTANCE_DIR, "geochem.db")

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS samples (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    sample_name        TEXT    NOT NULL,
    area_code          TEXT    DEFAULT '',
    borehole_code      TEXT    DEFAULT '',
    depth_from         REAL,
    depth_to           REAL,
    mt_resistivity     REAL,
    clay_type_override TEXT    DEFAULT '',
    xrd_image          TEXT    DEFAULT '',
    notes              TEXT    DEFAULT '',
    created_at         TEXT    NOT NULL,
    updated_at         TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS cec_sets (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    sample_id INTEGER NOT NULL REFERENCES samples(id) ON DELETE CASCADE,
    position  INTEGER NOT NULL DEFAULT 0,
    trial1    REAL,
    trial2    REAL,
    trial3    REAL,
    w_clay    REAL,
    w_meb     REAL
);

CREATE TABLE IF NOT EXISTS xrd_minerals (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    sample_id  INTEGER NOT NULL REFERENCES samples(id) ON DELETE CASCADE,
    position   INTEGER NOT NULL DEFAULT 0,
    mineral    TEXT    NOT NULL DEFAULT '',
    percent    REAL,
    source     TEXT    DEFAULT 'manual',   -- manual | estimated | ocr
    confidence REAL
);

CREATE TABLE IF NOT EXISTS lithology (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    sample_id     INTEGER REFERENCES samples(id) ON DELETE CASCADE,
    borehole_code TEXT    DEFAULT '',
    position      INTEGER NOT NULL DEFAULT 0,
    depth_from    REAL,
    depth_to      REAL,
    description   TEXT    DEFAULT '',
    color         TEXT    DEFAULT ''
);

CREATE TABLE IF NOT EXISTS boreholes (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    borehole_code    TEXT    NOT NULL,
    area_code        TEXT    NOT NULL DEFAULT '',
    latitude         REAL,
    longitude        REAL,
    utm_easting      REAL,
    utm_northing     REAL,
    utm_zone         INTEGER,
    utm_hemisphere   TEXT    DEFAULT 'N',
    ground_elevation REAL,
    total_depth      REAL,
    notes            TEXT    DEFAULT '',
    created_at       TEXT    NOT NULL,
    updated_at       TEXT    NOT NULL,
    UNIQUE (area_code, borehole_code)
);

CREATE TABLE IF NOT EXISTS xrd_scans (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    sample_id      INTEGER NOT NULL UNIQUE REFERENCES samples(id) ON DELETE CASCADE,
    wavelength     REAL    DEFAULT 1.5406,
    calibration    TEXT    DEFAULT '',   -- JSON: the two points clicked per axis
    curve          TEXT    DEFAULT '',   -- JSON: [[two_theta, intensity], ...]
    created_at     TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS xrd_peaks (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    sample_id  INTEGER NOT NULL REFERENCES samples(id) ON DELETE CASCADE,
    position   INTEGER NOT NULL DEFAULT 0,
    two_theta  REAL,
    intensity  REAL,
    area       REAL,
    d_spacing  REAL,
    mineral    TEXT    DEFAULT '',
    confidence REAL,
    edited     INTEGER DEFAULT 0          -- 1 when the user moved or added it
);

CREATE TABLE IF NOT EXISTS mineral_reference (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    mineral    TEXT    NOT NULL,
    reflection TEXT    DEFAULT '',
    d_spacing  REAL,
    two_theta  REAL,
    tolerance  REAL    DEFAULT 0.4,
    rir        REAL    DEFAULT 1.0,       -- relative intensity ratio, for the estimate
    position   INTEGER NOT NULL DEFAULT 0
);

-- Measured XRD patterns imported from .jas / .chi files (the XRD page).
-- The arrays are stored as JSON: {x1a, xcu, bgsub, raw}.
CREATE TABLE IF NOT EXISTS xrd_patterns (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    name          TEXT    NOT NULL UNIQUE,
    role          TEXT    NOT NULL DEFAULT 'sample',   -- sample | capillary
    source        TEXT    DEFAULT '',                  -- jas | chi | jas+chi
    points        INTEGER DEFAULT 0,
    two_theta_min REAL,
    two_theta_max REAL,
    notes         TEXT    DEFAULT '[]',                -- JSON list of check messages
    data          TEXT    NOT NULL,
    created_at    TEXT    NOT NULL,
    updated_at    TEXT    NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_cec_sample      ON cec_sets(sample_id);
CREATE INDEX IF NOT EXISTS idx_minerals_sample ON xrd_minerals(sample_id);
CREATE INDEX IF NOT EXISTS idx_litho_sample    ON lithology(sample_id);
CREATE INDEX IF NOT EXISTS idx_litho_borehole  ON lithology(borehole_code);
CREATE INDEX IF NOT EXISTS idx_peaks_sample    ON xrd_peaks(sample_id);
CREATE INDEX IF NOT EXISTS idx_sample_borehole ON samples(borehole_code);
"""

# Columns added after version 1 shipped. Each is applied only when missing,
# so upgrading an existing database never destroys anything.
MIGRATIONS = [
    ("samples", "cec_imported", "INTEGER DEFAULT 0"),
    ("samples", "cec_from_file", "REAL"),
    ("samples", "import_batch", "TEXT DEFAULT ''"),
    ("xrd_minerals", "source", "TEXT DEFAULT 'manual'"),
    ("xrd_minerals", "confidence", "REAL"),
    # XRD page: which sample a pattern belongs to, and how it was treated
    ("xrd_patterns", "sample_group", "TEXT DEFAULT ''"),
    ("xrd_patterns", "treatment", "TEXT DEFAULT ''"),   # AD | EG | H400 | H550 | ''
]

# Starting values from the project requirements. The user can edit these in
# the app; they are only seeded when the table is empty.
DEFAULT_MINERAL_REFERENCE = [
    # mineral, reflection, d-spacing (A), 2-theta Cu Ka (deg), tolerance, RIR
    ("Smectite (air-dried)", "001, about 12-15 A", 13.5, 6.54, 0.80, 0.35),
    ("Chlorite",             "001, about 14 A",    14.0, 6.31, 0.45, 0.60),
    ("Illite",               "001, about 10 A",    10.0, 8.84, 0.45, 0.50),
    ("Kaolinite",            "001, about 7.15 A",   7.15, 12.37, 0.40, 0.70),
    ("Quartz",               "101, about 3.34 A",   3.34, 26.66, 0.30, 1.00),
]


def get_connection(db_path: str = DB_PATH) -> sqlite3.Connection:
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db(db_path: str = DB_PATH) -> None:
    """Create anything missing, then migrate an older database in place."""
    conn = get_connection(db_path)
    with conn:
        conn.executescript(SCHEMA)
        _apply_migrations(conn)
        _seed_mineral_reference(conn)
    _migrate_boreholes_to_area_key(conn, db_path)
    conn.close()


def norm_area(area) -> str:
    """Area codes are compared upper-case and trimmed: 'cri1 ' == 'CRI1'."""
    return (area or "").strip().upper()


def _boreholes_keyed_by_code_only(conn: sqlite3.Connection) -> bool:
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'boreholes'"
    ).fetchone()
    sql = re.sub(r"\s+", " ", (row["sql"] if row else "") or "")
    return bool(re.search(r"borehole_code TEXT NOT NULL UNIQUE", sql, re.I))


def _migrate_boreholes_to_area_key(conn: sqlite3.Connection, db_path: str) -> None:
    """
    Version 3: a borehole is identified by area + code, not by code alone.

    BH_1 in CRI1 and BH_1 in PCMI2 are different holes about 190 km apart,
    so each needs its own position. Older databases had borehole_code UNIQUE,
    which SQLite cannot drop, so the table is rebuilt: every row is copied
    across, a backup of the file is taken first, and nothing is lost.

    Empty placeholder records (no position, no notes, and no samples in that
    area) are removed afterwards; they were created automatically and would
    only show up as blank rows.
    """
    if not _boreholes_keyed_by_code_only(conn):
        return

    if os.path.isfile(db_path):
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        backup = os.path.join(os.path.dirname(db_path), f"geochem.before-area-boreholes-{stamp}.db")
        if not os.path.exists(backup):
            shutil.copy2(db_path, backup)

    conn.execute("BEGIN IMMEDIATE")
    try:
        # Another copy of the program may have migrated while we waited
        if not _boreholes_keyed_by_code_only(conn):
            conn.rollback()
            return

        columns = ("id", "borehole_code", "area_code", "latitude", "longitude",
                   "utm_easting", "utm_northing", "utm_zone", "utm_hemisphere",
                   "ground_elevation", "total_depth", "notes", "created_at", "updated_at")
        conn.execute("""
            CREATE TABLE boreholes_v3 (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                borehole_code    TEXT    NOT NULL,
                area_code        TEXT    NOT NULL DEFAULT '',
                latitude         REAL,
                longitude        REAL,
                utm_easting      REAL,
                utm_northing     REAL,
                utm_zone         INTEGER,
                utm_hemisphere   TEXT    DEFAULT 'N',
                ground_elevation REAL,
                total_depth      REAL,
                notes            TEXT    DEFAULT '',
                created_at       TEXT    NOT NULL,
                updated_at       TEXT    NOT NULL,
                UNIQUE (area_code, borehole_code)
            )""")
        select = ", ".join(
            "UPPER(TRIM(COALESCE(area_code, '')))" if c == "area_code" else c for c in columns)
        conn.execute(f"INSERT INTO boreholes_v3 ({', '.join(columns)}) "
                     f"SELECT {select} FROM boreholes")
        conn.execute("DROP TABLE boreholes")
        conn.execute("ALTER TABLE boreholes_v3 RENAME TO boreholes")

        conn.execute("""
            DELETE FROM boreholes
            WHERE latitude IS NULL AND longitude IS NULL
              AND utm_easting IS NULL AND utm_northing IS NULL
              AND ground_elevation IS NULL AND total_depth IS NULL
              AND COALESCE(notes, '') = ''
              AND NOT EXISTS (
                  SELECT 1 FROM samples s
                  WHERE s.borehole_code = boreholes.borehole_code
                    AND UPPER(TRIM(COALESCE(s.area_code, ''))) = boreholes.area_code)
        """)
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def _apply_migrations(conn: sqlite3.Connection) -> None:
    for table, column, definition in MIGRATIONS:
        existing = {row["name"] for row in conn.execute(f"PRAGMA table_info({table})")}
        if column not in existing:
            conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")


def _seed_mineral_reference(conn: sqlite3.Connection) -> None:
    count = conn.execute("SELECT COUNT(*) FROM mineral_reference").fetchone()[0]
    if count:
        return
    for position, row in enumerate(DEFAULT_MINERAL_REFERENCE):
        conn.execute(
            "INSERT INTO mineral_reference "
            "(mineral, reflection, d_spacing, two_theta, tolerance, rir, position) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            row + (position,),
        )


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


# --------------------------------------------------------------------------
# Samples: read
# --------------------------------------------------------------------------
def list_samples(db_path: str = DB_PATH) -> list[dict]:
    conn = get_connection(db_path)
    rows = conn.execute(
        "SELECT * FROM samples ORDER BY borehole_code, depth_from, id"
    ).fetchall()
    samples = [_hydrate(conn, row) for row in rows]
    conn.close()
    return samples


def get_sample(sample_id: int, db_path: str = DB_PATH) -> dict | None:
    conn = get_connection(db_path)
    row = conn.execute("SELECT * FROM samples WHERE id = ?", (sample_id,)).fetchone()
    sample = _hydrate(conn, row) if row else None
    conn.close()
    return sample


def _hydrate(conn: sqlite3.Connection, row: sqlite3.Row) -> dict:
    sample = dict(row)
    sample_id = row["id"]

    sample["cec_sets"] = [
        dict(r) for r in conn.execute(
            "SELECT id, position, trial1, trial2, trial3, w_clay, w_meb "
            "FROM cec_sets WHERE sample_id = ? ORDER BY position, id", (sample_id,)
        )
    ]
    sample["minerals"] = [
        dict(r) for r in conn.execute(
            "SELECT id, position, mineral, percent, source, confidence "
            "FROM xrd_minerals WHERE sample_id = ? ORDER BY position, id", (sample_id,)
        )
    ]
    sample["lithology"] = [
        dict(r) for r in conn.execute(
            "SELECT id, position, depth_from, depth_to, description, color "
            "FROM lithology WHERE sample_id = ? ORDER BY position, id", (sample_id,)
        )
    ]
    sample["peaks"] = [
        dict(r) for r in conn.execute(
            "SELECT id, position, two_theta, intensity, area, d_spacing, mineral, "
            "confidence, edited FROM xrd_peaks WHERE sample_id = ? ORDER BY two_theta",
            (sample_id,)
        )
    ]

    scan = conn.execute(
        "SELECT wavelength, calibration, curve FROM xrd_scans WHERE sample_id = ?",
        (sample_id,)
    ).fetchone()
    if scan:
        sample["xrd_scan"] = {
            "wavelength": scan["wavelength"],
            "calibration": _loads(scan["calibration"]),
            "curve": _loads(scan["curve"]) or [],
        }
    else:
        sample["xrd_scan"] = None

    return sample


def _loads(text):
    if not text:
        return None
    try:
        return json.loads(text)
    except (ValueError, TypeError):
        return None


# --------------------------------------------------------------------------
# Samples: write
# --------------------------------------------------------------------------
SAMPLE_FIELDS = (
    "sample_name",
    "area_code",
    "borehole_code",
    "depth_from",
    "depth_to",
    "mt_resistivity",
    "clay_type_override",
    "xrd_image",
    "notes",
    "cec_imported",
    "cec_from_file",
    "import_batch",
)


def create_sample(data: dict, db_path: str = DB_PATH, conn: sqlite3.Connection = None) -> int:
    own = conn is None
    conn = conn or get_connection(db_path)
    now = _now()
    cursor = conn.execute(
        f"INSERT INTO samples ({', '.join(SAMPLE_FIELDS)}, created_at, updated_at) "
        f"VALUES ({', '.join('?' for _ in SAMPLE_FIELDS)}, ?, ?)",
        tuple(data.get(field) for field in SAMPLE_FIELDS) + (now, now),
    )
    sample_id = cursor.lastrowid
    _replace_children(conn, sample_id, data)
    if own:
        conn.commit()
        conn.close()
    return sample_id


def update_sample(sample_id: int, data: dict, db_path: str = DB_PATH,
                  conn: sqlite3.Connection = None) -> bool:
    own = conn is None
    conn = conn or get_connection(db_path)
    existing = conn.execute("SELECT id FROM samples WHERE id = ?", (sample_id,)).fetchone()
    if existing is None:
        if own:
            conn.close()
        return False
    conn.execute(
        f"UPDATE samples SET {', '.join(f'{f} = ?' for f in SAMPLE_FIELDS)}, updated_at = ? "
        f"WHERE id = ?",
        tuple(data.get(field) for field in SAMPLE_FIELDS) + (_now(), sample_id),
    )
    _replace_children(conn, sample_id, data)
    if own:
        conn.commit()
        conn.close()
    return True


def _replace_children(conn: sqlite3.Connection, sample_id: int, data: dict) -> None:
    conn.execute("DELETE FROM cec_sets WHERE sample_id = ?", (sample_id,))
    conn.execute("DELETE FROM xrd_minerals WHERE sample_id = ?", (sample_id,))
    conn.execute("DELETE FROM lithology WHERE sample_id = ?", (sample_id,))

    for position, cec_set in enumerate(data.get("cec_sets") or []):
        conn.execute(
            "INSERT INTO cec_sets (sample_id, position, trial1, trial2, trial3, w_clay, w_meb) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (sample_id, position, cec_set.get("trial1"), cec_set.get("trial2"),
             cec_set.get("trial3"), cec_set.get("w_clay"), cec_set.get("w_meb")),
        )

    for position, mineral in enumerate(data.get("minerals") or []):
        conn.execute(
            "INSERT INTO xrd_minerals (sample_id, position, mineral, percent, source, confidence) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (sample_id, position, mineral.get("mineral") or "", mineral.get("percent"),
             mineral.get("source") or "manual", mineral.get("confidence")),
        )

    for position, bed in enumerate(data.get("lithology") or []):
        conn.execute(
            "INSERT INTO lithology "
            "(sample_id, borehole_code, position, depth_from, depth_to, description, color) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (sample_id, data.get("borehole_code") or "", position, bed.get("depth_from"),
             bed.get("depth_to"), bed.get("description") or "", bed.get("color") or ""),
        )


def delete_sample(sample_id: int, db_path: str = DB_PATH) -> tuple[bool, str | None]:
    """
    Delete a sample.

    Returns (found, image_filename) so the caller can tell "no such sample"
    apart from "deleted, but it had no image".
    """
    conn = get_connection(db_path)
    row = conn.execute("SELECT xrd_image FROM samples WHERE id = ?", (sample_id,)).fetchone()
    if row is None:
        conn.close()
        return False, None
    with conn:
        conn.execute("DELETE FROM samples WHERE id = ?", (sample_id,))
    conn.close()
    return True, (row["xrd_image"] or None)


def find_duplicate(borehole_code, sample_name, depth_from, area_code=None,
                   db_path: str = DB_PATH, conn: sqlite3.Connection = None):
    """
    A sample already stored with the same area, borehole, name and top depth.

    This is the rule the bulk import uses to spot duplicates. The area is part
    of it because the same borehole code (BH_2) is reused in different areas.
    Pass area_code=None to ignore the area.
    """
    own = conn is None
    conn = conn or get_connection(db_path)
    sql = "SELECT * FROM samples WHERE borehole_code = ? AND sample_name = ? "
    params = [borehole_code or "", sample_name or ""]
    if depth_from is None:
        sql += "AND depth_from IS NULL "
    else:
        sql += "AND ABS(COALESCE(depth_from, -999) - ?) < 0.0005 "
        params.append(depth_from)
    if area_code is not None:
        sql += "AND UPPER(TRIM(COALESCE(area_code, ''))) = ? "
        params.append((area_code or "").strip().upper())
    row = conn.execute(sql, params).fetchone()
    if own:
        conn.close()
    return dict(row) if row else None


# --------------------------------------------------------------------------
# XRD scans and peaks
# --------------------------------------------------------------------------
def save_xrd_scan(sample_id: int, scan: dict, peaks: list[dict],
                  db_path: str = DB_PATH) -> None:
    conn = get_connection(db_path)
    with conn:
        conn.execute("DELETE FROM xrd_scans WHERE sample_id = ?", (sample_id,))
        conn.execute("DELETE FROM xrd_peaks WHERE sample_id = ?", (sample_id,))
        conn.execute(
            "INSERT INTO xrd_scans (sample_id, wavelength, calibration, curve, created_at) "
            "VALUES (?, ?, ?, ?, ?)",
            (sample_id, scan.get("wavelength") or 1.5406,
             json.dumps(scan.get("calibration") or {}),
             json.dumps(scan.get("curve") or []), _now()),
        )
        for position, peak in enumerate(peaks or []):
            conn.execute(
                "INSERT INTO xrd_peaks (sample_id, position, two_theta, intensity, area, "
                "d_spacing, mineral, confidence, edited) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (sample_id, position, peak.get("two_theta"), peak.get("intensity"),
                 peak.get("area"), peak.get("d_spacing"), peak.get("mineral") or "",
                 peak.get("confidence"), 1 if peak.get("edited") else 0),
            )
    conn.close()


def clear_xrd_scan(sample_id: int, db_path: str = DB_PATH) -> None:
    conn = get_connection(db_path)
    with conn:
        conn.execute("DELETE FROM xrd_scans WHERE sample_id = ?", (sample_id,))
        conn.execute("DELETE FROM xrd_peaks WHERE sample_id = ?", (sample_id,))
    conn.close()


# --------------------------------------------------------------------------
# Mineral reference table (editable by the user)
# --------------------------------------------------------------------------
def list_mineral_reference(db_path: str = DB_PATH) -> list[dict]:
    conn = get_connection(db_path)
    rows = [dict(r) for r in conn.execute(
        "SELECT * FROM mineral_reference ORDER BY position, id"
    )]
    conn.close()
    return rows


def replace_mineral_reference(rows: list[dict], db_path: str = DB_PATH) -> None:
    conn = get_connection(db_path)
    with conn:
        conn.execute("DELETE FROM mineral_reference")
        for position, row in enumerate(rows or []):
            conn.execute(
                "INSERT INTO mineral_reference "
                "(mineral, reflection, d_spacing, two_theta, tolerance, rir, position) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (row.get("mineral") or "", row.get("reflection") or "",
                 row.get("d_spacing"), row.get("two_theta"),
                 row.get("tolerance") if row.get("tolerance") is not None else 0.4,
                 row.get("rir") if row.get("rir") is not None else 1.0, position),
            )
    conn.close()


def reset_mineral_reference(db_path: str = DB_PATH) -> None:
    conn = get_connection(db_path)
    with conn:
        conn.execute("DELETE FROM mineral_reference")
        _seed_mineral_reference(conn)
    conn.close()


# --------------------------------------------------------------------------
# Boreholes
# --------------------------------------------------------------------------
BOREHOLE_FIELDS = (
    "borehole_code",
    "area_code",
    "latitude",
    "longitude",
    "utm_easting",
    "utm_northing",
    "utm_zone",
    "utm_hemisphere",
    "ground_elevation",
    "total_depth",
    "notes",
)


def list_boreholes(db_path: str = DB_PATH) -> list[dict]:
    conn = get_connection(db_path)
    rows = [dict(r) for r in conn.execute(
        "SELECT * FROM boreholes ORDER BY area_code, borehole_code"
    )]
    conn.close()
    return rows


def get_borehole(code: str, area_code: str | None = None, fallback: bool = True,
                 db_path: str = DB_PATH) -> dict | None:
    """
    One borehole record. A hole is identified by area + code.

    With `area_code`, the record for that area is returned. When there is
    none and `fallback` is on, a record saved without an area is used
    instead, so a position typed in before areas were known still counts.
    Without `area_code`, any record with that code is returned.
    """
    conn = get_connection(db_path)
    if area_code is None:
        row = conn.execute(
            "SELECT * FROM boreholes WHERE borehole_code = ? "
            "ORDER BY (latitude IS NULL AND utm_easting IS NULL), area_code LIMIT 1",
            (code,)).fetchone()
    else:
        row = conn.execute(
            "SELECT * FROM boreholes WHERE borehole_code = ? AND area_code = ?",
            (code, norm_area(area_code))).fetchone()
        if row is None and fallback and norm_area(area_code):
            row = conn.execute(
                "SELECT * FROM boreholes WHERE borehole_code = ? AND area_code = ''",
                (code,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_borehole(data: dict, db_path: str = DB_PATH,
                  conn: sqlite3.Connection = None) -> int:
    """Insert or update by area + borehole code, which together are the identity."""
    own = conn is None
    conn = conn or get_connection(db_path)
    code = (data.get("borehole_code") or "").strip()
    values = dict(data, borehole_code=code, area_code=norm_area(data.get("area_code")))
    now = _now()

    existing = conn.execute(
        "SELECT id FROM boreholes WHERE borehole_code = ? AND area_code = ?",
        (code, values["area_code"])
    ).fetchone()

    if existing:
        conn.execute(
            f"UPDATE boreholes SET {', '.join(f'{f} = ?' for f in BOREHOLE_FIELDS)}, "
            f"updated_at = ? WHERE id = ?",
            tuple(values.get(f) for f in BOREHOLE_FIELDS) + (now, existing["id"]),
        )
        borehole_id = existing["id"]
    else:
        cursor = conn.execute(
            f"INSERT INTO boreholes ({', '.join(BOREHOLE_FIELDS)}, created_at, updated_at) "
            f"VALUES ({', '.join('?' for _ in BOREHOLE_FIELDS)}, ?, ?)",
            tuple(values.get(f) for f in BOREHOLE_FIELDS) + (now, now),
        )
        borehole_id = cursor.lastrowid

    if own:
        conn.commit()
        conn.close()
    return borehole_id


def delete_borehole(code: str, area_code: str | None = None, db_path: str = DB_PATH) -> bool:
    """
    Remove a borehole record: the one in `area_code`, or every area's when
    no area is given.

    Samples keep their borehole_code: deleting the map position of a hole must
    never delete the lab results that belong to it.
    """
    conn = get_connection(db_path)
    if area_code is None:
        cursor = conn.execute("DELETE FROM boreholes WHERE borehole_code = ?", (code,))
    else:
        cursor = conn.execute("DELETE FROM boreholes WHERE borehole_code = ? AND area_code = ?",
                              (code, norm_area(area_code)))
    conn.commit()
    deleted = cursor.rowcount > 0
    conn.close()
    return deleted


# --------------------------------------------------------------------------
# Measured XRD patterns (.jas / .chi)
# --------------------------------------------------------------------------
def _xrd_pattern_row(row, with_data: bool) -> dict:
    item = {key: row[key] for key in ("id", "name", "role", "source", "points",
                                      "two_theta_min", "two_theta_max",
                                      "sample_group", "treatment",
                                      "created_at", "updated_at")}
    item["sample_group"] = item["sample_group"] or item["name"]
    item["treatment"] = item["treatment"] or ""
    item["notes"] = json.loads(row["notes"] or "[]")
    if with_data:
        item["data"] = json.loads(row["data"])
    return item


def list_xrd_patterns(with_data: bool = False, db_path: str = DB_PATH) -> list[dict]:
    conn = get_connection(db_path)
    rows = conn.execute("SELECT * FROM xrd_patterns ORDER BY role DESC, sample_group, name").fetchall()
    conn.close()
    order = {"AD": 0, "EG": 1, "H400": 2, "H550": 3, "": 4}
    items = [_xrd_pattern_row(r, with_data) for r in rows]
    items.sort(key=lambda p: (p["role"] != "capillary", p["sample_group"].lower(),
                              order.get(p["treatment"], 5), p["name"]))
    return items


def get_xrd_patterns(ids: list[int] | None = None, sample_group: str | None = None,
                     db_path: str = DB_PATH) -> list[dict]:
    """Patterns with their data, by id or by sample."""
    return [p for p in list_xrd_patterns(with_data=True, db_path=db_path)
            if (ids is None or p["id"] in ids)
            and (sample_group is None or p["sample_group"] == sample_group)]


def save_xrd_pattern(pattern: dict, db_path: str = DB_PATH) -> tuple[int, bool]:
    """
    Insert, or replace the pattern with the same name (re-importing a file
    updates it). A role the user already chose is kept on re-import.

    Returns (id, replaced).
    """
    conn = get_connection(db_path)
    now = _now()
    existing = conn.execute("SELECT id, role FROM xrd_patterns WHERE name = ?",
                            (pattern["name"],)).fetchone()
    values = (pattern["source"], pattern["points"], pattern["two_theta_min"],
              pattern["two_theta_max"], json.dumps(pattern.get("notes") or []),
              json.dumps(pattern["data"], separators=(",", ":")))
    with conn:
        if existing:
            conn.execute(
                "UPDATE xrd_patterns SET source = ?, points = ?, two_theta_min = ?, "
                "two_theta_max = ?, notes = ?, data = ?, updated_at = ? WHERE id = ?",
                values + (now, existing["id"]))
            pattern_id, replaced = existing["id"], True
        else:
            cursor = conn.execute(
                "INSERT INTO xrd_patterns (name, role, source, points, two_theta_min, "
                "two_theta_max, notes, data, created_at, updated_at, sample_group, treatment) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (pattern["name"], pattern.get("role") or "sample") + values + (now, now)
                + (pattern.get("sample_group") or pattern["name"], pattern.get("treatment") or ""))
            pattern_id, replaced = cursor.lastrowid, False
    conn.close()
    return pattern_id, replaced


def update_xrd_pattern(pattern_id: int, role: str | None = None, name: str | None = None,
                       sample_group: str | None = None, treatment: str | None = None,
                       db_path: str = DB_PATH) -> bool:
    conn = get_connection(db_path)
    sets, params = [], []
    if role in ("sample", "capillary"):
        sets.append("role = ?")
        params.append(role)
    if name:
        sets.append("name = ?")
        params.append(name.strip())
    if sample_group is not None and sample_group.strip():
        sets.append("sample_group = ?")
        params.append(sample_group.strip())
    if treatment in ("AD", "EG", "H400", "H550", ""):
        sets.append("treatment = ?")
        params.append(treatment)
    if not sets:
        conn.close()
        return False
    with conn:
        cursor = conn.execute(f"UPDATE xrd_patterns SET {', '.join(sets)}, updated_at = ? "
                              f"WHERE id = ?", params + [_now(), pattern_id])
    conn.close()
    return cursor.rowcount > 0


def delete_xrd_patterns(ids: list[int], db_path: str = DB_PATH) -> int:
    if not ids:
        return 0
    conn = get_connection(db_path)
    with conn:
        cursor = conn.execute(
            f"DELETE FROM xrd_patterns WHERE id IN ({', '.join('?' for _ in ids)})", ids)
    conn.close()
    return cursor.rowcount


def list_lithology(borehole_code: str, area_code: str | None = None,
                   db_path: str = DB_PATH) -> list[dict]:
    """
    Lithology beds logged for a borehole.

    Each bed belongs to a sample, so passing `area_code` keeps only the beds
    from that area's samples: BH_1 in CRI1 and BH_1 in PCMI2 are different
    holes and must not share a core log.
    """
    conn = get_connection(db_path)
    if area_code is None:
        cursor = conn.execute(
            "SELECT * FROM lithology WHERE borehole_code = ? ORDER BY depth_from, position",
            (borehole_code,))
    else:
        cursor = conn.execute(
            "SELECT l.* FROM lithology l JOIN samples s ON s.id = l.sample_id "
            "WHERE l.borehole_code = ? AND UPPER(TRIM(COALESCE(s.area_code, ''))) = ? "
            "ORDER BY l.depth_from, l.position",
            (borehole_code, (area_code or "").strip().upper()))
    rows = [dict(r) for r in cursor]
    conn.close()
    return rows
