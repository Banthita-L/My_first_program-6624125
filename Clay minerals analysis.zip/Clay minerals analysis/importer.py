"""
importer.py — Bulk import of lab results from CSV or XLSX.

The lab file used in this project is not a plain table. It looks like this:

    PCMI2 หมู่ที่ 3 ...        19 samples        <- title row
    BH_1                                          <- borehole header row
    Sample | Depth (m.) | Titration (ml.) ... |   <- column header row
    D:2.00 | 2 - 2.45   | 1.7 | 1.5 | 1.5    |   <- one row per sample
    ...
    BH_2                                          <- next borehole starts here
    Sample | Depth (m.) | ...
    ...

So the parser works in three passes:

  1. read the file into a plain grid of text cells (CSV or XLSX, any sheet)
  2. walk the grid and work out which rows are titles, borehole headers,
     column headers, and data
  3. map each column to a field, then validate every value

Nothing is written to the database here. This module only ever returns a
preview for the user to look at, which is what the requirements ask for.
"""

from __future__ import annotations

import csv
import io
import re
import unicodedata

import geochem

MAX_PREVIEW_ROWS = 2000

# How far the file's own CEC may differ from the recalculated value before we
# flag it. The lab rounds to two decimals, so a small gap is expected.
CEC_TOLERANCE = 0.05


class ImportError_(ValueError):
    """Raised when a file cannot be read at all."""


# --------------------------------------------------------------------------
# 1. Read the file into a grid of text cells
# --------------------------------------------------------------------------
def list_sheets(data: bytes, filename: str) -> list[str]:
    """Sheet names for an .xlsx file; an empty list for CSV."""
    if not _is_excel(filename):
        return []
    try:
        import openpyxl
    except ImportError:
        raise ImportError_(
            "Reading .xlsx files needs the openpyxl package. "
            "Run: pip install -r requirements.txt"
        )
    book = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    names = list(book.sheetnames)
    book.close()
    return names


def read_grid(data: bytes, filename: str, sheet: str | None = None) -> list[list[str]]:
    """Read a CSV or XLSX file into a rectangular grid of trimmed strings."""
    if _is_excel(filename):
        return _read_excel(data, sheet)
    return _read_csv(data)


def _is_excel(filename: str) -> bool:
    return (filename or "").lower().endswith((".xlsx", ".xlsm", ".xls"))


def _read_excel(data: bytes, sheet: str | None) -> list[list[str]]:
    name = (sheet or "").strip()
    lower = name.lower()

    if lower.endswith(".xls") or (not lower and False):
        pass  # handled below by the loader choice

    try:
        import openpyxl
    except ImportError:
        raise ImportError_(
            "Reading Excel files needs the openpyxl package. "
            "Run: pip install -r requirements.txt"
        )

    try:
        book = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    except Exception as exc:                       # noqa: BLE001 - user-facing message
        raise ImportError_(
            "That Excel file could not be opened. If it is an old .xls file, "
            f"please open it in Excel and save it as .xlsx first. ({exc})"
        )

    worksheet = book[name] if name and name in book.sheetnames else book[book.sheetnames[0]]
    grid = []
    for row in worksheet.iter_rows(values_only=True):
        grid.append([_cell_text(value) for value in row])
    book.close()
    return _trim_grid(grid)


def _read_csv(data: bytes) -> list[list[str]]:
    text = _decode(data)
    # Sniff the delimiter, falling back to a comma for short or odd files
    sample = text[:8000]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
        delimiter = dialect.delimiter
    except csv.Error:
        delimiter = ","

    reader = csv.reader(io.StringIO(text), delimiter=delimiter)
    grid = [[_cell_text(cell) for cell in row] for row in reader]
    return _trim_grid(grid)


def _decode(data: bytes) -> str:
    """
    Decode a CSV file.

    Thai lab files turn up as UTF-8 (often with a BOM from Excel) or as the
    older Windows Thai code page 874, so both are tried before giving up.
    """
    for encoding in ("utf-8-sig", "utf-8", "cp874", "tis-620", "cp1252", "latin-1"):
        try:
            return data.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode("utf-8", errors="replace")


def _cell_text(value) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).replace("\r", " ").replace("\n", " ").strip()


def _trim_grid(grid: list[list[str]]) -> list[list[str]]:
    """Drop trailing empty rows and pad every row to the same width."""
    while grid and not any(cell for cell in grid[-1]):
        grid.pop()
    width = max((len(row) for row in grid), default=0)
    return [list(row) + [""] * (width - len(row)) for row in grid]


# --------------------------------------------------------------------------
# 2. Work out the shape of the file
# --------------------------------------------------------------------------
BOREHOLE_PATTERN = re.compile(r"^\s*(BH|HOLE|BORE[\s_-]*HOLE|หลุม)[\s_\-.:#]*([A-Za-z0-9]+)\s*$", re.I)

HEADER_KEYWORDS = (
    "sample", "depth", "titration", "volume", "meb", "cec", "clay",
    "mineral", "resistivity", "w_clay", "w clay", "w_meb", "w meb",
)


def normalise(text: str) -> str:
    """Lowercase, strip accents, collapse whitespace and punctuation."""
    text = unicodedata.normalize("NFKC", str(text or ""))
    text = text.replace("\n", " ").replace("\r", " ")
    text = re.sub(r"[^\w\s#%./-]", " ", text, flags=re.UNICODE)
    return re.sub(r"\s+", " ", text).strip().lower()


def looks_like_borehole(cell: str) -> str | None:
    """Return a tidy borehole code when this cell is a borehole header."""
    raw = (cell or "").strip()
    if not raw or len(raw) > 30:
        return None
    match = BOREHOLE_PATTERN.match(raw)
    if match:
        return f"BH_{match.group(2).upper()}"
    # A bare code such as "BH_1" already in the right shape
    if re.fullmatch(r"(?i)bh[\s_\-]?\d+[a-z]?", raw):
        return re.sub(r"(?i)^bh[\s_\-]?", "BH_", raw).upper().replace("BH_", "BH_")
    return None


def _row_is_borehole_header(row: list[str]) -> str | None:
    found = _borehole_and_area(row)
    return found[0] if found else None


# ---- area codes -----------------------------------------------------------
# Area codes in this project look like CRI1, PCMI2: letters then a number.
AREA_CODE_PATTERN = re.compile(r"^[A-Za-z]{2,}[A-Za-z0-9]*\d[A-Za-z0-9_\-]*$")
# "Area: CRI1", "Area code = CRI1", "พื้นที่ CRI1"
_AREA_LABEL = re.compile(
    r"^\s*(?:area\s*code|code\s*area|area|พื้นที่)(?![A-Za-z])\s*[:=#\-]?\s*([A-Za-z0-9][A-Za-z0-9_\-]*)",
    re.I)
BOREHOLE_SEARCH = re.compile(
    r"(?<![A-Za-z0-9])(?:BH|HOLE|BORE[\s_-]*HOLE|หลุม)[\s_\-.:#]*(\d+[A-Za-z]?(?:/\d+)?)(?![A-Za-z0-9])",
    re.I)


def _labelled_area(text: str) -> str | None:
    """
    'Area: CRI1' -> 'CRI1', 'Area code PCMI2' -> 'PCMI2', 'Area A' -> 'A'.

    The word after the label must look like a code (CRI1, or capitals), so a
    sentence such as "Area with 3 roads" is not mistaken for one.
    """
    match = _AREA_LABEL.match(text or "")
    if not match:
        return None
    code = match.group(1)
    if AREA_CODE_PATTERN.match(code) or re.fullmatch(r"[A-Z0-9_\-]{1,12}", code):
        return code.upper()
    return None


def looks_like_area_code(text: str) -> str | None:
    """'CRI1' -> 'CRI1'; 'Area: CRI1' -> 'CRI1'; anything else -> None."""
    raw = (text or "").strip()
    if not raw:
        return None
    labelled = _labelled_area(raw)
    if labelled:
        return labelled
    if AREA_CODE_PATTERN.match(raw) and not looks_like_borehole(raw):
        return raw.upper()
    return None


def _borehole_and_area(row: list[str]):
    """
    A borehole header row, with the area code when the row names one too.

        BH_1            -> ('BH_1', None)
        CRI1 BH_2       -> ('BH_2', 'CRI1')
        BH_2 (PCMI2)    -> ('BH_2', 'PCMI2')
        CRI1 | BH_2     -> ('BH_2', 'CRI1')     two cells on the same row
    """
    filled = [cell.strip() for cell in row if cell.strip()]
    if not filled or len(filled) > 2:
        return None

    if len(filled) == 1:
        plain = looks_like_borehole(filled[0])
        if plain:
            return plain, None

    text = " ".join(filled)
    if len(text) > 40:
        return None
    match = BOREHOLE_SEARCH.search(text)
    if not match:
        return None

    rest = (text[:match.start()] + " " + text[match.end():])
    rest = re.sub(r"[()\[\],;/|]+", " ", rest).strip(" -_:.")
    rest = re.sub(r"\s+", " ", rest).strip()
    if not rest:
        return f"BH_{match.group(1).upper()}", None

    area = looks_like_area_code(rest)
    if area:
        return f"BH_{match.group(1).upper()}", area
    return None


def _row_is_area_header(row: list[str], seen_header: bool) -> str | None:
    """
    A row that starts a new area, such as the title row
    "CRI1 บ้าน... | 12 samples", or a bare "Area: PCMI2".

    It must not look like a sample: apart from the area cell, the only other
    cells allowed are plain text or a sample count, never a depth or a number.
    """
    filled = [cell.strip() for cell in row if cell.strip()]
    if not filled or len(filled) > 3:
        return None

    first = filled[0]
    labelled = _labelled_area(first)
    code = labelled
    if not code:
        token = first.split()[0]
        if not AREA_CODE_PATTERN.match(token) or looks_like_borehole(token):
            return None
        code = token.upper()

    for other in filled[1:]:
        if _sample_count(other) is not None:
            continue
        if parse_number(other) is not None or parse_depth(other)[0] is not None:
            return None

    # A bare token on its own could be a sample name, so once the column
    # header has been seen it needs some extra sign that it is an area: a
    # label, a place name after it, or a sample count beside it.
    if seen_header and not labelled:
        has_name = len(first.split()) > 1
        has_count = any(_sample_count(other) is not None for other in filled[1:])
        if not (has_name or has_count):
            return None
    return code


def _row_is_column_header(row: list[str]) -> bool:
    hits = 0
    for cell in row:
        text = normalise(cell)
        if any(keyword in text for keyword in HEADER_KEYWORDS):
            hits += 1
    return hits >= 3


def _row_is_header_continuation(row: list[str]) -> bool:
    """
    A second header line holding only the titration numbers.

    Excel files often merge "Titration (ml.)" across three columns and put
    1, 2, 3 (or #1, #2, #3) on the line below. That line is part of the
    header, not a sample, so it gets merged upwards.
    """
    filled = [cell.strip() for cell in row if cell.strip()]
    if not filled or len(filled) > 6:
        return False
    return all(
        len(cell) <= 3 and re.fullmatch(r"#?\d", cell) is not None
        for cell in filled
    )


def _merge_header_rows(upper: list[str], lower: list[str]) -> list[str]:
    width = max(len(upper), len(lower))
    merged = []
    for index in range(width):
        top = upper[index].strip() if index < len(upper) else ""
        bottom = lower[index].strip() if index < len(lower) else ""
        merged.append(" ".join(part for part in (top, bottom) if part))
    return merged


def detect_structure(grid: list[list[str]]) -> dict:
    """
    Walk the grid once and label every row.

    Returns:
        {
          'title': str,              the area name from the top row
          'total_declared': int|None the sample count claimed in the title
          'header_row': [str],       the column header actually used
          'blocks': [ {borehole, area, header_row_index, rows: [row_index, ...]} ],
          'unassigned': [row_index]  data rows found before any borehole header
          'row_areas': {row_index: area_code}   the area each data row sits in
          'areas': [area_code, ...]  every area found, in file order
        }

    A file can hold more than one area. Each time a new area row turns up
    ("CRI1 ... 12 samples", or "Area: PCMI2"), the rows after it belong to
    that area. A borehole header can also name its area: "CRI1 BH_2".
    """
    title = ""
    total_declared = None
    blocks = []
    unassigned = []
    row_areas = {}
    areas = []
    current_area = None
    current_header = None
    current_block = None
    skip = set()

    def note_area(code):
        if code and code not in areas:
            areas.append(code)

    for index, row in enumerate(grid):
        if index in skip:
            continue

        filled = [cell for cell in row if cell.strip()]
        if not filled:
            continue

        found = _borehole_and_area(row)
        if found:
            borehole, area = found
            if area:
                current_area = area
                note_area(area)
            current_block = {"borehole": borehole, "area": current_area,
                             "header_row_index": None, "rows": []}
            blocks.append(current_block)
            continue

        if _row_is_column_header(row):
            header = list(row)
            # Pull in a second header line such as the bare 1 / 2 / 3 under
            # a merged "Titration (ml.)" cell
            if index + 1 < len(grid) and _row_is_header_continuation(grid[index + 1]):
                header = _merge_header_rows(header, grid[index + 1])
                skip.add(index + 1)
            current_header = header
            if current_block is not None and current_block["header_row_index"] is None:
                current_block["header_row_index"] = index
            continue

        area = _row_is_area_header(row, seen_header=current_header is not None)
        if area:
            # A new area: the boreholes that follow belong to it
            current_area = area
            note_area(area)
            current_block = None
            if not title:
                title = " ".join(filled)
                total_declared = _sample_count(title)
            else:
                count = _sample_count(" ".join(filled))
                if count is not None and total_declared is not None:
                    total_declared += count
            continue

        if not title and current_header is None and not blocks:
            # The first meaningful row before any header is the title row
            title = " ".join(filled)
            total_declared = _sample_count(title)
            code = area_code_from_title(title)
            if code:
                current_area = code
                note_area(code)
            continue

        row_areas[index] = current_area
        if current_block is None:
            unassigned.append(index)
        else:
            current_block["rows"].append(index)

    return {
        "title": title,
        "total_declared": total_declared,
        "header_row": current_header or [],
        "blocks": [b for b in blocks if b["rows"]],
        "unassigned": unassigned,
        "row_areas": row_areas,
        "areas": areas,
    }


SAMPLE_COUNT_PATTERNS = (
    re.compile(r"(\d{1,5})\s*(?:samples?|ตัวอย่าง)", re.I),
    re.compile(r"(?:samples?|total|จำนวน)\s*[:=]?\s*(\d{1,5})", re.I),
)


def _sample_count(text: str):
    """
    The sample count declared in the title row, when there is one.

    Deliberately narrow: a Thai address carries stray numbers ("หมู่ที่ 3"),
    so only a number sitting next to the word "samples" counts. Returning None
    simply means the import skips the row-count cross-check.
    """
    for pattern in SAMPLE_COUNT_PATTERNS:
        match = pattern.search(text or "")
        if match:
            return int(match.group(1))
    return None


def area_code_from_title(title: str) -> str:
    """
    The short area code is the first word of the title row.

    "PCMI2 หมู่ที่ 3 บ้านท่าศาลา ..." gives "PCMI2", which is what the sample
    rows carry. "Area: CRI1 ..." gives "CRI1". The full title is kept
    separately as the area name. A title that does not start with a code
    ("Some area with 3 roads") gives "" rather than a made-up code.
    """
    text = (title or "").strip()
    labelled = _labelled_area(text)
    if labelled:
        return labelled
    tokens = text.split()
    if not tokens:
        return ""
    first = tokens[0].strip(",;:")
    if AREA_CODE_PATTERN.match(first) or re.fullmatch(r"[A-Z][A-Z0-9_\-]{1,11}", first):
        return first.upper()
    return ""


def area_code_from_sheet(sheet_name: str | None) -> str:
    """A sheet called "CRI1" or "Area PCMI2" names the area of its rows."""
    name = (sheet_name or "").strip()
    labelled = _labelled_area(name)
    if labelled:
        return labelled
    return name.upper() if AREA_CODE_PATTERN.match(name) else ""


# --------------------------------------------------------------------------
# 3. Map columns to fields
# --------------------------------------------------------------------------
# Each field lists the phrases that identify it, longest/most specific first.
COLUMN_PATTERNS = {
    "sample_name":    ["sample name", "sample no", "sample", "ตัวอย่าง"],
    "depth":          ["depth interval", "depth m", "depth", "ความลึก"],
    "depth_from":     ["depth from", "from m", "from"],
    "depth_to":       ["depth to", "to m", "to"],
    "trial1":         ["titration 1", "titration #1", "trial 1", "#1", "1"],
    "trial2":         ["titration 2", "titration #2", "trial 2", "#2", "2"],
    "trial3":         ["titration 3", "titration #3", "trial 3", "#3", "3"],
    "v_meb":          ["volume of meb", "volume meb", "v meb", "v_meb", "volume"],
    "w_clay":         ["w clay", "w_clay", "weight of clay", "weight clay"],
    "w_meb":          ["w meb", "w_meb", "weight of meb", "weight meb"],
    "cec":            ["cec meq/100g", "cec meq 100g", "cec"],
    "clay_type":      ["type of clay mineral", "type of clay", "clay mineral", "clay type"],
    "mt_resistivity": ["dc resistivity", "mt resistivity", "resistivity"],
    "area_code":      ["area code", "area"],
    "borehole_code":  ["borehole code", "borehole", "bh"],
}

FIELD_LABELS = {
    "sample_name": "Sample Name",
    "depth": "Depth (combined, e.g. 2 - 2.45)",
    "depth_from": "Depth From (m)",
    "depth_to": "Depth To (m)",
    "trial1": "Titration #1 (ml)",
    "trial2": "Titration #2 (ml)",
    "trial3": "Titration #3 (ml)",
    "v_meb": "Volume of MeB (ml)",
    "w_clay": "W_clay (g)",
    "w_meb": "W_MeB (g)",
    "cec": "CEC (meq/100g)",
    "clay_type": "Type of Clay Mineral",
    "mt_resistivity": "DC Resistivity (Ohm.m)",
    "area_code": "Area Code",
    "borehole_code": "Borehole Code",
}


def map_columns(header_row: list[str], overrides: dict | None = None) -> dict:
    """
    Decide which column holds which field.

    Returns {field: column_index}. Anything the patterns cannot place is simply
    left out, and the app then shows the manual column-mapping screen.
    `overrides` is {field: column_index} coming back from that screen and
    always wins.
    """
    headers = [normalise(cell) for cell in header_row]
    mapping = {}
    taken = set()

    # Specific phrases first, so "depth from" never loses to a bare "depth"
    ordered_fields = sorted(
        COLUMN_PATTERNS,
        key=lambda f: -max(len(p) for p in COLUMN_PATTERNS[f]),
    )

    for field in ordered_fields:
        for pattern in COLUMN_PATTERNS[field]:
            for index, header in enumerate(headers):
                if index in taken or not header:
                    continue
                if _header_matches(header, pattern):
                    mapping[field] = index
                    taken.add(index)
                    break
            if field in mapping:
                break

    mapping.update(_infer_titration_columns(headers, mapping, taken))

    for field, index in (overrides or {}).items():
        if index is None or index == "":
            mapping.pop(field, None)
        else:
            mapping[field] = int(index)

    return mapping


def _header_matches(header: str, pattern: str) -> bool:
    if pattern in ("1", "2", "3", "#1", "#2", "#3"):
        return header.strip() in (pattern, pattern.lstrip("#"))
    return pattern in header


def _infer_titration_columns(headers, mapping, taken) -> dict:
    """
    Handle the merged "Titration (ml.)" header whose three readings sit in
    columns labelled only 1, 2 and 3, or not labelled at all.
    """
    found = {}
    if all(f in mapping for f in ("trial1", "trial2", "trial3")):
        return found

    anchor = next(
        (i for i, h in enumerate(headers) if "titration" in h),
        None,
    )
    if anchor is None:
        return found

    free = [i for i in range(anchor, min(anchor + 3, len(headers))) if i not in taken]
    for field, index in zip(("trial1", "trial2", "trial3"), free):
        if field not in mapping:
            found[field] = index
    return found


# --------------------------------------------------------------------------
# Value parsing
# --------------------------------------------------------------------------
DEPTH_SPLIT = re.compile(r"\s*(?:-|–|—|to|ถึง)\s*", re.I)


def parse_number(text):
    """
    Turn a cell into a float.

    Copes with thousands separators, a stray unit, and the various dashes used
    for a minus sign. Returns None for anything blank or unreadable.
    """
    if text is None:
        return None
    if isinstance(text, (int, float)):
        return float(text)

    raw = str(text).strip()
    if not raw or raw in {"-", "–", "—", "n/a", "na", "nd", "."}:
        return None

    cleaned = raw.replace("−", "-").replace(",", "")
    cleaned = re.sub(r"[^\d.\-+eE]", "", cleaned)
    if cleaned in ("", "-", "+", "."):
        return None
    try:
        return float(cleaned)
    except ValueError:
        return None


def parse_depth(text):
    """
    Parse "2 - 2.45" into (2.0, 2.45).

    A single number gives (value, None). Unreadable text gives (None, None).
    """
    if text is None:
        return (None, None)

    raw = str(text).strip()
    if not raw:
        return (None, None)

    parts = [p for p in DEPTH_SPLIT.split(raw) if p.strip()]
    if len(parts) >= 2:
        return (parse_number(parts[0]), parse_number(parts[1]))

    single = parse_number(raw)
    return (single, None)


# --------------------------------------------------------------------------
# 4. Build the preview
# --------------------------------------------------------------------------
def build_preview(grid, structure, mapping, existing_lookup=None,
                  sheet_name=None, default_area="") -> dict:
    """
    Turn the detected structure into rows the user can review before saving.

    `existing_lookup(borehole, name, depth_from, area_code)` is called to spot
    samples that are already stored; pass None to skip the duplicate check.

    Where each row's area code comes from, first match wins:
        1. an "Area Code" column in the row itself
        2. the area row or borehole header above it in the file
           ("CRI1 ... 12 samples", "Area: PCMI2", "CRI1 BH_2")
        3. the sheet name, when it is an area code ("CRI1")
        4. `default_area`, typed in by the user on the review screen

    Every row carries its own `issues` list. Nothing here touches the database.
    """
    file_area = area_code_from_title(structure.get("title", ""))
    sheet_area = area_code_from_sheet(sheet_name)
    default_area = (default_area or "").strip().upper()
    row_areas = structure.get("row_areas") or {}
    rows = []
    seen_in_file = set()

    blocks = list(structure.get("blocks") or [])
    if structure.get("unassigned"):
        blocks.append({"borehole": "", "rows": structure["unassigned"]})

    for block in blocks:
        for row_index in block["rows"]:
            if len(rows) >= MAX_PREVIEW_ROWS:
                break
            row = grid[row_index]
            area = (row_areas.get(row_index) or block.get("area") or file_area
                    or sheet_area or default_area)
            parsed = _parse_row(row, mapping, block.get("borehole", ""), area)
            parsed["row_number"] = row_index + 1
            parsed["area_source"] = (
                "column" if mapping.get("area_code") is not None and _cell(row, mapping, "area_code")
                else "file" if (row_areas.get(row_index) or block.get("area") or file_area)
                else "sheet" if sheet_area
                else "typed" if default_area
                else ""
            )
            _check_row(parsed, seen_in_file, existing_lookup)
            rows.append(parsed)

    warnings = []
    no_area = sum(1 for row in rows if not row["area_code"])
    if no_area:
        warnings.append(
            f"{no_area} row{' has' if no_area == 1 else 's have'} no area code. "
            f"Type one in the Area code box below, or add a row such as "
            f"\"Area: CRI1\" above those boreholes in the file."
        )
    declared = structure.get("total_declared")
    if declared and declared != len(rows):
        warnings.append(
            f"The file's title row says {declared} samples, but {len(rows)} data rows "
            f"were found. Check the preview before importing."
        )
    if not structure.get("blocks"):
        warnings.append(
            "No borehole header rows (such as BH_1) were recognised. "
            "Every sample will be imported without a borehole code unless you set one."
        )

    missing_required = [f for f in ("sample_name",) if f not in mapping]
    if missing_required:
        warnings.append(
            "The Sample Name column could not be matched automatically. "
            "Please pick it on the column mapping screen."
        )

    return {
        "area_code": file_area or sheet_area or default_area,
        "areas": sorted({row["area_code"] for row in rows if row["area_code"]}),
        "area_name": structure.get("title", ""),
        "rows": rows,
        "summary": summarise(rows, structure),
        "warnings": warnings,
        "mapping": mapping,
        "header_row": structure.get("header_row", []),
    }


def _cell(row, mapping, field) -> str:
    index = mapping.get(field)
    if index is None or index >= len(row):
        return ""
    return row[index]


def _parse_row(row, mapping, borehole, area_code) -> dict:
    def cell(field):
        return _cell(row, mapping, field)

    depth_from, depth_to = (None, None)
    if "depth" in mapping:
        depth_from, depth_to = parse_depth(cell("depth"))
    if "depth_from" in mapping:
        depth_from = parse_number(cell("depth_from"))
    if "depth_to" in mapping:
        depth_to = parse_number(cell("depth_to"))

    trials = [parse_number(cell(f)) for f in ("trial1", "trial2", "trial3")]
    w_clay = parse_number(cell("w_clay"))
    w_meb = parse_number(cell("w_meb"))

    v_meb_file = parse_number(cell("v_meb"))
    v_meb_calc = geochem.average_titration(trials)
    cec_file = parse_number(cell("cec"))

    cec_calc = geochem.cec_meq_per_100g(
        v_meb_calc if v_meb_calc is not None else v_meb_file, w_clay, w_meb
    )

    # The example lab file carries no weights, so the file's CEC is kept and
    # flagged rather than silently dropped.
    cec_used = cec_calc if cec_calc is not None else cec_file
    cec_imported = cec_calc is None and cec_file is not None

    matches = geochem.classify_clay(cec_used)

    return {
        "sample_name": (cell("sample_name") or "").strip(),
        "area_code": (cell("area_code") or area_code or "").strip().upper(),
        "borehole_code": (cell("borehole_code") or borehole or "").strip(),
        "depth_from": depth_from,
        "depth_to": depth_to,
        "depth_display": geochem.format_depth(depth_from, depth_to),
        "trial1": trials[0],
        "trial2": trials[1],
        "trial3": trials[2],
        "w_clay": w_clay,
        "w_meb": w_meb,
        "v_meb_file": v_meb_file,
        "v_meb": v_meb_calc if v_meb_calc is not None else v_meb_file,
        "cec_file": cec_file,
        "cec_calculated": cec_calc,
        "cec": cec_used,
        "cec_imported": cec_imported,
        "mt_resistivity": parse_number(cell("mt_resistivity")),
        "clay_type_file": (cell("clay_type") or "").strip(),
        "clay_label": geochem.clay_label(matches),
        "clay_names": geochem.clay_names(matches),
        "issues": [],
        "action": "import",
    }


def _check_row(parsed, seen_in_file, existing_lookup) -> None:
    """Attach every problem found with one row, as plain readable sentences."""
    issues = parsed["issues"]

    if not parsed["sample_name"]:
        issues.append({"level": "error", "field": "sample_name",
                       "message": "No sample name in this row."})

    if parsed["depth_from"] is None:
        issues.append({"level": "warn", "field": "depth",
                       "message": "Depth could not be read, so this sample will not "
                                  "appear on the stratigraphic column."})
    elif parsed["depth_to"] is not None and parsed["depth_to"] < parsed["depth_from"]:
        issues.append({"level": "error", "field": "depth",
                       "message": "Depth To is shallower than Depth From."})

    if parsed["cec"] is None:
        issues.append({"level": "warn", "field": "cec",
                       "message": "No CEC value, and not enough data to calculate one."})

    if parsed["cec_imported"]:
        issues.append({"level": "info", "field": "cec",
                       "message": "CEC imported, not recalculated. Add W_clay and W_MeB "
                                  "later to recalculate it."})

    if parsed["cec_calculated"] is not None and parsed["cec_file"] is not None:
        gap = abs(parsed["cec_calculated"] - parsed["cec_file"])
        if gap > CEC_TOLERANCE:
            issues.append({
                "level": "warn", "field": "cec",
                "message": f"The file says CEC {parsed['cec_file']:.2f} but the formula "
                           f"gives {parsed['cec_calculated']:.2f}. The calculated value "
                           f"will be used.",
            })

    if parsed["v_meb_file"] is not None and parsed["v_meb"] is not None:
        if abs(parsed["v_meb_file"] - parsed["v_meb"]) > 0.02:
            issues.append({
                "level": "warn", "field": "v_meb",
                "message": f"Volume of MeB in the file ({parsed['v_meb_file']:.2f} ml) does "
                           f"not match the average of the titration readings "
                           f"({parsed['v_meb']:.2f} ml).",
            })

    file_clay = normalise(parsed["clay_type_file"])
    if file_clay and file_clay not in ("-", "none"):
        if not _clay_agrees(parsed["clay_type_file"], parsed["clay_names"]):
            issues.append({
                "level": "info", "field": "clay_type",
                "message": f"The file says \"{parsed['clay_type_file']}\"; the "
                           f"classification table gives \"{parsed['clay_label']}\".",
            })

    # The same borehole code can be reused in another area, so the area is
    # part of what makes a sample unique.
    key = (parsed["area_code"], parsed["borehole_code"], parsed["sample_name"],
           parsed["depth_from"])
    if key in seen_in_file:
        issues.append({"level": "warn", "field": "sample_name",
                       "message": "This sample appears more than once in the file."})
        parsed["duplicate_in_file"] = True
    seen_in_file.add(key)

    parsed["duplicate_existing"] = False
    if existing_lookup and parsed["sample_name"]:
        found = existing_lookup(parsed["borehole_code"], parsed["sample_name"],
                                parsed["depth_from"], parsed["area_code"])
        if found:
            parsed["duplicate_existing"] = True
            parsed["existing_id"] = found.get("id")
            issues.append({"level": "warn", "field": "sample_name",
                           "message": "A sample with this area, borehole, name and depth "
                                      "is already saved."})

    if any(issue["level"] == "error" for issue in issues):
        parsed["action"] = "skip"


def _clay_agrees(file_value, computed_names) -> bool:
    """
    Compare the file's clay column with the classification result.

    The lab writes short codes ("Kln, Mix"), the table gives full names, so
    both are reduced to their first three letters before comparing.
    """
    def stems(text):
        return {
            part.strip()[:3].lower()
            for part in re.split(r"[,/;]+", str(text or ""))
            if part.strip()
        }

    file_stems = stems(file_value)
    computed_stems = stems(", ".join(computed_names))

    if not file_stems or not computed_stems:
        return True
    if "non" in file_stems and "non" in computed_stems:
        return True
    return bool(file_stems & computed_stems)


def summarise(rows, structure) -> dict:
    holes = sorted({(row["area_code"], row["borehole_code"])
                    for row in rows if row["borehole_code"]})
    areas = sorted({row["area_code"] for row in rows if row["area_code"]})
    errors = sum(1 for row in rows if any(i["level"] == "error" for i in row["issues"]))
    warns = sum(1 for row in rows if any(i["level"] == "warn" for i in row["issues"]))
    duplicates = sum(1 for row in rows if row.get("duplicate_existing"))

    return {
        "row_count": len(rows),
        "borehole_count": len(holes),
        "boreholes": [f"{area} · {code}" if area else code for area, code in holes],
        "areas": areas,
        "area_count": len(areas),
        "rows_without_area": sum(1 for row in rows if not row["area_code"]),
        "error_count": errors,
        "warning_count": warns,
        "duplicate_count": duplicates,
        "imported_cec_count": sum(1 for row in rows if row["cec_imported"]),
        "declared_total": structure.get("total_declared"),
    }


# --------------------------------------------------------------------------
# Borehole coordinate files
# --------------------------------------------------------------------------
BOREHOLE_PATTERNS = {
    "borehole_code":    ["borehole code", "borehole", "bh", "hole", "name", "station", "point"],
    "area_code":        ["area code", "area"],
    "latitude":         ["latitude", "lat"],
    "longitude":        ["longitude", "lon", "lng"],
    "utm_easting":      ["easting", "east", "utm e", "x"],
    "utm_northing":     ["northing", "north", "utm n", "y"],
    "utm_zone":         ["zone"],
    "utm_hemisphere":   ["hemisphere", "hemi"],
    "ground_elevation": ["ground elevation", "elevation", "elev", "rl"],
    "total_depth":      ["total depth", "depth"],
}


def parse_borehole_file(data: bytes, filename: str, sheet=None) -> dict:
    """
    Read a simple one-row-per-borehole coordinate file.

    Unlike the lab results file this really is a plain table, so the first row
    containing a recognisable header is used and everything below it is data.
    """
    grid = read_grid(data, filename, sheet)
    if not grid:
        raise ImportError_("That file appears to be empty.")

    header_index = None
    for index, row in enumerate(grid[:20]):
        headers = [normalise(cell) for cell in row]
        if any(h.startswith(("borehole", "bh", "hole", "name", "station", "point"))
               for h in headers if h):
            header_index = index
            break
    if header_index is None:
        header_index = 0

    headers = [normalise(cell) for cell in grid[header_index]]
    mapping = {}
    taken = set()
    for field, patterns in BOREHOLE_PATTERNS.items():
        for pattern in patterns:
            for index, header in enumerate(headers):
                if index in taken or not header:
                    continue
                if header == pattern or pattern in header:
                    mapping[field] = index
                    taken.add(index)
                    break
            if field in mapping:
                break

    rows = []
    for row in grid[header_index + 1:]:
        if not any(cell.strip() for cell in row):
            continue

        def cell(field):
            index = mapping.get(field)
            return row[index] if index is not None and index < len(row) else ""

        code, area = split_hole_name(cell("borehole_code"), cell("area_code"))
        if not code:
            continue

        zone, band_hemisphere = parse_utm_zone(cell("utm_zone"))
        hemisphere = cell("utm_hemisphere").strip()[:1].upper() or band_hemisphere or "N"

        rows.append({
            "borehole_code": code,
            "area_code": area,
            "latitude": parse_number(cell("latitude")),
            "longitude": parse_number(cell("longitude")),
            "utm_easting": parse_number(cell("utm_easting")),
            "utm_northing": parse_number(cell("utm_northing")),
            "utm_zone": zone,
            "utm_hemisphere": hemisphere,
            "ground_elevation": parse_number(cell("ground_elevation")),
            "total_depth": parse_number(cell("total_depth")),
        })

    return {"rows": rows, "mapping": mapping, "header_row": grid[header_index]}


def split_hole_name(name: str, area: str = "") -> tuple[str, str]:
    """
    A survey point name split into (borehole code, area code).

        'CRI1_BH-1', area 'CRI1'  -> ('BH_1', 'CRI1')
        'PCMI2-1',   area 'PCMI2' -> ('BH_1', 'PCMI2')    no 'BH' in the name
        'CRI1_BH-1', no area      -> ('BH_1', 'CRI1')     area read from the name
        'BH_2'                    -> ('BH_2', '')
        'YPRE1_BH-3/1'            -> ('BH_3/1', 'YPRE1')
    """
    raw = (name or "").strip()
    area = (area or "").strip().upper()
    if not raw:
        return "", area

    rest = raw
    if area and raw.upper().startswith(area):
        rest = raw[len(area):].strip(" _-.:#")

    plain = looks_like_borehole(rest)
    if plain:
        return plain, area
    if re.fullmatch(r"\d+[A-Za-z]?(?:/\d+)?", rest):
        return f"BH_{rest.upper()}", area

    match = BOREHOLE_SEARCH.search(raw)
    if match:
        if not area:
            prefix = raw[:match.start()].strip(" _-.:#")
            area = looks_like_area_code(prefix) or ""
        return f"BH_{match.group(1).upper()}", area

    # Something we cannot read as a borehole: keep the name as it is written
    return raw, area


def parse_utm_zone(text) -> tuple[int | None, str | None]:
    """
    '47' -> (47, None);  '47N' -> (47, 'N');  '47Q' -> (47, 'N');  '47S' -> (47, 'S').

    A letter after the zone is either the hemisphere (N or S) or the MGRS
    latitude band (C to X; N to X are north of the equator). Thailand is in
    bands N, P and Q, all northern. 'S' is read as "south", the usual meaning
    when people write a hemisphere.
    """
    raw = str(text or "").strip().upper()
    match = re.match(r"^(\d{1,2})\s*([A-Z])?", raw)
    if not match:
        number = parse_number(raw)
        return (int(number) if number is not None else None), None
    zone = int(match.group(1))
    letter = match.group(2)
    if not letter:
        return zone, None
    if letter == "S":
        return zone, "S"
    if "N" <= letter <= "X":
        return zone, "N"
    if "C" <= letter <= "M":
        return zone, "S"
    return zone, None


# --------------------------------------------------------------------------
# Blank template
# --------------------------------------------------------------------------
TEMPLATE_HEADERS = [
    "Sample name", "Depth (m.)", "Titration (ml.) #1", "#2", "#3",
    "Volume of MeB (ml.)", "W_clay (g)", "W_MeB (g)", "CEC (meq/100g)",
    "Type of clay mineral", "DC Resistivity (Ohm.m)",
]

TEMPLATE_EXAMPLE = [
    ["D:2.00", "2 - 2.45", "1.7", "1.5", "1.5", "1.57", "0.9", "10", "5.44", "Kln, Mix", "45.2"],
    ["SS.4", "4.5 - 4.95", "0.5", "0.4", "0.5", "0.47", "0.9", "10", "1.62", "None-classified", "62.0"],
]


def build_template_xlsx() -> bytes:
    """A blank lab-results workbook in the shape the importer expects."""
    try:
        import openpyxl
    except ImportError:
        raise ImportError_(
            "Creating the template needs the openpyxl package. "
            "Run: pip install -r requirements.txt"
        )

    from openpyxl.styles import Alignment, Font, PatternFill

    book = openpyxl.Workbook()
    sheet = book.active
    sheet.title = "Lab results"

    bold = Font(bold=True)
    header_fill = PatternFill("solid", fgColor="DCE9FB")
    borehole_font = Font(bold=True, size=12)

    sheet.append(["CRI1  Area name here", "", "", "", "", "", "", "", "", "4 samples"])
    sheet["A1"].font = bold
    sheet.append([])

    row_number = 3
    for borehole in ("BH_1", "BH_2"):
        sheet.cell(row=row_number, column=1, value=borehole).font = borehole_font
        row_number += 1

        for column, title in enumerate(TEMPLATE_HEADERS, start=1):
            cell = sheet.cell(row=row_number, column=column, value=title)
            cell.font = bold
            cell.fill = header_fill
            cell.alignment = Alignment(wrap_text=True, vertical="center")
        row_number += 1

        for example in TEMPLATE_EXAMPLE:
            for column, value in enumerate(example, start=1):
                sheet.cell(row=row_number, column=column, value=value)
            row_number += 1
        row_number += 1

    widths = [16, 14, 12, 8, 8, 16, 12, 12, 16, 22, 18]
    for index, width in enumerate(widths, start=1):
        sheet.column_dimensions[openpyxl.utils.get_column_letter(index)].width = width

    notes = book.create_sheet("How to use")
    for line in [
        ["How to fill in this template"],
        [],
        ["1. Put the area code and name in the first row, with the sample count,"],
        ["   for example:  CRI1  Ban Tha Sala ...      12 samples"],
        ["2. Write the borehole code (BH_1, BH_2, ...) on its own row."],
        ["3. Keep the column header row under each borehole."],
        ["4. Add one row per sample underneath."],
        ["5. Depth can be written as a range, for example 2 - 2.45."],
        [],
        ["Several areas in one file"],
        ["The area code is read from the file. Any of these start a new area:"],
        ["  - a title row such as  PCMI2  Ban ...   10 samples"],
        ["  - a row with just  Area: PCMI2"],
        ["  - a borehole row that names its area:  PCMI2 BH_1"],
        ["  - an 'Area Code' column, filled in on every sample row"],
        ["  - one sheet per area, with the sheet named after the area code"],
        ["The same borehole code (BH_1) in two areas is kept as two boreholes."],
        [],
        ["W_clay and W_MeB are optional. When both are filled in, the program"],
        ["recalculates CEC with the AFNOR formula instead of trusting the file."],
        [],
        ["CEC (meq/100g) = (100 / W_clay) x V_MeB x (W_MeB / 320)"],
    ]:
        notes.append(line)
    notes["A1"].font = bold
    notes.column_dimensions["A"].width = 76

    buffer = io.BytesIO()
    book.save(buffer)
    return buffer.getvalue()
