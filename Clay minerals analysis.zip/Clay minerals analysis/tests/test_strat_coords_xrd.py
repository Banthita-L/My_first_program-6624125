"""
Tests for the stratigraphy helpers, the coordinate conversion and the XRD
maths. Run with:  python tests/test_strat_coords_xrd.py
"""

import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import coords   # noqa: E402
import geochem  # noqa: E402
import xrd      # noqa: E402


def sample(name, top, bottom, cec, names):
    return {
        "id": abs(hash(name)) % 10000,
        "sample_name": name,
        "depth_from": top,
        "depth_to": bottom,
        "average_cec": cec,
        "clay_label": ", ".join(n[:3] for n in names),
        "clay_names": names,
    }


BH1 = [
    sample("D:2.00", 2, 2.45, 5.44, ["Kaolinite", "Mixed-layer"]),
    sample("SS.4", 4.5, 4.95, 1.62, ["None-classified"]),
    sample("SS.9", 12, 12.45, 0.35, ["None-classified"]),
    sample("D:15.00", 15, 15.45, 13.31, ["Mixed-layer"]),
]


# ------------------------------------------------------------ stratigraphy
def test_samples_sort_down_hole():
    shuffled = [BH1[2], BH1[0], BH1[3], BH1[1]]
    names = [s["sample_name"] for s in geochem.sort_down_hole(shuffled)]
    assert names == ["D:2.00", "SS.4", "SS.9", "D:15.00"], names


def test_samples_without_depth_sink_to_the_end():
    mixed = BH1 + [sample("NO_DEPTH", None, None, 5, ["Kaolinite"])]
    assert geochem.sort_down_hole(mixed)[-1]["sample_name"] == "NO_DEPTH"


def test_transition_depth_is_a_range_not_a_point():
    """
    The exact change depth is unknown: it lies between the bottom of the
    upper sample and the top of the lower one.
    """
    transitions = geochem.clay_transitions(BH1)
    assert len(transitions) == 2, [t["label"] for t in transitions]

    first = transitions[0]
    assert first["from_depth"] == 2.45 and first["to_depth"] == 4.5
    assert first["above"] == "Kaolinite, Mixed-layer"
    assert first["below"] == "None-classified"
    assert first["range_display"] == "2.45 – 4.5"

    second = transitions[1]
    assert second["from_depth"] == 12.45 and second["to_depth"] == 15.0
    assert second["below"] == "Mixed-layer"
    assert abs(second["depth"] - 13.725) < 1e-6
    assert "about 13.7 m" in second["label"], second["label"]


def test_no_transition_when_the_mineral_does_not_change():
    same = [
        sample("A", 1, 1.45, 5, ["Kaolinite"]),
        sample("B", 3, 3.45, 6, ["Kaolinite"]),
    ]
    assert geochem.clay_transitions(same) == []


def test_step_plot_holds_each_value_across_its_interval():
    points = geochem.step_plot_points(BH1[:2])
    # top of 1, bottom of 1, carry across the gap, then top and bottom of 2
    assert points[0] == {"depth": 2.0, "cec": 5.44}
    assert points[1] == {"depth": 2.45, "cec": 5.44}
    assert points[2] == {"depth": 4.5, "cec": 5.44}      # carried, not interpolated
    assert points[3] == {"depth": 4.5, "cec": 1.62}      # the step itself
    assert points[4] == {"depth": 4.95, "cec": 1.62}


def test_step_plot_never_invents_a_slope():
    """Between two samples the value must stay flat, then jump."""
    points = geochem.step_plot_points(BH1)
    for before, after in zip(points, points[1:]):
        changed_depth = before["depth"] != after["depth"]
        changed_value = before["cec"] != after["cec"]
        assert not (changed_depth and changed_value), (before, after)


def test_dominant_clay_prefers_a_classified_mineral():
    mixed = [
        sample("A", 1, 1.45, 1, ["None-classified"]),
        sample("B", 3, 3.45, 1, ["None-classified"]),
        sample("C", 5, 5.45, 5, ["Kaolinite"]),
    ]
    assert geochem.dominant_clay(mixed) == "Kaolinite"
    assert geochem.dominant_clay([]) == geochem.NOT_CLASSIFIED


def test_stratigraphic_column_blocks_and_extent():
    beds = [{"depth_from": 0, "depth_to": 6, "description": "Silty clay", "color": "#c8b89a"}]
    column = geochem.stratigraphic_column(BH1, beds)

    assert len(column["blocks"]) == 4
    assert column["depth_min"] == 0 and column["depth_max"] == 15.45
    assert column["blocks"][0]["color"] == geochem.clay_color("Kaolinite")
    assert column["lithology"][0]["description"] == "Silty clay"
    assert len(column["transitions"]) == 2


def test_every_mineral_has_its_own_colour():
    names = [name for name, _, _, _ in geochem.CLAY_RANGES] + [geochem.NOT_CLASSIFIED]
    colors = [geochem.clay_color(n) for n in names]
    assert len(set(colors)) == len(colors), "two minerals share a colour"


def test_borehole_summary():
    summary = geochem.borehole_summary("BH_1", BH1)
    assert summary["sample_count"] == 4
    assert summary["max_depth"] == 15.45
    assert abs(summary["average_cec"] - (5.44 + 1.62 + 0.35 + 13.31) / 4) < 1e-9


# -------------------------------------------------------------- coordinates
def test_utm_round_trip_is_millimetre_accurate():
    latitude, longitude = 18.4147, 98.6730            # Chom Thong, Chiang Mai
    easting, northing, zone, hemisphere = coords.latlon_to_utm(latitude, longitude)
    assert zone == 47 and hemisphere == "N"

    back_lat, back_lon = coords.utm_to_latlon(easting, northing, zone, hemisphere)
    assert abs(back_lat - latitude) * 111320 < 0.01   # under a centimetre
    assert abs(back_lon - longitude) * 105000 < 0.01


def test_central_meridian_is_exact():
    """500,000 m east in zone 47 is exactly 99 degrees east, by definition."""
    _, longitude = coords.utm_to_latlon(500000, 2036000, 47, "N")
    assert abs(longitude - 99.0) < 1e-9


def test_southern_hemisphere():
    latitude, longitude = -33.8688, 151.2093          # Sydney
    easting, northing, zone, hemisphere = coords.latlon_to_utm(latitude, longitude)
    assert hemisphere == "S"
    back_lat, back_lon = coords.utm_to_latlon(easting, northing, zone, hemisphere)
    assert abs(back_lat - latitude) < 1e-6 and abs(back_lon - longitude) < 1e-6


def test_impossible_coordinates_are_refused():
    for call in (
        lambda: coords.utm_to_latlon(50, 2036000, 47),           # easting too small
        lambda: coords.utm_to_latlon(500000, 2036000, 99),       # no such zone
        lambda: coords.validate_latlon(95, 100),                 # latitude past the pole
        lambda: coords.validate_latlon(18, 200),                 # longitude past the line
        lambda: coords.utm_to_latlon("abc", 2036000, 47),        # not a number
    ):
        try:
            call()
            raise AssertionError("that should have been refused")
        except coords.CoordinateError:
            pass


def test_resolve_prefers_latlon_and_tolerates_nothing():
    assert coords.resolve({"latitude": 18.4, "longitude": 98.6}) == (18.4, 98.6)

    latitude, _ = coords.resolve(
        {"utm_easting": 500000, "utm_northing": 2036000, "utm_zone": 47, "utm_hemisphere": "N"})
    assert latitude is not None

    assert coords.resolve({}) == (None, None)
    assert coords.resolve({"latitude": "", "longitude": ""}) == (None, None)


# ---------------------------------------------------------------- XRD maths
def test_bragg_law_matches_the_reference_table():
    """Each mineral's d-spacing must give back its tabulated 2-theta."""
    for d, expected in [(7.15, 12.37), (3.34, 26.66), (10.0, 8.84), (14.0, 6.31)]:
        assert abs(xrd.two_theta_for_d(d) - expected) < 0.02, d
        assert abs(xrd.d_spacing(expected) - d) < 0.01, expected


def test_bragg_law_is_undefined_at_zero():
    assert xrd.d_spacing(0) is None
    assert xrd.d_spacing(-5) is None
    assert xrd.two_theta_for_d(0) is None
    assert xrd.two_theta_for_d(0.1) is None     # beyond the reach of the wavelength


def test_changing_the_source_moves_the_angles():
    """Kaolinite 001 sits at 12.37 with Cu, but near 14.4 with Co."""
    assert abs(xrd.two_theta_for_d(7.15, 1.5406) - 12.37) < 0.02
    assert abs(xrd.two_theta_for_d(7.15, 1.7902) - 14.38) < 0.05


def test_peak_finding_on_a_known_signal():
    import numpy as np
    two_theta = np.linspace(2, 40, 1200)
    truth = [(6.31, 300), (8.84, 420), (12.37, 760), (26.66, 950)]
    intensity = sum(h * np.exp(-((two_theta - p) ** 2) / (2 * 0.18 ** 2)) for p, h in truth)

    peaks = xrd.find_peaks(two_theta, intensity, min_prominence_ratio=0.05)
    found = sorted(p["two_theta"] for p in peaks)
    assert len(found) == 4, found
    for (expected, _), got in zip(truth, found):
        assert abs(got - expected) < 0.05, (expected, got)


def test_background_is_removed_without_eating_the_peaks():
    import numpy as np
    two_theta = np.linspace(2, 40, 900)
    background = 200 * np.exp(-two_theta / 8) + 40
    peak = 500 * np.exp(-((two_theta - 12.37) ** 2) / (2 * 0.2 ** 2))

    _, corrected, baseline = xrd.prepare_curve(list(zip(two_theta, background + peak)))
    edge = corrected[:40]
    assert edge.max() < 60, "sloping background was not removed"
    assert corrected.max() > 400, "the peak was flattened along with the background"


def test_identification_confidence_falls_off_with_distance():
    reference = [{"mineral": "Kaolinite", "two_theta": 12.37, "d_spacing": 7.15,
                  "tolerance": 0.4, "rir": 0.7}]

    exact = xrd.identify([{"two_theta": 12.37, "intensity": 100, "area": 50}], reference)[0]
    assert exact["mineral"] == "Kaolinite" and exact["confidence"] > 0.99

    near = xrd.identify([{"two_theta": 12.57, "intensity": 100, "area": 50}], reference)[0]
    assert near["mineral"] == "Kaolinite" and 0.4 < near["confidence"] < 0.6

    far = xrd.identify([{"two_theta": 15.0, "intensity": 100, "area": 50}], reference)[0]
    assert far["mineral"] == "" and far["confidence"] is None


def test_percentages_are_normalised_and_rir_weighted():
    peaks = [
        {"mineral": "Quartz", "area": 100, "confidence": 0.9, "rir": 1.0},
        {"mineral": "Kaolinite", "area": 100, "confidence": 0.9, "rir": 0.5},
    ]
    estimates = xrd.estimate_percentages(peaks)
    assert abs(sum(e["percent"] for e in estimates) - 100.0) < 0.01

    by_name = {e["mineral"]: e["percent"] for e in estimates}
    # equal areas, but quartz diffracts twice as strongly, so it is half as abundant
    assert abs(by_name["Kaolinite"] - 2 * by_name["Quartz"]) < 0.05


def test_low_confidence_is_flagged():
    flagged = xrd.flag_low_confidence([
        {"mineral": "A", "percent": 50, "confidence": 0.9},
        {"mineral": "B", "percent": 50, "confidence": 0.2},
    ])
    assert flagged[0]["low_confidence"] is False
    assert flagged[1]["low_confidence"] is True


def test_unmatched_peaks_do_not_become_percentages():
    assert xrd.estimate_percentages([{"mineral": "", "area": 100}]) == []
    assert xrd.estimate_percentages([]) == []


def test_calibration_rejects_useless_input():
    good_y = [{"pixel": 500, "value": 0}, {"pixel": 100, "value": 1000}]
    for x_points in (
        [{"pixel": 10, "value": 5}],                                   # only one point
        [{"pixel": 10, "value": 5}, {"pixel": 10, "value": 35}],       # same place
        [{"pixel": 10, "value": 5}, {"pixel": 800, "value": 5}],       # same value
        [{"pixel": 10}, {"pixel": 800, "value": 35}],                  # missing value
    ):
        try:
            xrd.AxisCalibration(x_points, good_y)
            raise AssertionError("that calibration should have been refused")
        except xrd.XRDError:
            pass


def test_calibration_maps_pixels_to_values():
    cal = xrd.AxisCalibration(
        [{"pixel": 100, "value": 5}, {"pixel": 900, "value": 45}],
        [{"pixel": 500, "value": 0}, {"pixel": 100, "value": 1000}],
    )
    assert abs(cal.x_to_value(500) - 25.0) < 1e-9     # halfway along
    assert abs(cal.y_to_value(300) - 500.0) < 1e-9    # halfway up


if __name__ == "__main__":
    failures = 0
    for name, function in sorted(globals().items()):
        if name.startswith("test_") and callable(function):
            try:
                function()
                print(f"PASS  {name}")
            except AssertionError as error:
                failures += 1
                print(f"FAIL  {name}: {error}")
            except Exception as error:                       # noqa: BLE001
                failures += 1
                print(f"ERROR {name}: {type(error).__name__}: {error}")
    print(f"\n{'All tests passed.' if not failures else f'{failures} test(s) failed.'}")
    sys.exit(1 if failures else 0)
