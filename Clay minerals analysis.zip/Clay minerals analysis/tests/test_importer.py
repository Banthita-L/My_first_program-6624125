"""
Tests for the bulk importer: file structure detection, column matching,
value parsing and the validation messages.

Run with:   python tests/test_importer.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import importer  # noqa: E402

# The shape of the project's lab file: Thai title row with the sample count,
# a borehole header on its own row, a two-line column header with the merged
# "Titration (ml.)" cell, then one row per sample. No W_clay or W_MeB columns.
LAB_CSV = """PCMI2 หมู่ที่ 3 บ้านท่าศาลา ตำบลข่วงเปา อำเภอจอมทอง จังหวัดเชียงใหม่,,,,,,,19 samples

BH_1,,,,,,,
Sample name,Depth (m.),Titration (ml.),,,Volume of MeB (ml.),CEC (meq/100g),Type of clay mineral
,,1,2,3,,,
D:2.00,2 - 2.45,1.7,1.5,1.5,1.57,5.44,"Kln, Mix"
SS.4,4.5 - 4.95,0.5,0.4,0.5,0.47,1.62,None-classified

BH_2,,,,,,,
Sample name,Depth (m.),Titration (ml.),,,Volume of MeB (ml.),CEC (meq/100g),Type of clay mineral
,,1,2,3,,,
D:2.00,2 - 2.45,1.1,1.0,1.1,1.07,3.70,"Kln, Mix"
"""


def grid_of(text):
    return importer.read_grid(text.encode("utf-8"), "test.csv")


def test_structure_detection():
    structure = importer.detect_structure(grid_of(LAB_CSV))

    assert structure["title"].startswith("PCMI2"), structure["title"]
    assert structure["total_declared"] == 19, structure["total_declared"]
    assert [b["borehole"] for b in structure["blocks"]] == ["BH_1", "BH_2"]
    assert [len(b["rows"]) for b in structure["blocks"]] == [2, 1]
    assert not structure["unassigned"]


def test_sample_count_ignores_address_numbers():
    """"หมู่ที่ 3" must not be mistaken for the sample count."""
    structure = importer.detect_structure(grid_of(LAB_CSV))
    assert structure["total_declared"] == 19

    # No count at all is better than a wrong one
    plain = "Some area with 3 roads,,,\nBH_1,,,\nSample name,Depth (m.),CEC (meq/100g),Type of clay mineral\nA,1 - 2,5,Kln\n"
    assert importer.detect_structure(grid_of(plain))["total_declared"] is None


def test_two_line_header_is_merged():
    """The bare 1 / 2 / 3 under a merged "Titration" cell belong to the header."""
    structure = importer.detect_structure(grid_of(LAB_CSV))
    header = structure["header_row"]
    assert "Titration (ml.) 1" in header, header
    assert header[3] == "2" and header[4] == "3", header

    # and that line must not be counted as a sample
    assert sum(len(b["rows"]) for b in structure["blocks"]) == 3


def test_column_mapping():
    structure = importer.detect_structure(grid_of(LAB_CSV))
    mapping = importer.map_columns(structure["header_row"])

    assert mapping["sample_name"] == 0
    assert mapping["depth"] == 1
    assert mapping["trial1"] == 2
    assert mapping["trial2"] == 3
    assert mapping["trial3"] == 4
    assert mapping["v_meb"] == 5
    assert mapping["cec"] == 6
    assert mapping["clay_type"] == 7


def test_mapping_overrides_win():
    structure = importer.detect_structure(grid_of(LAB_CSV))
    mapping = importer.map_columns(structure["header_row"], {"sample_name": 3, "cec": None})
    assert mapping["sample_name"] == 3
    assert "cec" not in mapping


def test_depth_parsing():
    assert importer.parse_depth("2 - 2.45") == (2.0, 2.45)
    assert importer.parse_depth("2–2.45") == (2.0, 2.45)       # en dash
    assert importer.parse_depth("4.5 to 4.95") == (4.5, 4.95)
    assert importer.parse_depth("12") == (12.0, None)
    assert importer.parse_depth("") == (None, None)
    assert importer.parse_depth("not a depth") == (None, None)


def test_number_parsing():
    assert importer.parse_number("1,234.5") == 1234.5          # thousands separator
    assert importer.parse_number("1.57") == 1.57
    assert importer.parse_number(" 0.9 g ") == 0.9             # stray unit
    assert importer.parse_number("-") is None
    assert importer.parse_number("") is None
    assert importer.parse_number("abc") is None
    assert importer.parse_number(3) == 3.0


def test_borehole_header_shapes():
    assert importer.looks_like_borehole("BH_1") == "BH_1"
    assert importer.looks_like_borehole("BH-2") == "BH_2"
    assert importer.looks_like_borehole("bh 3") == "BH_3"
    assert importer.looks_like_borehole("Borehole 4") == "BH_4"
    assert importer.looks_like_borehole("D:2.00") is None
    assert importer.looks_like_borehole("") is None


def test_preview_keeps_file_cec_when_weights_are_missing():
    """The example lab file has no W_clay or W_MeB, so its CEC must be kept."""
    grid = grid_of(LAB_CSV)
    structure = importer.detect_structure(grid)
    mapping = importer.map_columns(structure["header_row"])
    preview = importer.build_preview(grid, structure, mapping)

    first = preview["rows"][0]
    assert first["sample_name"] == "D:2.00"
    assert first["borehole_code"] == "BH_1"
    assert first["area_code"] == "PCMI2"
    assert first["depth_from"] == 2.0 and first["depth_to"] == 2.45
    assert first["cec"] == 5.44
    assert first["cec_imported"] is True
    assert first["cec_calculated"] is None
    assert any("not recalculated" in i["message"] for i in first["issues"])
    assert preview["summary"]["imported_cec_count"] == 3


def test_preview_recalculates_when_weights_are_present():
    csv = ("Area A, 1 samples,,,,,,,,\n"
           "BH_1,,,,,,,,,\n"
           "Sample name,Depth (m.),Titration (ml.) 1,2,3,Volume of MeB (ml.),"
           "W_clay (g),W_MeB (g),CEC (meq/100g),Type of clay mineral\n"
           "D:2.00,2 - 2.45,1.7,1.5,1.5,1.57,0.9,10,5.44,\"Kln, Mix\"\n")
    grid = grid_of(csv)
    structure = importer.detect_structure(grid)
    mapping = importer.map_columns(structure["header_row"])
    row = importer.build_preview(grid, structure, mapping)["rows"][0]

    assert row["w_clay"] == 0.9 and row["w_meb"] == 10.0
    assert round(row["cec_calculated"], 2) == 5.44
    assert row["cec_imported"] is False
    assert row["clay_label"] == "Kln, Mix"


def test_cec_mismatch_is_flagged():
    csv = ("Area A,,,,,,,,,\n"
           "BH_1,,,,,,,,,\n"
           "Sample name,Depth (m.),Titration (ml.) 1,2,3,Volume of MeB (ml.),"
           "W_clay (g),W_MeB (g),CEC (meq/100g),Type of clay mineral\n"
           "D:2.00,2 - 2.45,1.7,1.5,1.5,1.57,0.9,10,99.99,Smectite\n")
    grid = grid_of(csv)
    structure = importer.detect_structure(grid)
    row = importer.build_preview(grid, structure,
                                 importer.map_columns(structure["header_row"]))["rows"][0]
    assert any("does not match" in i["message"] or "the formula gives" in i["message"]
               for i in row["issues"]), row["issues"]


def test_rows_with_errors_are_marked_skip():
    csv = ("Area A,,,,\n"
           "BH_1,,,,\n"
           "Sample name,Depth (m.),CEC (meq/100g),Type of clay mineral,Volume of MeB (ml.)\n"
           ",2 - 2.45,5.44,Kln,1.57\n"            # no sample name
           "GOOD,5 - 1,5.44,Kln,1.57\n")          # inverted depth
    grid = grid_of(csv)
    structure = importer.detect_structure(grid)
    rows = importer.build_preview(grid, structure,
                                  importer.map_columns(structure["header_row"]))["rows"]
    assert rows[0]["action"] == "skip"
    assert rows[1]["action"] == "skip"
    assert all(any(i["level"] == "error" for i in row["issues"]) for row in rows)


def test_duplicates_within_the_file():
    csv = ("Area A,,,,\n"
           "BH_1,,,,\n"
           "Sample name,Depth (m.),CEC (meq/100g),Type of clay mineral,Volume of MeB (ml.)\n"
           "D:2.00,2 - 2.45,5.44,Kln,1.57\n"
           "D:2.00,2 - 2.45,5.44,Kln,1.57\n")
    grid = grid_of(csv)
    structure = importer.detect_structure(grid)
    rows = importer.build_preview(grid, structure,
                                  importer.map_columns(structure["header_row"]))["rows"]
    assert rows[1].get("duplicate_in_file") is True


def test_duplicates_against_the_database():
    grid = grid_of(LAB_CSV)
    structure = importer.detect_structure(grid)
    mapping = importer.map_columns(structure["header_row"])

    def lookup(borehole, name, depth_from, area_code=None):
        hit = (area_code, borehole, name) == ("PCMI2", "BH_1", "D:2.00")
        return {"id": 7} if hit else None

    preview = importer.build_preview(grid, structure, mapping, lookup)
    assert preview["summary"]["duplicate_count"] == 1
    assert preview["rows"][0]["existing_id"] == 7


# Two areas in one file, each reusing the borehole code BH_2
MULTI_AREA_CSV = """CRI1 บ้านทดสอบ,,,,2 samples
BH_2,,,,
Sample name,Depth (m.),Volume of MeB (ml.),CEC (meq/100g),Type of clay mineral
SS.3,3 - 3.45,0.5,1.50,None-classified
D:4.5,4.5 - 4.95,0.3,0.69,None-classified

PCMI2 หมู่ที่ 3 บ้านท่าศาลา,,,,1 samples
BH_2,,,,
Sample name,Depth (m.),Volume of MeB (ml.),CEC (meq/100g),Type of clay mineral
SS.3,3 - 3.45,0.5,1.50,None-classified
"""


def _preview(text, **kwargs):
    grid = grid_of(text)
    structure = importer.detect_structure(grid)
    return importer.build_preview(grid, structure,
                                  importer.map_columns(structure["header_row"]), **kwargs)


def test_several_areas_in_one_file():
    preview = _preview(MULTI_AREA_CSV)
    rows = preview["rows"]
    assert [r["area_code"] for r in rows] == ["CRI1", "CRI1", "PCMI2"], rows
    assert all(r["borehole_code"] == "BH_2" for r in rows)
    # the second title row is an area, not a sample
    assert len(rows) == 3
    assert preview["summary"]["areas"] == ["CRI1", "PCMI2"]
    assert preview["summary"]["borehole_count"] == 2      # CRI1 BH_2 and PCMI2 BH_2
    assert preview["summary"]["declared_total"] == 3


def test_same_sample_in_two_areas_is_not_a_duplicate():
    rows = _preview(MULTI_AREA_CSV)["rows"]
    assert not rows[2].get("duplicate_in_file"), rows[2]["issues"]


def test_area_label_rows_and_borehole_headers_with_areas():
    text = ("Area: CRI1,,\n"
            "BH_1,,\n"
            "Sample name,Depth (m.),CEC (meq/100g),Type of clay mineral\n"
            "A,1 - 2,5,Kln\n"
            "PCMI2 BH_3,,\n"
            "B,2 - 3,4,Kln\n"
            "BH_4 (CRI1),,\n"
            "C,3 - 4,3,Kln\n")
    rows = _preview(text)["rows"]
    assert [(r["area_code"], r["borehole_code"]) for r in rows] == [
        ("CRI1", "BH_1"), ("PCMI2", "BH_3"), ("CRI1", "BH_4")], rows


def test_area_code_column_wins():
    text = ("CRI1 บ้าน,,,\n"
            "BH_1,,,\n"
            "Sample name,Area code,Depth (m.),CEC (meq/100g),Type of clay mineral\n"
            "A,PCMI2,1 - 2,5,Kln\n"
            "B,,2 - 3,5,Kln\n")
    rows = _preview(text)["rows"]
    assert rows[0]["area_code"] == "PCMI2"
    assert rows[1]["area_code"] == "CRI1"


def test_area_from_sheet_name_and_typed_default():
    text = ("BH_1,,\n"
            "Sample name,Depth (m.),CEC (meq/100g),Type of clay mineral\n"
            "A,1 - 2,5,Kln\n")
    assert _preview(text)["rows"][0]["area_code"] == ""
    assert any("no area code" in w for w in _preview(text)["warnings"])
    assert _preview(text, sheet_name="CRI1")["rows"][0]["area_code"] == "CRI1"
    assert _preview(text, sheet_name="Lab results")["rows"][0]["area_code"] == ""
    assert _preview(text, default_area="pcmi2")["rows"][0]["area_code"] == "PCMI2"


def test_sample_rows_are_not_mistaken_for_areas():
    """A sample called SS4 with numbers beside it is data, not an area row."""
    text = ("CRI1 บ้าน,,\n"
            "BH_1,,\n"
            "Sample name,Depth (m.),CEC (meq/100g),Type of clay mineral\n"
            "SS4,4.5 - 4.95,1.62,Kln\n"
            "AB12,5 - 6,2,Kln\n")
    rows = _preview(text)["rows"]
    assert [r["sample_name"] for r in rows] == ["SS4", "AB12"]
    assert all(r["area_code"] == "CRI1" for r in rows)
    assert importer.area_code_from_title("Some area with 3 roads") == ""
    assert importer.area_code_from_title("Area with 3 roads") == ""


def test_thai_encodings_are_read():
    """Lab files come out of Excel as UTF-8 with a BOM, or as Windows Thai."""
    text = "พื้นที่ทดสอบ,1 samples\nBH_1,\nSample name,Depth (m.),CEC (meq/100g),Type of clay mineral\nA,1 - 2,5,Kln\n"
    for encoding in ("utf-8-sig", "utf-8", "cp874"):
        grid = importer.read_grid(text.encode(encoding), "test.csv")
        assert "พื้นที่ทดสอบ" in grid[0][0], encoding


def test_clay_codes_and_full_names_are_compared_fairly():
    assert importer._clay_agrees("Kln, Mix", ["Kaolinite", "Mixed-layer"])
    assert importer._clay_agrees("None-classified", ["None-classified"])
    assert importer._clay_agrees("Sme", ["Smectite", "Mixed-layer"])
    assert not importer._clay_agrees("Smectite", ["Kaolinite"])


def test_template_is_a_real_workbook():
    data = importer.build_template_xlsx()
    assert data[:2] == b"PK", "an xlsx file is a zip archive"
    assert len(data) > 3000


def test_borehole_coordinate_file():
    csv = ("Borehole,Area,Easting,Northing,Zone,Ground elevation (m),Total depth (m)\n"
           "BH_1,PCMI2,465464,2036098,47,310.5,25\n"
           "BH_2,PCMI2,465701,2036310,47,311.2,25\n")
    parsed = importer.parse_borehole_file(csv.encode(), "boreholes.csv")
    assert len(parsed["rows"]) == 2
    first = parsed["rows"][0]
    assert first["borehole_code"] == "BH_1"
    assert first["utm_easting"] == 465464
    assert first["utm_zone"] == 47
    assert first["ground_elevation"] == 310.5


def test_survey_point_names_are_split_into_area_and_borehole():
    split = importer.split_hole_name
    assert split("CRI1_BH-1", "CRI1") == ("BH_1", "CRI1")
    assert split("PCMI2-1", "PCMI2") == ("BH_1", "PCMI2")
    assert split("CRI1_BH-2", "") == ("BH_2", "CRI1")
    assert split("BH_3") == ("BH_3", "")
    assert split("YPRE1_BH-3/1", "YPRE1") == ("BH_3/1", "YPRE1")


def test_utm_zone_with_latitude_band():
    assert importer.parse_utm_zone("47Q") == (47, "N")
    assert importer.parse_utm_zone("47P") == (47, "N")
    assert importer.parse_utm_zone("47N") == (47, "N")
    assert importer.parse_utm_zone("47S") == (47, "S")
    assert importer.parse_utm_zone("47") == (47, None)
    assert importer.parse_utm_zone(47) == (47, None)


def test_survey_coordinate_file_with_areas():
    """The shape of the project's Borehole_coordinate.csv."""
    csv = ("Name,Zone,Easting,Northing,Area\n"
           "CRI1_BH-1,47Q,555988.95,2215349.85,CRI1\n"
           "PCMI2-1,47Q,468404.08,2037533.06,PCMI2\n")
    rows = importer.parse_borehole_file(csv.encode(), "Borehole_coordinate.csv")["rows"]
    assert [(r["area_code"], r["borehole_code"]) for r in rows] == [("CRI1", "BH_1"), ("PCMI2", "BH_1")]
    assert rows[0]["utm_zone"] == 47 and rows[0]["utm_hemisphere"] == "N"
    assert rows[0]["utm_easting"] == 555988.95


def test_old_borehole_table_is_migrated_to_area_keys():
    """An old database (borehole_code UNIQUE) keeps its rows and gains area keys."""
    import sqlite3
    import tempfile
    import database

    path = os.path.join(tempfile.mkdtemp(), "old.db")
    conn = sqlite3.connect(path)
    conn.executescript("""
        CREATE TABLE boreholes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            borehole_code TEXT NOT NULL UNIQUE,
            area_code TEXT DEFAULT '',
            latitude REAL, longitude REAL, utm_easting REAL, utm_northing REAL,
            utm_zone INTEGER, utm_hemisphere TEXT DEFAULT 'N',
            ground_elevation REAL, total_depth REAL, notes TEXT DEFAULT '',
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        INSERT INTO boreholes (borehole_code, area_code, latitude, longitude, created_at, updated_at)
            VALUES ('BH_9', 'cri1 ', 19.9, 99.8, 'x', 'x');
        INSERT INTO boreholes (borehole_code, area_code, created_at, updated_at)
            VALUES ('BH_8', '', 'x', 'x');
    """)
    conn.commit()
    conn.close()

    database.init_db(path)

    kept = database.get_borehole("BH_9", "CRI1", db_path=path)
    assert kept and kept["latitude"] == 19.9, kept           # data survives, area normalised
    assert database.get_borehole("BH_8", db_path=path) is None   # empty placeholder removed

    # the same code can now be saved for two areas
    database.save_borehole({"borehole_code": "BH_1", "area_code": "CRI1", "latitude": 19.9,
                            "longitude": 99.8}, db_path=path)
    database.save_borehole({"borehole_code": "BH_1", "area_code": "PCMI2", "latitude": 18.4,
                            "longitude": 98.7}, db_path=path)
    assert database.get_borehole("BH_1", "CRI1", db_path=path)["latitude"] == 19.9
    assert database.get_borehole("BH_1", "PCMI2", db_path=path)["latitude"] == 18.4
    assert any(name.startswith("geochem.before-area-boreholes")
               for name in os.listdir(os.path.dirname(path))), "a backup is taken first"


if __name__ == "__main__":
    failures = 0
    for name, function in sorted(globals().items()):
        if name.startswith("test_") and callable(function):
            try:
                function()
                print(f"PASS  {name}")
            except AssertionError as error:
                failures += 1
                print(f"FAIL  {name}: {error}")
    print(f"\n{'All tests passed.' if not failures else f'{failures} test(s) failed.'}")
    sys.exit(1 if failures else 0)
