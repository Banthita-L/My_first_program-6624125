"""
Run every test file in this folder.

    python tests/run_all.py

Each file can also be run on its own, and all of them work under pytest:

    python -m pytest tests -q
"""

import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    files = sorted(
        name for name in os.listdir(HERE)
        if name.startswith("test_") and name.endswith(".py")
    )

    failed = []
    for name in files:
        print(f"\n{'=' * 64}\n{name}\n{'=' * 64}")
        result = subprocess.run([sys.executable, os.path.join(HERE, name)])
        if result.returncode != 0:
            failed.append(name)

    print(f"\n{'=' * 64}")
    if failed:
        print(f"{len(failed)} file(s) had failures: {', '.join(failed)}")
        return 1
    print(f"All {len(files)} test files passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
