"""
Unit tests for the AFNOR CEC calculations and the clay classification.

The expected values come straight from the lab results table in the project
requirements (area PCMI2, boreholes BH_1 / BH_2 / BH_3), computed with
W_clay = 0.9 g and W_MeB = 10 g.

Run them with:   python -m pytest tests -q
or without pytest installed:   python tests/test_geochem.py
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import geochem  # noqa: E402

W_CLAY = 0.9
W_MEB = 10.0

# borehole, sample, trials, expected V_MeB, expected CEC, expected clay label
#
# NOTE on the two rows marked (*): the requirements document lists them as
# "Kln, Mix", but their CEC (13.31 and 12.15) sits above Kaolinite's stated
# range of 2 – 10 meq/100 g, so the classification table can only return
# Mixed-layer. The app follows the table, which is the rule the program was
# asked to implement; the manual-override dropdown on Page 1 exists for
# exactly this situation.
LAB_RESULTS = [
    ("BH_1", "D:2.00",  [1.7, 1.5, 1.5], 1.57, 5.44,  "Kln, Mix"),
    ("BH_1", "SS.4",    [0.5, 0.4, 0.5], 0.47, 1.62,  "None-classified"),
    ("BH_1", "SS.6",    [0.5, 0.5, 0.5], 0.50, 1.74,  "None-classified"),
    ("BH_1", "SS.9",    [0.1, 0.1, 0.1], 0.10, 0.35,  "None-classified"),
    ("BH_1", "D:15.00", [3.8, 3.8, 3.9], 3.83, 13.31, "Mix"),  # (*)
    ("BH_1", "D:18.00", [3.4, 3.6, 3.5], 3.50, 12.15, "Mix"),  # (*)
    ("BH_2", "D:2.00",  [1.1, 1.0, 1.1], 1.07, 3.70,  "Kln, Mix"),
    ("BH_2", "SS.4",    [0.7, 0.7, 0.7], 0.70, 2.43,  "Kln"),
    ("BH_3", "SS.1",    [0.3, 0.4, 0.3], 0.33, 1.16,  "None-classified"),
]


def test_lab_results_reproduce():
    """Every row of the reference table must come back out of the formula."""
    for borehole, name, trials, expected_v, expected_cec, expected_clay in LAB_RESULTS:
        v_meb = geochem.average_titration(trials)
        cec = geochem.cec_meq_per_100g(v_meb, W_CLAY, W_MEB)
        label = geochem.clay_label(geochem.classify_clay(cec))

        assert round(v_meb, 2) == expected_v, f"{borehole} {name}: V_MeB {v_meb}"
        assert round(cec, 2) == expected_cec, f"{borehole} {name}: CEC {cec}"
        assert label == expected_clay, f"{borehole} {name}: clay {label}"


def test_blank_trials_are_ignored():
    """Two readings average over two, not three."""
    assert geochem.average_titration([2.0, 3.0, None]) == 2.5
    assert geochem.average_titration(["2.0", "", "  "]) == 2.0
    assert geochem.average_titration([None, None, None]) is None


def test_missing_inputs_give_no_cec():
    assert geochem.cec_meq_per_100g(None, 0.9, 10) is None
    assert geochem.cec_meq_per_100g(1.5, None, 10) is None
    assert geochem.cec_meq_per_100g(1.5, 0.9, None) is None
    assert geochem.cec_meq_per_100g(1.5, 0, 10) is None  # no division by zero


def test_overlapping_ranges_return_every_match():
    """25 meq/100 g sits in both the Illite and the Chlorite range."""
    codes = [m["code"] for m in geochem.classify_clay(25)]
    assert codes == ["Ilt", "Chl", "Mix"]

    codes = [m["code"] for m in geochem.classify_clay(120)]
    assert codes == ["Sme", "Vrm"]


def test_boundaries_are_inclusive():
    assert [m["code"] for m in geochem.classify_clay(2)] == ["Kln"]
    assert [m["code"] for m in geochem.classify_clay(10)] == ["Kln", "Mix"]
    assert geochem.classify_clay(1.9) == []
    assert geochem.classify_clay(151) == []


def test_average_cec_across_sets():
    sets = [
        geochem.compute_cec_set({"trial1": 1.7, "trial2": 1.5, "trial3": 1.5,
                                 "w_clay": W_CLAY, "w_meb": W_MEB}),
        geochem.compute_cec_set({"trial1": 3.8, "trial2": 3.8, "trial3": 3.9,
                                 "w_clay": W_CLAY, "w_meb": W_MEB}),
    ]
    average = geochem.average_cec(sets)
    assert round(average, 2) == round((5.4398 + 13.3102) / 2, 2)

    # A single set averages to itself
    assert geochem.average_cec(sets[:1]) == sets[0]["cec"]


def test_manual_override_wins():
    matches = geochem.classify_clay(5.44)
    assert geochem.clay_label(matches) == "Kln, Mix"
    assert geochem.clay_label(matches, override="Smectite") == "Smectite"
    assert geochem.clay_names([], override="Illite") == ["Illite"]


def test_depth_display():
    assert geochem.format_depth(2, 2.45) == "2 – 2.45"
    assert geochem.format_depth(4.5, 4.95) == "4.5 – 4.95"
    assert geochem.format_depth(None, None) == ""


def test_mineral_percentage_warning():
    assert geochem.mineral_percent_warning([{"percent": 60}, {"percent": 40}]) is None
    assert geochem.mineral_percent_warning([{"percent": 60}, {"percent": 25}]) is not None
    assert geochem.mineral_percent_warning([]) is None


def test_enrich_sample_end_to_end():
    sample = {
        "sample_name": "D:2.00",
        "borehole_code": "BH_1",
        "depth_from": 2,
        "depth_to": 2.45,
        "clay_type_override": "",
        "cec_sets": [{"trial1": 1.7, "trial2": 1.5, "trial3": 1.5,
                      "w_clay": W_CLAY, "w_meb": W_MEB}],
        "minerals": [{"mineral": "Quartz", "percent": 70},
                     {"mineral": "Kaolinite", "percent": 30}],
    }
    result = geochem.enrich_sample(sample)
    assert round(result["average_cec"], 2) == 5.44
    assert result["clay_label"] == "Kln, Mix"
    assert result["depth_display"] == "2 – 2.45"
    assert result["mineral_warning"] is None


if __name__ == "__main__":
    failures = 0
    for name, function in sorted(globals().items()):
        if name.startswith("test_") and callable(function):
            try:
                function()
                print(f"PASS  {name}")
            except AssertionError as error:
                failures += 1
                print(f"FAIL  {name}: {error}")
    print(f"\n{'All tests passed.' if not failures else f'{failures} test(s) failed.'}")
    sys.exit(1 if failures else 0)
