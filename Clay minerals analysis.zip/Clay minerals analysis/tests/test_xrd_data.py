"""
Tests for reading measured XRD files (.jas / .chi) for the XRD page.

Run with:   python tests/test_xrd_data.py
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import xrd_data  # noqa: E402


def make_jas(n=50, scale=1.0):
    """A small .jas file whose column 2 follows Bragg's law at 1.5418 Å."""
    x1a = np.linspace(3.3, 50, n)
    xcu = xrd_data.two_theta_to_cu(x1a)
    raw = 1000 + 500 * np.exp(-((x1a - 17) ** 2)) * scale
    background = np.full(n, 1000.0)
    bgsub = raw - background
    norm = bgsub / bgsub.max() * 100
    rows = np.column_stack([x1a, xcu, norm, bgsub, raw, background])
    text = "\n".join(" ".join(f"{v:.6f}" for v in row) for row in rows)
    return text.encode(), rows


def make_chi(rows):
    header = "/some/path/Sample.tif: 2-theta Scan\n2-Theta Angle (Degrees)\nIntensity\n       %d\n" % len(rows)
    body = "\n".join(f" {x:.7E}  {i:.7E}" for x, i in zip(rows[:, 0], rows[:, 4]))
    return (header + body).encode()


def test_names_drop_the_scan_number():
    assert xrd_data.pattern_name("Sample_OMWCNT_1_00001.jas") == "Sample_OMWCNT_1"
    assert xrd_data.pattern_name("Capillary_00001.chi") == "Capillary"
    assert xrd_data.pattern_name("plain.jas") == "plain"


def test_capillary_is_recognised_by_name():
    assert xrd_data.looks_like_capillary("Capillary")
    assert xrd_data.looks_like_capillary("empty_cap")
    assert not xrd_data.looks_like_capillary("Sample_OMWCNT_1")


def test_cu_wavelength_matches_column_two():
    """The real files' column 2 is 2θ at 1.5418 Å; Bragg's law must reproduce it."""
    x1a = np.array([10.0, 20.0, 30.0])
    xcu = xrd_data.two_theta_to_cu(x1a)
    d_1a = 1.0 / (2 * np.sin(np.radians(x1a / 2)))
    d_cu = xrd_data.CU_KALPHA / (2 * np.sin(np.radians(xcu / 2)))
    assert np.allclose(d_1a, d_cu)


def test_jas_and_chi_are_paired():
    jas_bytes, rows = make_jas()
    patterns, problems = xrd_data.read_upload_set([
        ("Sample_A_00001.jas", jas_bytes),
        ("Sample_A_00001.chi", make_chi(rows)),
    ])
    assert len(patterns) == 1, patterns
    pattern = patterns[0]
    assert pattern["name"] == "Sample_A"
    assert pattern["source"] == "jas+chi"
    assert pattern["role"] == "sample"
    assert pattern["notes"] == [], pattern["notes"]       # the pair agrees
    assert pattern["points"] == len(rows)
    assert np.allclose(pattern["data"]["bgsub"], rows[:, 3], atol=1e-3)
    assert not problems


def test_mismatched_chi_is_flagged():
    jas_bytes, rows = make_jas()
    other = rows.copy()
    other[:, 4] *= 1.5
    patterns, _ = xrd_data.read_upload_set([("S_00001.jas", jas_bytes), ("S_00001.chi", make_chi(other))])
    assert any("same scan" in note for note in patterns[0]["notes"])


def test_chi_only_has_raw_intensity():
    _, rows = make_jas()
    patterns, _ = xrd_data.read_upload_set([("Only_00001.chi", make_chi(rows))])
    assert patterns[0]["source"] == "chi"
    assert patterns[0]["data"]["bgsub"] is None
    assert any("only a .chi file" in note for note in patterns[0]["notes"])


def test_bulk_upload_with_capillary_and_bad_files():
    a, _ = make_jas()
    b, _ = make_jas(scale=2)
    cap, _ = make_jas(scale=0.3)
    patterns, problems = xrd_data.read_upload_set([
        ("Sample_2_00001.jas", b),
        ("Sample_10_00001.jas", a),
        ("Capillary_00001.jas", cap),
        ("notes.txt", b"hello"),
        ("Broken_00001.jas", b"not numbers at all"),
    ])
    names = [p["name"] for p in patterns]
    assert names == ["Capillary", "Sample_2", "Sample_10"], names   # natural order
    assert [p["role"] for p in patterns] == ["capillary", "sample", "sample"]
    assert any("notes.txt" in p for p in problems)
    assert any("Broken_00001.jas" in p for p in problems)


def test_real_file_if_present():
    """The project's own data file, when it is on this computer."""
    path = r"C:\mu\4th year\Python\xrd\Sample_OMWCNT_1_00001.jas"
    if not os.path.exists(path):
        return
    with open(path, "rb") as jas, open(path[:-4] + ".chi", "rb") as chi:
        patterns, problems = xrd_data.read_upload_set([
            (os.path.basename(path), jas.read()), (os.path.basename(path)[:-4] + ".chi", chi.read())])
    assert patterns[0]["notes"] == [], patterns[0]["notes"]
    assert patterns[0]["points"] > 5000


if __name__ == "__main__":
    failures = 0
    for name, function in sorted(globals().items()):
        if name.startswith("test_") and callable(function):
            try:
                function()
                print(f"PASS  {name}")
            except AssertionError as error:
                failures += 1
                print(f"FAIL  {name}: {error}")
    print(f"\n{'All tests passed.' if not failures else f'{failures} test(s) failed.'}")
    sys.exit(1 if failures else 0)
