"""
Tests for automatic clay mineral identification (clay_id.py).

Synthetic patterns are built peak by peak at known d-spacings, recorded at
λ = 1 Å like the project's .jas files, so the right answer is known.

Run with:   python tests/test_clay_id.py
"""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import clay_id  # noqa: E402

X = np.arange(3.3, 50.0, 0.00785)          # 2θ at 1 Å, the real files' step
RNG = np.random.default_rng(7)


def pattern(peaks, noise=2.0, width=0.06):
    """peaks: [(d in Å, height)] -> intensity on X."""
    y = np.zeros_like(X)
    for d, height in peaks:
        centre = clay_id.two_theta_from_d(d)
        y += height * np.exp(-0.5 * ((X - centre) / width) ** 2)
    return y + RNG.normal(0, noise, X.size)


def run(treatments):
    peaks = {t: clay_id.find_peaks(X, pattern(p)) for t, p in treatments.items()}
    return clay_id.identify(peaks)


def statuses(result):
    return {m["mineral"]: m["status"] for m in result["minerals"]}


# A typical soil clay: kaolinite + smectite + illite + quartz
AD = [(14.5, 600), (10.0, 300), (5.0, 80), (7.15, 900), (3.58, 400), (4.26, 150), (3.34, 500)]
EG = [(17.0, 700), (10.0, 300), (5.0, 80), (7.15, 900), (3.58, 400), (4.26, 150), (3.34, 500)]
H400 = [(10.0, 900), (7.15, 800), (3.58, 350), (4.26, 150), (3.34, 500)]
H550 = [(10.0, 950), (4.26, 150), (3.34, 500)]


def test_bragg_round_trip():
    for d in (17.0, 14.2, 10.0, 7.15, 3.34, 1.50):
        assert abs(float(clay_id.d_from_two_theta(clay_id.two_theta_from_d(d))) - d) < 1e-9


def test_peaks_are_found_at_the_right_d():
    peaks = clay_id.find_peaks(X, pattern(AD))
    found = [p["d"] for p in peaks]
    for d, _ in AD:
        assert any(abs(f - d) < 0.03 * d for f in found), (d, found)


def test_four_treatments_identify_kaolinite_smectite_illite_quartz():
    result = run({"AD": AD, "EG": EG, "H400": H400, "H550": H550})
    s = statuses(result)
    assert s.get("Smectite") == "identified", s
    assert s.get("Kaolinite") == "identified", s
    assert s.get("Illite") == "identified", s
    assert s.get("Quartz") == "identified", s
    assert "Chlorite" not in s and "Vermiculite" not in s, s


def test_chlorite_survives_550():
    ad = [(14.2, 500), (7.08, 600), (4.73, 120), (3.54, 300)]
    result = run({"AD": ad, "EG": ad, "H400": ad, "H550": [(14.1, 700), (7.08, 120)]})
    s = statuses(result)
    assert s.get("Chlorite") == "identified", s
    assert s.get("Kaolinite") != "identified", s       # the 7 Å peak is chlorite 002 here


def test_vermiculite_collapses_at_400():
    ad = [(14.4, 700), (4.80, 80)]
    result = run({"AD": ad, "EG": ad, "H400": [(10.0, 700)], "H550": [(10.0, 700)]})
    assert statuses(result).get("Vermiculite") == "identified", statuses(result)


def test_air_dried_only_gives_possibles():
    """Without glycol or heating, the 14 Å and 10 Å minerals stay 'possible'.
    Kaolinite may still be identified from its 3.58 Å peak (chlorite gives 3.54 Å)."""
    result = run({"AD": AD})
    s = statuses(result)
    for mineral in ("Smectite", "Illite", "Chlorite or vermiculite"):
        assert s.get(mineral) == "possible", s
    assert s.get("Kaolinite") == "identified", s
    assert any("3.58" in line for m in result["minerals"] if m["mineral"] == "Kaolinite"
               for line in m["evidence"]), result["minerals"]
    assert any("Not measured" in note for note in result["notes"])


def test_mixed_layer_illite_smectite():
    result = run({"AD": [(11.5, 500)], "EG": [(13.2, 500)], "H400": [(10.0, 500)]})
    assert statuses(result).get("Mixed-layer illite/smectite") == "possible", statuses(result)


def test_d060_dioctahedral_and_trioctahedral():
    dioct = run({"AD": [(10.0, 500), (1.499, 120)]})["d060"]
    assert dioct and dioct["octahedral"] == "dioctahedral", dioct
    assert dioct["matches"][0]["mineral"] in ("Illite (Muscovite)", "Montmorillonite"), dioct

    trioct = run({"AD": [(14.2, 500), (1.545, 120)]})["d060"]
    assert trioct and trioct["octahedral"] == "trioctahedral", trioct
    assert any(m["mineral"] == "Chlorites" for m in trioct["matches"]), trioct


def test_d060_table_matches_the_printed_two_theta():
    """The d values of Table 7.4 give the printed 2θ at Cu Kα (1.5418 Å)."""
    for name, low, high, printed in clay_id.D060_TABLE:
        computed = clay_id.two_theta_from_d(low, 1.5418)
        first = float(printed.split("–")[0])
        assert abs(computed - first) < 0.03, (name, computed, first)


def test_treatment_from_file_name():
    detect = clay_id.detect_treatment
    assert detect("BH1_2m_AD") == ("BH1_2m", "AD")
    assert detect("BH1_2m_EG") == ("BH1_2m", "EG")
    assert detect("BH1_2m_glycol") == ("BH1_2m", "EG")
    assert detect("BH1_2m_H400") == ("BH1_2m", "H400")
    assert detect("BH1_2m_heat550") == ("BH1_2m", "H550")
    assert detect("BH1 2m 550C") == ("BH1_2m", "H550")
    assert detect("BH1_2m_air-dried") == ("BH1_2m", "AD")
    assert detect("Sample_OMWCNT_1") == ("Sample_OMWCNT_1", "")


if __name__ == "__main__":
    failures = 0
    for name, function in sorted(globals().items()):
        if name.startswith("test_") and callable(function):
            try:
                function()
                print(f"PASS  {name}")
            except AssertionError as error:
                failures += 1
                print(f"FAIL  {name}: {error}")
    print(f"\n{'All tests passed.' if not failures else f'{failures} test(s) failed.'}")
    sys.exit(1 if failures else 0)
