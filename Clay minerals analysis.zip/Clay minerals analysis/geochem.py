"""
geochem.py — Core geochemistry calculations for the Sample Management Program.

Pure functions only: no Flask, no database. Everything here can be unit-tested
on its own (see tests/test_geochem.py).

AFNOR / methylene-blue (MeB) cation exchange capacity:

    CEC (meq/100 g) = (100 / W_clay) * V_MeB * (W_MeB / 320)

where
    W_MeB   = weight of methylene blue powder used (g)
    V_MeB   = volume of methylene blue used in titration (ml)
    W_clay  = weight of the clay / soil sample powder (g)
    320     = molecular weight of methylene blue (g/mol)
"""

from __future__ import annotations

# --------------------------------------------------------------------------
# Clay mineral classification table
# Ranges overlap on purpose — a sample may match several minerals at once.
# --------------------------------------------------------------------------
CLAY_RANGES = [
    # (full name, short code, CEC min, CEC max)   meq/100 g
    ("Kaolinite",   "Kln",   2.0,  10.0),
    ("Smectite",    "Sme",  80.0, 150.0),
    ("Illite",      "Ilt",  20.0,  30.0),
    ("Chlorite",    "Chl",  20.0,  30.0),
    ("Vermiculite", "Vrm", 100.0, 150.0),
    ("Mixed-layer", "Mix",   3.0, 100.0),
]

NOT_CLASSIFIED = "None-classified"

MEB_MOLECULAR_WEIGHT = 320.0

# Colour used for each mineral on the stratigraphic column and the map.
# Chosen so the column stays readable in both light and dark mode, and so
# adjacent minerals in the table never share a hue.
CLAY_COLORS = {
    "Kaolinite":   "#2a78d6",
    "Smectite":    "#eb6834",
    "Illite":      "#1baf7a",
    "Chlorite":    "#eda100",
    "Vermiculite": "#e87ba4",
    "Mixed-layer": "#4a3aa7",
    NOT_CLASSIFIED: "#898781",
}


def clay_color(name):
    """Colour for one mineral name, falling back to the unclassified grey."""
    return CLAY_COLORS.get(name, CLAY_COLORS[NOT_CLASSIFIED])


def _to_float(value):
    """Return a float, or None for blank / unparsable input."""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if text == "":
        return None
    try:
        return float(text)
    except ValueError:
        return None


def clean_numbers(values):
    """Filter a list of raw inputs down to the usable numbers."""
    out = []
    for value in values or []:
        number = _to_float(value)
        if number is not None:
            out.append(number)
    return out


def average_titration(trials):
    """
    Average of the titration readings that were actually entered.

    Blank trials are ignored, so entering only trial #1 and #2 averages two
    readings rather than treating the third as a zero.

    Returns None when nothing usable was entered.
    """
    readings = clean_numbers(trials)
    if not readings:
        return None
    return sum(readings) / len(readings)


def cec_meq_per_100g(v_meb, w_clay, w_meb):
    """
    AFNOR CEC for one titration set.

    Returns None if any input is missing, or if W_clay is zero (division by
    zero — the caller should surface this as a validation message).
    """
    v_meb = _to_float(v_meb)
    w_clay = _to_float(w_clay)
    w_meb = _to_float(w_meb)

    if v_meb is None or w_clay is None or w_meb is None:
        return None
    if w_clay == 0:
        return None

    return (100.0 / w_clay) * v_meb * (w_meb / MEB_MOLECULAR_WEIGHT)


def compute_cec_set(cec_set):
    """
    Take one raw titration set (a dict from the form) and return it enriched
    with the derived volume and CEC.

    Input keys:  trial1, trial2, trial3, w_clay, w_meb
    Added keys:  v_meb, cec
    """
    trials = [cec_set.get("trial1"), cec_set.get("trial2"), cec_set.get("trial3")]
    v_meb = average_titration(trials)
    cec = cec_meq_per_100g(v_meb, cec_set.get("w_clay"), cec_set.get("w_meb"))

    result = dict(cec_set)
    result["trial1"] = _to_float(cec_set.get("trial1"))
    result["trial2"] = _to_float(cec_set.get("trial2"))
    result["trial3"] = _to_float(cec_set.get("trial3"))
    result["w_clay"] = _to_float(cec_set.get("w_clay"))
    result["w_meb"] = _to_float(cec_set.get("w_meb"))
    result["v_meb"] = v_meb
    result["cec"] = cec
    return result


def average_cec(cec_sets):
    """
    Average CEC across every titration set recorded for a sample.

    With a single set this is simply that set's CEC, which is what the
    requirements ask for.
    """
    values = [s.get("cec") for s in cec_sets or [] if s.get("cec") is not None]
    if not values:
        return None
    return sum(values) / len(values)


def classify_clay(avg_cec):
    """
    Match an average CEC against the classification table.

    Ranges overlap, so this returns every mineral whose range contains the
    value. Returns an empty list when nothing matches; the caller displays
    "None-classified" in that case.
    """
    value = _to_float(avg_cec)
    if value is None:
        return []
    return [
        {"name": name, "code": code, "min": low, "max": high}
        for (name, code, low, high) in CLAY_RANGES
        if low <= value <= high
    ]


def clay_label(matches, override=None):
    """
    Human-readable clay mineral label.

    A manual override always wins — the geologist's call beats the lookup table.
    """
    if override:
        return override
    if not matches:
        return NOT_CLASSIFIED
    return ", ".join(m["code"] for m in matches)


def clay_names(matches, override=None):
    """Full mineral names, for the detail pop-up and charts."""
    if override:
        return [override]
    if not matches:
        return [NOT_CLASSIFIED]
    return [m["name"] for m in matches]


def format_depth(depth_from, depth_to):
    """Display a depth interval the way the lab writes it: '2 – 2.45'."""
    a = _to_float(depth_from)
    b = _to_float(depth_to)
    if a is None and b is None:
        return ""
    if b is None:
        return _trim(a)
    if a is None:
        return _trim(b)
    return f"{_trim(a)} – {_trim(b)}"


def _trim(number):
    """Drop trailing zeros: 2.0 -> '2', 2.45 -> '2.45'."""
    if number is None:
        return ""
    text = f"{number:.4f}".rstrip("0").rstrip(".")
    return text if text else "0"


def mineral_percent_warning(minerals, tolerance=1.0):
    """
    Return a warning string when the XRD mineral percentages do not sum to
    roughly 100 %, or None when they are fine.
    """
    values = [_to_float(m.get("percent")) for m in minerals or []]
    values = [v for v in values if v is not None]
    if not values:
        return None
    total = sum(values)
    if abs(total - 100.0) > tolerance:
        return f"XRD mineral percentages add up to {total:.2f} %, not 100 %."
    return None


def enrich_sample(sample):
    """
    Given a sample dict holding raw entered values plus 'cec_sets' and
    'minerals', return a copy with every derived field filled in.

    This is the single place where "what the lab typed" becomes "what the app
    displays", so Page 1 and Page 2 can never disagree.
    """
    result = dict(sample)

    cec_sets = [compute_cec_set(s) for s in sample.get("cec_sets") or []]
    avg = average_cec(cec_sets)
    matches = classify_clay(avg)
    override = (sample.get("clay_type_override") or "").strip() or None

    result["cec_sets"] = cec_sets
    result["average_cec"] = avg
    result["clay_matches"] = matches
    result["clay_label"] = clay_label(matches, override)
    result["clay_names"] = clay_names(matches, override)
    result["clay_type_override"] = override
    result["depth_display"] = format_depth(sample.get("depth_from"), sample.get("depth_to"))
    result["mineral_warning"] = mineral_percent_warning(sample.get("minerals"))
    return result


# ==========================================================================
# Stratigraphy: ordering samples down a borehole, finding where the clay
# mineral type changes, and shaping the data for the depth-vs-CEC step plot.
# These are used by Page 3 (Map & Stratigraphy).
# ==========================================================================

def sort_down_hole(samples):
    """
    Order samples from shallowest to deepest.

    Samples with no depth sink to the end rather than breaking the order.
    """
    def key(sample):
        top = _to_float(sample.get("depth_from"))
        return (top is None, top if top is not None else 0.0, sample.get("sample_name") or "")
    return sorted(samples or [], key=key)


def interval_of(sample):
    """
    The depth interval a sample represents, as (top, bottom).

    When only one depth was entered the sample is treated as a thin interval
    at that depth, so it still draws on the column.
    """
    top = _to_float(sample.get("depth_from"))
    bottom = _to_float(sample.get("depth_to"))
    if top is None and bottom is None:
        return None
    if top is None:
        top = bottom
    if bottom is None or bottom < top:
        bottom = top
    return (top, bottom)


def clay_transitions(samples):
    """
    Find every depth where the clay mineral type changes down the hole.

    The exact depth is not known: the change happens somewhere between the
    bottom of the upper sample and the top of the next one below. Each
    transition therefore carries that range and its midpoint, and the caller
    is expected to present it as approximate.

    Returns a list of dicts, shallowest first.
    """
    ordered = [s for s in sort_down_hole(samples) if interval_of(s) is not None]
    transitions = []

    def label_of(sample):
        names = sample.get("clay_names") or []
        if names:
            return ", ".join(names)
        return sample.get("clay_label") or NOT_CLASSIFIED

    for upper, lower in zip(ordered, ordered[1:]):
        above = label_of(upper)
        below = label_of(lower)
        if above == below:
            continue

        gap_top = interval_of(upper)[1]
        gap_bottom = interval_of(lower)[0]
        if gap_bottom < gap_top:            # overlapping intervals
            gap_top, gap_bottom = gap_bottom, gap_top

        midpoint = (gap_top + gap_bottom) / 2.0
        transitions.append({
            "above": above,
            "below": below,
            "above_sample": upper.get("sample_name"),
            "below_sample": lower.get("sample_name"),
            "from_depth": gap_top,
            "to_depth": gap_bottom,
            "depth": midpoint,
            "range_display": format_depth(gap_top, gap_bottom),
            "label": f"{above} to {below}, at about {_trim(round(midpoint, 1))} m",
        })

    return transitions


def step_plot_points(samples):
    """
    Turn samples into the corner points of a depth-vs-CEC step plot.

    Each sample holds its CEC constant from the top to the bottom of its own
    interval, then steps to the next sample's value. Returned as a flat list
    of {depth, cec} corners, deepest last, ready to be drawn as a polyline.

    Gaps between samples are carried at the upper sample's value, which is the
    usual convention for a core log and avoids inventing a smooth trend.
    """
    ordered = [
        s for s in sort_down_hole(samples)
        if interval_of(s) is not None and _to_float(s.get("average_cec")) is not None
    ]
    points = []

    for sample in ordered:
        top, bottom = interval_of(sample)
        cec = _to_float(sample.get("average_cec"))
        if points and points[-1]["depth"] < top:
            points.append({"depth": top, "cec": points[-1]["cec"]})
        points.append({"depth": top, "cec": cec})
        points.append({"depth": bottom, "cec": cec})

    return points


def stratigraphic_column(samples, lithology=None):
    """
    Build the blocks that make up a borehole's core column.

    Returns {'depth_min', 'depth_max', 'blocks', 'lithology', 'transitions'}
    where each block is one sample interval carrying its clay type and colour.
    """
    ordered = [s for s in sort_down_hole(samples) if interval_of(s) is not None]
    blocks = []

    for sample in ordered:
        top, bottom = interval_of(sample)
        names = sample.get("clay_names") or [NOT_CLASSIFIED]
        blocks.append({
            "sample_id": sample.get("id"),
            "sample_name": sample.get("sample_name"),
            "depth_from": top,
            "depth_to": bottom,
            "depth_display": format_depth(top, bottom),
            "average_cec": _to_float(sample.get("average_cec")),
            "clay_label": sample.get("clay_label") or NOT_CLASSIFIED,
            "clay_names": names,
            "color": clay_color(names[0]),
        })

    beds = []
    for bed in lithology or []:
        top = _to_float(bed.get("depth_from"))
        bottom = _to_float(bed.get("depth_to"))
        if top is None and bottom is None:
            continue
        if top is None:
            top = bottom
        if bottom is None or bottom < top:
            bottom = top
        beds.append({
            "depth_from": top,
            "depth_to": bottom,
            "depth_display": format_depth(top, bottom),
            "description": bed.get("description") or "",
            "color": bed.get("color") or "#c3c2b7",
        })
    beds.sort(key=lambda b: b["depth_from"])

    depths = [b["depth_from"] for b in blocks] + [b["depth_to"] for b in blocks]
    depths += [b["depth_from"] for b in beds] + [b["depth_to"] for b in beds]

    return {
        "depth_min": min(depths) if depths else 0.0,
        "depth_max": max(depths) if depths else 0.0,
        "blocks": blocks,
        "lithology": beds,
        "transitions": clay_transitions(ordered),
    }


def dominant_clay(samples):
    """
    The clay mineral that appears in the most samples of a borehole.

    Used to colour a map marker. Classified minerals always beat
    "None-classified", so one unclassified sample does not grey out a hole
    that is otherwise kaolinite.
    """
    counts = {}
    for sample in samples or []:
        for name in sample.get("clay_names") or []:
            counts[name] = counts.get(name, 0) + 1
    if not counts:
        return NOT_CLASSIFIED

    classified = {k: v for k, v in counts.items() if k != NOT_CLASSIFIED}
    pool = classified or counts
    return max(sorted(pool), key=lambda name: pool[name])


def borehole_summary(code, samples):
    """One row of headline numbers for a borehole, used on the map."""
    cec_values = [
        _to_float(s.get("average_cec")) for s in samples or []
        if _to_float(s.get("average_cec")) is not None
    ]
    intervals = [interval_of(s) for s in samples or []]
    bottoms = [i[1] for i in intervals if i is not None]

    return {
        "borehole_code": code,
        "sample_count": len(samples or []),
        "average_cec": (sum(cec_values) / len(cec_values)) if cec_values else None,
        "max_depth": max(bottoms) if bottoms else None,
        "dominant_clay": dominant_clay(samples),
        "color": clay_color(dominant_clay(samples)),
    }
