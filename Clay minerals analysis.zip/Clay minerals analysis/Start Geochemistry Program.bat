@echo off
title Geochemistry Sample Management Program
cd /d "%~dp0"

rem ---------------------------------------------------------------
rem  Double-click this file (or a shortcut to it) to start the
rem  program. It launches the server and opens your browser.
rem  Keep the window open while you work; close it when finished.
rem ---------------------------------------------------------------

rem Prefer the Windows py launcher, fall back to python
set "PY=py"
where py >nul 2>nul || set "PY=python"

rem Make sure Flask is installed before trying to start
%PY% -c "import flask" >nul 2>nul
if errorlevel 1 (
    echo Flask is not installed yet. Installing it now, please wait...
    echo.
    %PY% -m pip install -r requirements.txt
    echo.
)

echo ===============================================================
echo   Geochemistry Sample Management Program
echo   Geoscience Program, Mahidol University
echo ===============================================================
echo.
echo   Your browser will open in a few seconds.
echo   If it does not, go to:  http://127.0.0.1:5000
echo.
echo   KEEP THIS WINDOW OPEN while you are using the program.
echo   Close it, or press Ctrl+C, when you are finished.
echo.
echo ===============================================================
echo.

rem Open the browser a few seconds after the server has started
start "" /min cmd /c "timeout /t 4 /nobreak >nul & start "" http://127.0.0.1:5000"

%PY% app.py

echo.
echo The program has stopped. You can close this window.
pause
