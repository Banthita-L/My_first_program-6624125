/* ------------------------------------------------------------------
   sample-detail.js — the read-only sample pop-up.

   Used by both the Analysis page and the Map page, so a sample always
   looks the same wherever it is opened from.
------------------------------------------------------------------- */

import { $, escapeHtml, fmt, trimNum } from './common.js';

function item(label, value) {
  return `<div class="detail-item"><dt>${escapeHtml(label)}</dt><dd>${value}</dd></div>`;
}

/** Draw the digitised pattern with its detected peaks marked. */
function spectrumSvg(scan, peaks) {
  const curve = (scan && scan.curve) || [];
  if (curve.length < 5) return '';

  const width = 560;
  const height = 190;
  const margin = { top: 10, right: 10, bottom: 26, left: 40 };
  const plotW = width - margin.left - margin.right;
  const plotH = height - margin.top - margin.bottom;

  const xs = curve.map((p) => p[0]);
  const ys = curve.map((p) => p[1]);
  const xMin = Math.min(...xs);
  const xMax = Math.max(...xs);
  const yMax = Math.max(...ys, 1);

  const x = (value) => margin.left + ((value - xMin) / (xMax - xMin || 1)) * plotW;
  const y = (value) => margin.top + plotH - (value / yMax) * plotH;

  const path = curve
    .map((p, i) => `${i ? 'L' : 'M'}${x(p[0]).toFixed(1)} ${y(p[1]).toFixed(1)}`)
    .join(' ');

  const markers = (peaks || [])
    .filter((p) => p.two_theta >= xMin && p.two_theta <= xMax)
    .map((p) => {
      const px = x(p.two_theta);
      const py = y(p.intensity || 0);
      const label = p.mineral ? escapeHtml(p.mineral.split(' ')[0]) : '';
      return `<line x1="${px.toFixed(1)}" y1="${(py - 6).toFixed(1)}" x2="${px.toFixed(1)}" y2="${margin.top}"
                    stroke="var(--series-2)" stroke-width="1" stroke-dasharray="2 3" opacity="0.7"></line>
              <circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="3.5"
                      fill="var(--series-2)" stroke="var(--surface-1)" stroke-width="1.5"></circle>
              ${label ? `<text x="${px.toFixed(1)}" y="${(margin.top - 1).toFixed(1)}"
                     text-anchor="middle" font-size="9" fill="var(--text-muted)">${label}</text>` : ''}`;
    })
    .join('');

  const ticks = [];
  const step = Math.max(5, Math.round((xMax - xMin) / 6 / 5) * 5);
  for (let value = Math.ceil(xMin / step) * step; value <= xMax; value += step) {
    ticks.push(`<text x="${x(value).toFixed(1)}" y="${height - 8}" text-anchor="middle"
                      font-size="9" fill="var(--text-muted)">${value}</text>`);
  }

  return `
    <div class="spectrum-plot">
      <svg viewBox="0 0 ${width} ${height}" role="img"
           aria-label="Digitised diffraction pattern with the detected peaks marked">
        <line x1="${margin.left}" y1="${margin.top}" x2="${margin.left}" y2="${margin.top + plotH}"
              stroke="var(--baseline)" stroke-width="1"></line>
        <line x1="${margin.left}" y1="${margin.top + plotH}" x2="${margin.left + plotW}" y2="${margin.top + plotH}"
              stroke="var(--baseline)" stroke-width="1"></line>
        <path d="${path}" fill="none" stroke="var(--series-1)" stroke-width="1.5"
              stroke-linejoin="round"></path>
        ${markers}
        ${ticks.join('')}
        <text x="${margin.left + plotW / 2}" y="${height - 1}" text-anchor="middle"
              font-size="9" fill="var(--text-muted)">2θ (degrees)</text>
      </svg>
    </div>`;
}

export function detailHtml(sample) {
  const cecRows = (sample.cec_sets || []).map((set, index) => `
    <tr>
      <td>Set ${index + 1}</td>
      <td>${fmt(set.trial1)}</td>
      <td>${fmt(set.trial2)}</td>
      <td>${fmt(set.trial3)}</td>
      <td>${fmt(set.v_meb)}</td>
      <td>${trimNum(set.w_clay) || '—'}</td>
      <td>${trimNum(set.w_meb) || '—'}</td>
      <td><strong>${fmt(set.cec)}</strong></td>
    </tr>`).join('')
    || `<tr><td colspan="8">${sample.cec_imported
          ? 'No titration data: the CEC was imported from a lab file.'
          : 'No titration data recorded.'}</td></tr>`;

  const mineralRows = (sample.minerals || []).map((m) => `
    <tr>
      <td>${escapeHtml(m.mineral || '—')}</td>
      <td>${fmt(m.percent)}</td>
      <td><span class="chip source-chip">${escapeHtml(m.source || 'manual')}</span></td>
    </tr>`).join('')
    || '<tr><td colspan="3">No mineral percentages recorded.</td></tr>';

  let spectrum = '<p class="hint">No XRD spectrum image was uploaded for this sample.</p>';
  if (sample.xrd_image_url && sample.xrd_image_is_pdf) {
    spectrum = `<p><a href="${escapeHtml(sample.xrd_image_url)}" target="_blank" rel="noopener">Open the uploaded PDF spectrum &rarr;</a></p>`;
  } else if (sample.xrd_image_url) {
    spectrum = `<div class="spectrum">
        <img src="${escapeHtml(sample.xrd_image_url)}" alt="XRD peak spectrum for ${escapeHtml(sample.sample_name)}">
        <p class="hint">Click the image to view it full size.</p>
      </div>`;
  }

  const digitised = sample.xrd_scan && sample.xrd_scan.curve && sample.xrd_scan.curve.length
    ? `<h4 class="sub-head">Digitised pattern</h4>
       ${spectrumSvg(sample.xrd_scan, sample.peaks)}
       <p class="hint">Read from the image. <a href="/api/samples/${sample.id}/xrd.csv">Download the data points as CSV</a>.</p>`
    : '';

  const peakRows = (sample.peaks || []).length
    ? `<h4 class="sub-head">Detected peaks</h4>
       <table class="detail-table">
         <thead><tr><th>2θ (°)</th><th>d (Å)</th><th>Height</th><th>Mineral</th><th>Confidence</th></tr></thead>
         <tbody>${sample.peaks.map((p) => `
           <tr><td>${fmt(p.two_theta, 2)}</td><td>${fmt(p.d_spacing, 3)}</td>
               <td>${fmt(p.intensity, 1)}</td><td>${escapeHtml(p.mineral || '—')}</td>
               <td>${p.confidence === null || p.confidence === undefined ? '—' : fmt(p.confidence, 2)}</td></tr>`).join('')}
         </tbody>
       </table>`
    : '';

  const cecSource = sample.cec_imported
    ? 'Imported from a lab file, not recalculated'
    : 'Calculated with the AFNOR formula';

  return `
    <section class="detail-group">
      <h3>General info</h3>
      <dl class="detail-grid">
        ${item('Sample Name', escapeHtml(sample.sample_name))}
        ${item('Area Code', escapeHtml(sample.area_code || '—'))}
        ${item('Borehole Code', escapeHtml(sample.borehole_code || '—'))}
        ${item('Depth (m)', escapeHtml(sample.depth_display || '—'))}
      </dl>
    </section>

    <section class="detail-group">
      <h3>AFNOR system / CEC</h3>
      <table class="detail-table">
        <thead><tr>
          <th></th><th>#1 (ml)</th><th>#2 (ml)</th><th>#3 (ml)</th>
          <th>V_MeB (ml)</th><th>W_clay (g)</th><th>W_MeB (g)</th><th>CEC</th>
        </tr></thead>
        <tbody>${cecRows}</tbody>
      </table>
      <dl class="detail-grid" style="margin-top:12px">
        ${item('Average CEC (meq/100 g)', fmt(sample.average_cec))}
        ${item('Source', escapeHtml(cecSource))}
      </dl>
    </section>

    <section class="detail-group">
      <h3>Clay mineralogy</h3>
      <dl class="detail-grid">
        ${item('Type of Clay Mineral',
               `<span class="clay-dot" style="background:${escapeHtml(sample.clay_color || '#898781')}"></span>` +
               escapeHtml((sample.clay_names || []).join(', ')))}
        ${item('Source', sample.clay_type_override ? 'Manual override' : 'Classification table')}
      </dl>
    </section>

    <section class="detail-group">
      <h3>Resistivity</h3>
      <dl class="detail-grid">
        ${item('DC Resistivity (Ω·m)', fmt(sample.mt_resistivity))}
        ${item('Reference', 'Amatyakul et al., 2021')}
      </dl>
    </section>

    <section class="detail-group">
      <h3>XRD composition</h3>
      <table class="detail-table">
        <thead><tr><th>Mineral</th><th>Percentage (%)</th><th>Source</th></tr></thead>
        <tbody>${mineralRows}</tbody>
      </table>
      ${sample.mineral_warning ? `<p class="inline-warning">${escapeHtml(sample.mineral_warning)}</p>` : ''}
      ${spectrum}
      ${digitised}
      ${peakRows}
    </section>

    ${(sample.lithology || []).length ? `
    <section class="detail-group">
      <h3>Lithology</h3>
      <table class="detail-table">
        <thead><tr><th>Depth (m)</th><th>Description</th><th>Colour</th></tr></thead>
        <tbody>${sample.lithology.map((b) => `
          <tr><td>${escapeHtml(depthOf(b))}</td><td>${escapeHtml(b.description || '—')}</td>
              <td><span class="clay-dot" style="background:${escapeHtml(b.color || '#c3c2b7')}"></span></td></tr>`).join('')}
        </tbody>
      </table>
    </section>` : ''}

    ${sample.notes ? `<section class="detail-group"><h3>Notes</h3><p>${escapeHtml(sample.notes)}</p></section>` : ''}
  `;
}

function depthOf(bed) {
  const from = bed.depth_from;
  const to = bed.depth_to;
  if (from === null && to === null) return '—';
  if (to === null || to === undefined) return trimNum(from);
  return `${trimNum(from)} – ${trimNum(to)}`;
}

/**
 * Fill and show the shared detail modal.
 *
 * The page supplies the modal markup; this only fills it in and wires the
 * image zoom, so both pages behave identically.
 */
export function openSampleDetail(sample, { onZoom } = {}) {
  $('modal-title').textContent = sample.sample_name;
  $('modal-sub').textContent =
    `${sample.borehole_code || 'No borehole'}${sample.depth_display ? ` · ${sample.depth_display} m` : ''}`;

  const edit = $('modal-edit');
  const report = $('modal-report');
  if (edit) edit.href = `/collection?id=${sample.id}`;
  if (report) report.href = `/samples/${sample.id}/report`;

  const body = $('modal-body');
  body.innerHTML = detailHtml(sample);
  body.scrollTop = 0;

  body.querySelectorAll('.spectrum img').forEach((img) => {
    img.addEventListener('click', () => onZoom && onZoom(img.src));
  });

  $('modal').hidden = false;
  $('modal-close').focus();
}

export function closeSampleDetail() {
  const modal = $('modal');
  if (modal) modal.hidden = true;
}

/** Wire the modal's close buttons and the image zoom overlay once per page. */
export function wireDetailModal() {
  const modal = $('modal');
  if (!modal) return;

  const close = () => closeSampleDetail();
  $('modal-close').addEventListener('click', close);
  $('modal-done').addEventListener('click', close);
  modal.addEventListener('click', (event) => {
    if (event.target === modal) close();
  });

  const zoom = $('zoom');
  if (zoom) {
    const closeZoom = () => { zoom.hidden = true; };
    $('zoom-close').addEventListener('click', closeZoom);
    zoom.addEventListener('click', (event) => {
      if (event.target !== $('zoom-img')) closeZoom();
    });
  }

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    if (zoom && !zoom.hidden) { zoom.hidden = true; return; }
    if (!modal.hidden) close();
  });
}

export function openZoom(src) {
  const zoom = $('zoom');
  if (!zoom) return;
  $('zoom-img').src = src;
  zoom.hidden = false;
  $('zoom-close').focus();
}
