/* ------------------------------------------------------------------
   collection.js — Page 1: entering, importing and editing samples.

   Three tabs share this page:
     Manual entry        the sample form, with live CEC calculation
     Bulk import         see import.js
     Borehole information see boreholes.js

   The XRD review screen (xrd-review.js) fills in the mineral percentages
   when the user accepts its result.
------------------------------------------------------------------- */

import { $, api, errorsOf, escapeHtml, fmt, hideBanner, num, showBanner, trimNum } from './common.js';
import { BulkImport } from './import.js';
import { BoreholePanel } from './boreholes.js';
import { XrdReview } from './xrd-review.js';

const MEB_MW = 320;
const NOT_CLASSIFIED = 'None-classified';

let CLAY_RANGES = [];
let IMPORT_FIELDS = [];
let removeImageFlag = false;
let pendingXrd = null;      // what the XRD screen handed back, until saved

const form = $('sample-form');
const cecContainer = $('cec-sets');
const mineralRows = $('mineral-rows');
const bedRows = $('bed-rows');

/* ------------------------------------------------------------- tabs */

function showTab(name) {
  document.querySelectorAll('.tab').forEach((tab) => {
    tab.classList.toggle('active', tab.dataset.tab === name);
  });
  ['manual', 'import', 'boreholes'].forEach((key) => {
    $(`panel-${key}`).hidden = key !== name;
  });
}

document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => showTab(tab.dataset.tab));
});

/* -------------------------------------------------- the AFNOR formulas */

function averageTitration(trials) {
  const readings = trials.map(num).filter((v) => v !== null);
  if (!readings.length) return null;
  return readings.reduce((a, b) => a + b, 0) / readings.length;
}

function cecFor(vMeb, wClay, wMeb) {
  if (vMeb === null || wClay === null || wMeb === null || wClay === 0) return null;
  return (100 / wClay) * vMeb * (wMeb / MEB_MW);
}

function classify(avgCec) {
  if (avgCec === null) return [];
  return CLAY_RANGES.filter((r) => avgCec >= r.min && avgCec <= r.max);
}

/* ------------------------------------------------ titration set rows */

function addCecSet(values = null) {
  const node = $('cec-template').content.firstElementChild.cloneNode(true);
  cecContainer.appendChild(node);

  if (values) {
    node.querySelectorAll('input[data-key]').forEach((input) => {
      const value = values[input.dataset.key];
      if (value !== null && value !== undefined) input.value = value;
    });
  }

  node.querySelectorAll('input').forEach((input) => input.addEventListener('input', recalcAll));
  node.querySelector('.remove-cec').addEventListener('click', () => {
    node.remove();
    if (!cecContainer.children.length) addCecSet();
    recalcAll();
  });

  recalcAll();
  return node;
}

function readCecSets() {
  return [...cecContainer.querySelectorAll('.cec-set')].map((node) => {
    const value = (key) => num(node.querySelector(`[data-key="${key}"]`).value);
    return {
      node,
      trial1: value('trial1'),
      trial2: value('trial2'),
      trial3: value('trial3'),
      w_clay: value('w_clay'),
      w_meb: value('w_meb'),
    };
  });
}

/* -------------------------------------------------------- mineral rows */

function addMineralRow(values = null) {
  const row = $('mineral-template').content.firstElementChild.cloneNode(true);
  mineralRows.appendChild(row);

  if (values) {
    row.querySelector('.mineral-name').value = values.mineral || '';
    if (values.percent !== null && values.percent !== undefined) {
      row.querySelector('.mineral-percent').value = values.percent;
    }
    const chip = row.querySelector('.source-chip');
    chip.textContent = values.source || 'manual';
    chip.classList.toggle('estimated', (values.source || '') === 'estimated');
    row.dataset.source = values.source || 'manual';
    row.dataset.confidence = values.confidence ?? '';
  }

  // Typing over an estimated value makes it the user's own number
  row.querySelectorAll('input').forEach((input) => {
    input.addEventListener('input', () => {
      if (row.dataset.source === 'estimated') {
        row.dataset.source = 'manual';
        const chip = row.querySelector('.source-chip');
        chip.textContent = 'manual';
        chip.classList.remove('estimated');
      }
      updateMineralTotal();
    });
  });

  row.querySelector('.remove-mineral').addEventListener('click', () => {
    row.remove();
    if (!mineralRows.children.length) addMineralRow();
    updateMineralTotal();
  });

  updateMineralTotal();
  return row;
}

function readMinerals() {
  return [...mineralRows.querySelectorAll('.mineral-row')].map((row) => ({
    mineral: row.querySelector('.mineral-name').value.trim(),
    percent: num(row.querySelector('.mineral-percent').value),
    source: row.dataset.source || 'manual',
    confidence: num(row.dataset.confidence),
  })).filter((m) => m.mineral !== '' || m.percent !== null);
}

function updateMineralTotal() {
  const values = readMinerals().map((m) => m.percent).filter((v) => v !== null);
  const total = values.reduce((a, b) => a + b, 0);

  $('mineral_total').textContent = `${total.toFixed(2)} %`;

  const warning = $('mineral_warning');
  if (values.length && Math.abs(total - 100) > 1) {
    warning.textContent = `These percentages add up to ${total.toFixed(2)} %, not 100 %. Please check the XRD results.`;
    warning.hidden = false;
  } else {
    warning.hidden = true;
  }
}

/* ------------------------------------------------------- lithology rows */

function addBedRow(values = null) {
  const row = $('bed-template').content.firstElementChild.cloneNode(true);
  bedRows.appendChild(row);

  if (values) {
    if (values.depth_from !== null && values.depth_from !== undefined) {
      row.querySelector('.bed-from').value = values.depth_from;
    }
    if (values.depth_to !== null && values.depth_to !== undefined) {
      row.querySelector('.bed-to').value = values.depth_to;
    }
    row.querySelector('.bed-description').value = values.description || '';
    if (values.color) row.querySelector('.bed-color').value = values.color;
  }

  row.querySelector('.remove-bed').addEventListener('click', () => row.remove());
  return row;
}

function readBeds() {
  return [...bedRows.querySelectorAll('.bed-row')].map((row) => ({
    depth_from: num(row.querySelector('.bed-from').value),
    depth_to: num(row.querySelector('.bed-to').value),
    description: row.querySelector('.bed-description').value.trim(),
    color: row.querySelector('.bed-color').value,
  })).filter((b) => b.description !== '' || b.depth_from !== null || b.depth_to !== null);
}

/* ------------------------------------------------------ live calculation */

function recalcAll() {
  const sets = readCecSets();
  const cecValues = [];

  sets.forEach((set) => {
    const vMeb = averageTitration([set.trial1, set.trial2, set.trial3]);
    const cec = cecFor(vMeb, set.w_clay, set.w_meb);
    set.node.querySelector('.v-meb').textContent = fmt(vMeb);
    set.node.querySelector('.cec-value').textContent = fmt(cec);
    if (cec !== null) cecValues.push(cec);
  });

  [...cecContainer.querySelectorAll('.set-number')].forEach((el, index) => {
    el.textContent = index + 1;
  });
  const single = cecContainer.children.length === 1;
  cecContainer.querySelectorAll('.remove-cec').forEach((btn) => { btn.hidden = single; });

  const average = cecValues.length
    ? cecValues.reduce((a, b) => a + b, 0) / cecValues.length
    : null;

  const averageOut = $('average_cec');
  averageOut.textContent = fmt(average);
  averageOut.classList.toggle('muted', average === null);
  $('average_cec_note').textContent = cecValues.length > 1
    ? `Average of ${cecValues.length} titration sets.`
    : 'Across all titration sets entered.';

  const matches = classify(average);
  const suggestion = $('clay_suggestion');
  const override = $('clay_type_override').value;

  if (override) {
    suggestion.textContent = override;
    suggestion.classList.remove('muted');
    $('clay_suggestion_note').textContent = 'Manual override is in use.';
  } else if (average === null) {
    suggestion.textContent = '—';
    suggestion.classList.add('muted');
    $('clay_suggestion_note').textContent = 'Enter a titration set to see a suggestion.';
  } else if (!matches.length) {
    suggestion.textContent = NOT_CLASSIFIED;
    suggestion.classList.add('muted');
    $('clay_suggestion_note').textContent = `No range in the table contains ${fmt(average)} meq/100 g.`;
  } else {
    suggestion.textContent = matches.map((m) => m.name).join(', ');
    suggestion.classList.remove('muted');
    $('clay_suggestion_note').textContent = matches.length > 1
      ? 'Ranges overlap, so more than one mineral matches.'
      : 'Matched against the classification table.';
  }

  updateDepthPreview();
}

function updateDepthPreview() {
  const from = num($('depth_from').value);
  const to = num($('depth_to').value);
  if (from === null && to === null) {
    $('depth_preview').textContent = '—';
    return;
  }
  $('depth_preview').textContent =
    `${from === null ? '?' : trimNum(from)} – ${to === null ? '?' : trimNum(to)} m`;
}

/* ------------------------------------------------------------- uploads */

function showPreview(url, isPdf, name) {
  const holder = $('preview-holder');
  holder.innerHTML = '';

  if (isPdf) {
    const chip = document.createElement('div');
    chip.className = 'pdf-chip';
    chip.textContent = `PDF spectrum: ${name || 'uploaded file'}`;
    holder.appendChild(chip);
  } else {
    const img = document.createElement('img');
    img.src = url;
    img.alt = 'XRD peak spectrum preview';
    holder.appendChild(img);
  }

  $('preview-wrap').hidden = false;
  $('read-xrd').hidden = isPdf;
}

function clearPreview() {
  $('preview-wrap').hidden = true;
  $('preview-holder').innerHTML = '';
  $('xrd-status').hidden = true;
}

$('xrd_image').addEventListener('change', (event) => {
  const file = event.target.files[0];
  if (!file) return;
  removeImageFlag = false;
  pendingXrd = null;
  $('file-name').textContent = file.name;
  const isPdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name);
  showPreview(isPdf ? null : URL.createObjectURL(file), isPdf, file.name);
  $('xrd-status').hidden = true;
});

$('remove-image').addEventListener('click', () => {
  $('xrd_image').value = '';
  removeImageFlag = true;
  pendingXrd = null;
  $('file-name').textContent = 'No file chosen — .png or .jpg can be read automatically; .pdf is stored only.';
  clearPreview();
});

/* ---------------------------------------------------------- XRD review */

const xrdReview = new XrdReview({
  onAccept: (result) => {
    pendingXrd = result;
    removeImageFlag = false;

    if (result.estimates && result.estimates.length) {
      mineralRows.innerHTML = '';
      result.estimates.forEach((row) => addMineralRow({
        mineral: row.mineral,
        percent: row.percent,
        source: 'estimated',
        confidence: row.confidence,
      }));
      addMineralRow();
    }

    const low = (result.estimates || []).filter((r) => r.low_confidence).length;
    const status = $('xrd-status');
    status.innerHTML =
      `Read from the image: ${result.peaks.length} peak${result.peaks.length === 1 ? '' : 's'}, ` +
      `${(result.estimates || []).length} mineral${(result.estimates || []).length === 1 ? '' : 's'} estimated` +
      (low ? `, ${low} with low confidence` : '') +
      `. These percentages are an estimate from a picture and do not replace quantitative XRD. ` +
      `Edit anything above before saving.`;
    status.hidden = false;

    showPreview(result.url, false, 'XRD image');
    updateMineralTotal();
  },
});

$('read-xrd').addEventListener('click', () => {
  const file = $('xrd_image').files[0];
  if (file) {
    xrdReview.open(file);
    return;
  }
  // Editing a sample whose image is already stored: fetch it back as a file
  const img = $('preview-holder').querySelector('img');
  if (!img) return;
  fetch(img.src)
    .then((response) => response.blob())
    .then((blob) => xrdReview.open(new File([blob], 'xrd.png', { type: blob.type })))
    .catch(() => showBanner('error', 'That image could not be re-read.',
      ['Please choose the image file again with the Choose image button.']));
});

/* --------------------------------------------------------- save & load */

function collectPayload() {
  const payload = {
    sample_name: $('sample_name').value.trim(),
    area_code: $('area_code').value.trim(),
    borehole_code: $('borehole_code').value.trim(),
    depth_from: $('depth_from').value,
    depth_to: $('depth_to').value,
    mt_resistivity: $('mt_resistivity').value,
    clay_type_override: $('clay_type_override').value,
    notes: $('notes').value.trim(),
    remove_image: removeImageFlag,
    cec_sets: readCecSets().map(({ node, ...rest }) => rest),
    minerals: readMinerals(),
    lithology: readBeds(),
  };

  if (pendingXrd) {
    payload.xrd_image_name = pendingXrd.filename;
    payload.xrd_scan = pendingXrd.scan;
    payload.xrd_peaks = pendingXrd.peaks;
  }
  return payload;
}

function clientErrors(payload) {
  const errors = [];
  if (!payload.sample_name) errors.push('Please enter a Sample Name — for example D:2.00 or SS.4.');
  if (!payload.borehole_code) errors.push('Please enter a Borehole Code — for example BH_1.');

  const from = num(payload.depth_from);
  const to = num(payload.depth_to);
  if (from !== null && to !== null && to < from) {
    errors.push('Depth To must be deeper than (or equal to) Depth From.');
  }

  payload.cec_sets.forEach((set, index) => {
    const hasTrial = [set.trial1, set.trial2, set.trial3].some((v) => v !== null);
    if (hasTrial && (set.w_clay === null || set.w_meb === null)) {
      errors.push(`Titration set ${index + 1}: enter W_clay (g) and W_MeB (g) so the CEC can be calculated.`);
    }
    if (set.w_clay !== null && set.w_clay <= 0) {
      errors.push(`Titration set ${index + 1}: W_clay must be greater than zero.`);
    }
  });

  payload.lithology.forEach((bed, index) => {
    if (bed.depth_from !== null && bed.depth_to !== null && bed.depth_to < bed.depth_from) {
      errors.push(`Lithology row ${index + 1}: Depth To is shallower than Depth From.`);
    }
  });

  return errors;
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  hideBanner();

  const payload = collectPayload();
  const errors = clientErrors(payload);

  $('sample_name').classList.toggle('invalid', !payload.sample_name);
  $('borehole_code').classList.toggle('invalid', !payload.borehole_code);

  if (errors.length) {
    showBanner('error', 'Please check these before saving:', errors);
    return;
  }

  const body = new FormData();
  body.append('payload', JSON.stringify(payload));
  const file = $('xrd_image').files[0];
  if (file && !pendingXrd) body.append('xrd_image', file);

  const id = $('sample-id').value;
  const saveBtn = $('save-btn');
  saveBtn.disabled = true;
  saveBtn.textContent = 'Saving…';

  const { ok, body: result } = await api(id ? `/api/samples/${id}` : '/api/samples',
    { method: 'POST', body });

  saveBtn.disabled = false;

  if (!ok) {
    showBanner('error', 'The sample was not saved:', errorsOf(result));
    saveBtn.textContent = id ? 'Update Sample' : 'Save Sample';
    return;
  }

  const link = ' <p style="margin:8px 0 0"><a href="/analysis">View it on the Analysis page &rarr;</a>' +
               ' &middot; <a href="/map">Open the map &rarr;</a></p>';
  showBanner(result.warnings.length ? 'warn' : 'success', result.message, result.warnings, link);

  if (!id) {
    resetForm();
    loadBoreholeOptions();
    boreholePanel.load();
  } else {
    $('sample-id').value = result.id;
    pendingXrd = null;
  }
  saveBtn.textContent = $('sample-id').value ? 'Update Sample' : 'Save Sample';
});

function resetForm() {
  $('sample-id').value = '';
  ['sample_name', 'area_code', 'depth_from', 'depth_to', 'mt_resistivity', 'notes'].forEach((id) => {
    $(id).value = '';
  });
  $('clay_type_override').value = '';
  cecContainer.innerHTML = '';
  addCecSet();
  mineralRows.innerHTML = '';
  addMineralRow();
  bedRows.innerHTML = '';
  addBedRow();
  $('xrd_image').value = '';
  removeImageFlag = false;
  pendingXrd = null;
  $('file-name').textContent = 'No file chosen — .png or .jpg can be read automatically; .pdf is stored only.';
  clearPreview();
  document.querySelectorAll('.invalid').forEach((el) => el.classList.remove('invalid'));
  $('page-title').textContent = 'Data Collection';
  $('save-btn').textContent = 'Save Sample';
  recalcAll();
  updateMineralTotal();
}

$('reset-btn').addEventListener('click', () => {
  resetForm();
  hideBanner();
  history.replaceState(null, '', '/collection');
});

/* ------------------------------------------------------ edit an existing */

async function loadSample(id) {
  const { ok, body: sample } = await api(`/api/samples/${id}`);
  if (!ok) {
    showBanner('error', 'That sample could not be loaded.', ['It may have been deleted.']);
    return;
  }

  $('sample-id').value = sample.id;
  $('sample_name').value = sample.sample_name || '';
  $('area_code').value = sample.area_code || '';
  $('borehole_code').value = sample.borehole_code || '';
  $('depth_from').value = sample.depth_from ?? '';
  $('depth_to').value = sample.depth_to ?? '';
  $('mt_resistivity').value = sample.mt_resistivity ?? '';
  $('notes').value = sample.notes || '';

  cecContainer.innerHTML = '';
  (sample.cec_sets.length ? sample.cec_sets : [null]).forEach((set) => addCecSet(set));

  mineralRows.innerHTML = '';
  (sample.minerals.length ? sample.minerals : [null]).forEach((m) => addMineralRow(m));

  bedRows.innerHTML = '';
  (sample.lithology && sample.lithology.length ? sample.lithology : [null]).forEach((b) => addBedRow(b));

  if (sample.xrd_image_url) {
    $('file-name').textContent = 'Current file — choose a new one to replace it.';
    showPreview(sample.xrd_image_url, sample.xrd_image_is_pdf, 'current file');
  }

  if (sample.xrd_scan && sample.xrd_scan.curve && sample.xrd_scan.curve.length) {
    const status = $('xrd-status');
    status.textContent = `This sample already has a digitised pattern with ` +
      `${(sample.peaks || []).length} peaks. Press "Read this image" to do it again.`;
    status.hidden = false;
  }

  $('clay_type_override').value = sample.clay_type_override || '';
  $('page-title').textContent = `Editing ${sample.sample_name}`;
  $('save-btn').textContent = 'Update Sample';
  recalcAll();
  updateMineralTotal();

  const extra = sample.cec_imported
    ? ' <p style="margin:8px 0 0">This sample\'s CEC came from an imported file. Add W_clay and W_MeB to recalculate it.</p>'
    : ' <p style="margin:8px 0 0">Saving will overwrite the stored values. Use “Clear form” to start a new sample instead.</p>';
  showBanner('warn', `You are editing “${sample.sample_name}”.`, [], extra);
}

/* ------------------------------------------------------------- start-up */

const boreholePanel = new BoreholePanel({
  onChange: () => loadBoreholeOptions(),
});

let bulkImport = null;

async function loadReference() {
  const { ok, body } = await api('/api/reference');
  if (!ok) return;

  CLAY_RANGES = body.clay_ranges || [];
  IMPORT_FIELDS = body.import_fields || [];

  const tbody = document.querySelector('#clay-ref-table tbody');
  tbody.innerHTML = CLAY_RANGES.map((r) => `
    <tr><td><span class="clay-dot" style="background:${escapeHtml(r.color)}"></span>
        ${escapeHtml(r.name)} <span class="hint">(${escapeHtml(r.code)})</span></td>
        <td>${r.min} – ${r.max}</td></tr>`).join('');

  const select = $('clay_type_override');
  CLAY_RANGES.forEach((r) => {
    const option = document.createElement('option');
    option.value = r.name;
    option.textContent = r.name;
    select.appendChild(option);
  });
  const none = document.createElement('option');
  none.value = NOT_CLASSIFIED;
  none.textContent = NOT_CLASSIFIED;
  select.appendChild(none);
}

async function loadBoreholeOptions() {
  const { ok, body } = await api('/api/samples');
  if (!ok) return;
  const codes = [...new Set(body.map((s) => s.borehole_code).filter(Boolean))].sort();
  $('borehole-options').innerHTML = codes
    .map((c) => `<option value="${escapeHtml(c)}">`).join('');
}

async function init() {
  await loadReference();

  bulkImport = new BulkImport({
    fields: IMPORT_FIELDS,
    onImported: () => {
      loadBoreholeOptions();
      boreholePanel.load();
    },
  });

  addCecSet();
  addMineralRow();
  addBedRow();

  $('add-cec').addEventListener('click', () => {
    addCecSet().querySelector('input').focus();
  });
  $('add-mineral').addEventListener('click', () => {
    addMineralRow().querySelector('.mineral-name').focus();
  });
  $('add-bed').addEventListener('click', () => {
    addBedRow().querySelector('.bed-from').focus();
  });

  ['depth_from', 'depth_to'].forEach((id) => $(id).addEventListener('input', updateDepthPreview));
  $('clay_type_override').addEventListener('change', recalcAll);
  $('sample_name').addEventListener('input', () => $('sample_name').classList.remove('invalid'));
  $('borehole_code').addEventListener('input', () => $('borehole_code').classList.remove('invalid'));

  loadBoreholeOptions();
  boreholePanel.load();

  const params = new URLSearchParams(window.location.search);
  if (params.get('tab')) showTab(params.get('tab'));

  const editId = params.get('id');
  if (editId) await loadSample(editId);

  recalcAll();
}

init();
