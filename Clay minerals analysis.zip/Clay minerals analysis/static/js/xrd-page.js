/* ------------------------------------------------------------------
   xrd-page.js — the XRD Patterns page.

   1. Bulk import of .jas / .chi files. The server reads them, and works out
      each file's sample and treatment from its name.
   2. A table of every pattern, grouped by sample: correct the sample,
      the treatment (AD / EG / 400 °C / 550 °C) or the role (sample /
      capillary) of any file.
   3. The graph: ONE sample, its four treatments stacked for comparison.
      Column 1 (2θ at 1 Å) against column 4 (background-subtracted), with
      the capillary's column 4 subtracted, as in the reported figures.
   4. Automatic clay identification from how the peaks respond to the
      treatments, plus d(060) (server side: clay_id.py). Identified
      minerals are marked on the graph.

   The capillary is interpolated onto each pattern's 2θ (1 Å) points before
   subtracting, so the result is right even if the scan steps differ.
------------------------------------------------------------------- */

import { $, api, cssVar, downloadBlob, errorsOf, escapeHtml, showBanner, svgToPng } from './common.js';

const SVG_NS = 'http://www.w3.org/2000/svg';

const TREATMENTS = [
  { code: 'AD', label: 'Air-dried', short: 'AD', color: '#0072B2' },
  { code: 'EG', label: 'Ethylene glycol', short: 'EG', color: '#D55E00' },
  { code: 'H400', label: 'Heated 400 °C', short: '400 °C', color: '#009E73' },
  { code: 'H550', label: 'Heated 550 °C', short: '550 °C', color: '#CC79A7' },
  { code: '', label: 'Treatment not set', short: 'not set', color: '#555555' },
];
const TREATMENT = Object.fromEntries(TREATMENTS.map((t) => [t.code, t]));

let patterns = [];                 // every pattern, with its data arrays
const picked = new Set();          // ticked in the table, for Delete
const shownTreatments = new Set(TREATMENTS.map((t) => t.code));
let cuWavelength = 1.5418;
let identification = null;         // last /api/xrd-identify result for the current sample
let identifyRun = 0;
let lastSeries = [];

/* ------------------------------------------------------------ loading */

async function load() {
  const { ok, body } = await api('/api/xrd-patterns?data=1');
  if (!ok) {
    showBanner('error', 'The XRD patterns could not be loaded.', errorsOf(body));
    return;
  }
  cuWavelength = body.cu_wavelength || cuWavelength;
  // /xrd?sample=NAME opens that sample
  const wanted = new URLSearchParams(window.location.search).get('sample');
  patterns = (body.patterns || []).map((p) => ({ ...p }));
  renderSampleChoice();
  if (wanted && sampleGroups().has(wanted)) $('xrd-sample').value = wanted;
  setPatterns(body.patterns || []);
}

function setPatterns(list) {
  const dataById = new Map(patterns.map((p) => [p.id, p.data]));
  patterns = list.map((p) => ({ ...p, data: p.data || dataById.get(p.id) }));
  const ids = new Set(patterns.map((p) => p.id));
  [...picked].forEach((id) => { if (!ids.has(id)) picked.delete(id); });

  renderTable();
  renderSampleChoice();
  renderCapillaryChoice();
  renderTreatmentToggles();
  refresh();
}

function sampleGroups() {
  const groups = new Map();
  patterns.filter((p) => p.role === 'sample').forEach((p) => {
    if (!groups.has(p.sample_group)) groups.set(p.sample_group, []);
    groups.get(p.sample_group).push(p);
  });
  return groups;
}

function currentSample() {
  return $('xrd-sample').value;
}

/** The current sample's patterns, in treatment order AD, EG, 400, 550, not set. */
function samplePatterns() {
  const order = Object.fromEntries(TREATMENTS.map((t, i) => [t.code, i]));
  return (sampleGroups().get(currentSample()) || [])
    .slice()
    .sort((a, b) => order[a.treatment] - order[b.treatment] || a.name.localeCompare(b.name));
}

/* ------------------------------------------------------------ import */

async function importFiles(fileList) {
  const files = [...fileList].filter((f) => /\.(jas|chi)$/i.test(f.name));
  const skipped = fileList.length - files.length;
  if (!files.length) {
    showBanner('error', 'Please choose .jas or .chi files.');
    return;
  }

  $('xrd-filenames').textContent = `Reading ${files.length} file${files.length === 1 ? '' : 's'}…`;
  const form = new FormData();
  files.forEach((file) => form.append('files', file));
  const { ok, body } = await api('/api/xrd-patterns/import', { method: 'POST', body: form });
  $('xrd-filenames').textContent = files.map((f) => f.name).join(', ');

  if (!ok) {
    showBanner('error', 'The files could not be imported:', errorsOf(body));
    return;
  }
  const warnings = [...(body.warnings || [])];
  if (skipped) warnings.unshift(`${skipped} file${skipped === 1 ? '' : 's'} skipped: not .jas or .chi.`);
  showBanner(warnings.length ? 'warn' : 'success', body.message, warnings);

  // Show the sample that was just imported
  const added = (body.patterns || []).find((p) => (body.added || []).includes(p.name) && p.role === 'sample');
  setPatterns(body.patterns || []);
  if (added) {
    $('xrd-sample').value = added.sample_group;
    refresh();
  }
}

/* ------------------------------------------------------------ the table */

function treatmentOptions(selected) {
  return TREATMENTS.map((t) =>
    `<option value="${t.code}" ${t.code === selected ? 'selected' : ''}>${escapeHtml(t.code ? `${t.short} · ${t.label}` : 'Not set')}</option>`
  ).join('');
}

function renderTable() {
  const body = $('xrd-body');
  $('xrd-empty').hidden = patterns.length > 0;
  $('xrd-table').hidden = patterns.length === 0;

  const groups = sampleGroups();
  const capillaries = patterns.filter((p) => p.role === 'capillary');
  $('xrd-count').textContent = patterns.length
    ? `${groups.size} sample${groups.size === 1 ? '' : 's'}, ${capillaries.length} capillar${capillaries.length === 1 ? 'y' : 'ies'}. ` +
      'Each sample should have four patterns: AD, EG, 400 °C and 550 °C.'
    : 'Each sample should have four patterns: AD, EG, 400 °C and 550 °C.';

  const row = (p) => {
    const files = { jas: '.jas', chi: '.chi only', 'jas+chi': '.jas + .chi' }[p.source] || p.source;
    const notes = (p.notes || []).length
      ? p.notes.map((n) => `<span class="issue warn">${escapeHtml(n)}</span>`).join('')
      : '<span class="chip good-chip">ok</span>';
    const isCap = p.role === 'capillary';
    return `
      <tr data-id="${p.id}" class="${isCap ? 'xrd-capillary-row' : ''}">
        <td class="select-col"><input type="checkbox" class="xrd-pick" ${picked.has(p.id) ? 'checked' : ''}
            aria-label="Select ${escapeHtml(p.name)}"></td>
        <td><strong>${escapeHtml(p.name)}</strong></td>
        <td>${isCap ? '<span class="hint">—</span>' : `<input type="text" class="xrd-group" value="${escapeHtml(p.sample_group)}"
            aria-label="Sample of ${escapeHtml(p.name)}" spellcheck="false">`}</td>
        <td>${isCap ? '<span class="hint">—</span>' : `<select class="xrd-treatment" aria-label="Treatment of ${escapeHtml(p.name)}">
            ${treatmentOptions(p.treatment)}</select>`}</td>
        <td>
          <select class="xrd-role" aria-label="Role of ${escapeHtml(p.name)}">
            <option value="sample" ${!isCap ? 'selected' : ''}>Sample</option>
            <option value="capillary" ${isCap ? 'selected' : ''}>Capillary</option>
          </select>
        </td>
        <td>${escapeHtml(files)}</td>
        <td class="num">${p.points}</td>
        <td class="num">${Number(p.two_theta_min).toFixed(2)} – ${Number(p.two_theta_max).toFixed(2)}°</td>
        <td class="issue-cell">${notes}</td>
      </tr>`;
  };

  let html = '';
  if (capillaries.length) {
    html += `<tr class="group-row"><td colspan="9">Capillary <span class="count">· subtracted from every sample</span></td></tr>`;
    html += capillaries.map(row).join('');
  }
  [...groups.keys()].sort((a, b) => a.localeCompare(b, undefined, { numeric: true })).forEach((group) => {
    const list = groups.get(group);
    const have = new Set(list.map((p) => p.treatment));
    const status = TREATMENTS.slice(0, 4).map((t) =>
      `<span class="xrd-tchip ${have.has(t.code) ? 'on' : 'off'}" title="${escapeHtml(t.label)}">${escapeHtml(t.short)}</span>`).join('');
    html += `<tr class="group-row"><td colspan="9">${escapeHtml(group)} ${status}</td></tr>`;
    html += list.map(row).join('');
  });
  body.innerHTML = html;

  body.querySelectorAll('tr[data-id]').forEach((tr) => {
    const id = Number(tr.dataset.id);
    tr.querySelector('.xrd-pick').addEventListener('change', (event) => {
      if (event.target.checked) picked.add(id); else picked.delete(id);
      syncPickUi();
    });
    tr.querySelector('.xrd-role').addEventListener('change', (event) => update(id, { role: event.target.value }));
    const treatment = tr.querySelector('.xrd-treatment');
    if (treatment) treatment.addEventListener('change', () => update(id, { treatment: treatment.value }));
    const group = tr.querySelector('.xrd-group');
    if (group) {
      group.addEventListener('change', () => {
        if (group.value.trim()) update(id, { sample_group: group.value.trim() });
      });
    }
  });

  syncPickUi();
}

function syncPickUi() {
  const all = $('xrd-check-all');
  all.checked = patterns.length > 0 && picked.size === patterns.length;
  all.indeterminate = picked.size > 0 && picked.size < patterns.length;
  $('xrd-delete').disabled = picked.size === 0;
  $('xrd-delete').textContent = picked.size ? `Delete selected (${picked.size})` : 'Delete selected';
}

async function update(id, changes) {
  const { ok, body } = await api(`/api/xrd-patterns/${id}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(changes),
  });
  if (!ok) {
    showBanner('error', 'That change was not saved.', errorsOf(body));
    renderTable();
    return;
  }
  const keep = currentSample();
  setPatterns(body.patterns || []);
  if (changes.sample_group && sampleGroups().has(changes.sample_group)) {
    $('xrd-sample').value = changes.sample_group;
  } else if (sampleGroups().has(keep)) {
    $('xrd-sample').value = keep;
  }
  refresh();
}

async function deleteSelected() {
  const chosen = patterns.filter((p) => picked.has(p.id));
  if (!chosen.length) return;
  const names = chosen.map((p) => p.name).join(', ');
  if (!window.confirm(`Delete ${chosen.length} pattern${chosen.length === 1 ? '' : 's'}?\n\n${names}\n\n` +
                      'The files on your computer are not touched; you can import them again.')) return;

  const { ok, body } = await api('/api/xrd-patterns/delete', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ids: chosen.map((p) => p.id) }),
  });
  if (!ok) {
    showBanner('error', 'The patterns could not be deleted.', errorsOf(body));
    return;
  }
  showBanner('success', body.message);
  setPatterns(body.patterns || []);
}

/* -------------------------------------------------- the choices */

function renderSampleChoice() {
  const select = $('xrd-sample');
  const current = select.value;
  const groups = [...sampleGroups().keys()].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  select.innerHTML = groups.length
    ? groups.map((g) => {
      const n = sampleGroups().get(g).length;
      return `<option value="${escapeHtml(g)}">${escapeHtml(g)} (${n} pattern${n === 1 ? '' : 's'})</option>`;
    }).join('')
    : '<option value="">No samples yet</option>';
  if (groups.includes(current)) select.value = current;
}

function renderCapillaryChoice() {
  const select = $('xrd-capillary');
  const current = select.value;
  const capillaries = patterns.filter((p) => p.role === 'capillary');
  select.innerHTML = '<option value="">None (not subtracted)</option>' + capillaries.map((p) =>
    `<option value="${p.id}">${escapeHtml(p.name)}</option>`).join('');
  if (capillaries.some((p) => String(p.id) === current)) select.value = current;
  else if (capillaries.length) select.value = String(capillaries[0].id);
  else select.value = '';
}

function renderTreatmentToggles() {
  const present = new Set(samplePatterns().map((p) => p.treatment));
  $('xrd-treatment-toggles').innerHTML = TREATMENTS.filter((t) => t.code || present.has('')).map((t) => `
    <label class="checkbox ${present.has(t.code) ? '' : 'xrd-missing'}"
           title="${present.has(t.code) ? '' : 'Not measured for this sample'}">
      <input type="checkbox" data-code="${t.code}" ${shownTreatments.has(t.code) ? 'checked' : ''}
             ${present.has(t.code) ? '' : 'disabled'}>
      <span class="xrd-swatch" style="background:${t.color}"></span>${escapeHtml(t.label)}
    </label>`).join('');
  $('xrd-treatment-toggles').querySelectorAll('input').forEach((box) => {
    box.addEventListener('change', () => {
      if (box.checked) shownTreatments.add(box.dataset.code); else shownTreatments.delete(box.dataset.code);
      renderGraph();
    });
  });
}

/* ------------------------------------------------------- the maths */

/** Linear interpolation of (xs, ys) at x; NaN outside the range. xs ascending. */
function interpolate(xs, ys, x) {
  if (!xs.length || x < xs[0] || x > xs[xs.length - 1]) return NaN;
  let lo = 0;
  let hi = xs.length - 1;
  while (hi - lo > 1) {
    const mid = (lo + hi) >> 1;
    if (xs[mid] <= x) lo = mid; else hi = mid;
  }
  const a = ys[lo];
  const b = ys[hi];
  if (a === null || b === null || a === undefined || b === undefined) return NaN;
  const span = xs[hi] - xs[lo];
  return span === 0 ? a : a + (b - a) * ((x - xs[lo]) / span);
}

/** d-spacing in Å from 2θ in degrees: Bragg's law, d = λ / (2 sin θ). */
function dSpacing(twoTheta, wavelength) {
  const sine = Math.sin((twoTheta / 2) * Math.PI / 180);
  return sine > 0 ? wavelength / (2 * sine) : NaN;
}

function twoThetaFor(d, wavelength) {
  const ratio = wavelength / (2 * d);
  return ratio > 0 && ratio <= 1 ? 2 * Math.asin(ratio) * 180 / Math.PI : NaN;
}

function capillaryPattern() {
  return patterns.find((p) => String(p.id) === $('xrd-capillary').value) || null;
}

/** One series per treatment of the current sample, capillary subtracted. */
function buildSeries() {
  const xKey = $('xrd-xaxis').value;
  const yWanted = $('xrd-yaxis').value;
  const normalise = $('xrd-normalize').checked;
  const xmin = parseFloat($('xrd-xmin').value);
  const xmax = parseFloat($('xrd-xmax').value);
  const capillary = capillaryPattern();
  const capY = capillary && capillary.data ? capillary.data[yWanted] || null : null;
  const notes = [];
  if (capillary && !capY) notes.push(`${capillary.name} has no column 4 (a .chi file alone), so it is not subtracted.`);

  const series = samplePatterns()
    .filter((p) => p.data && shownTreatments.has(p.treatment))
    .map((p) => {
      let yKey = yWanted;
      if (!p.data[yKey]) {
        yKey = 'raw';
        notes.push(`${p.name}: no column 4 (only a .chi file), raw intensity shown.`);
      }
      const x1a = p.data.x1a;
      const xs = p.data[xKey];
      const ys = p.data[yKey];
      const subtract = capY && yKey === yWanted;

      const points = [];
      for (let i = 0; i < xs.length; i += 1) {
        const x = xs[i];
        if (!Number.isNaN(xmin) && x < xmin) continue;
        if (!Number.isNaN(xmax) && x > xmax) continue;
        if (ys[i] === null) continue;
        const capPart = subtract ? interpolate(capillary.data.x1a, capY, x1a[i]) : 0;
        if (Number.isNaN(capPart)) continue;
        points.push({ x, x1a: x1a[i], raw: ys[i], cap: subtract ? capPart : null, y: ys[i] - capPart });
      }
      let scale = 1;
      if (normalise && points.length) {
        const top = Math.max(...points.map((pt) => pt.y));
        scale = top > 0 ? 100 / top : 1;
      }
      points.forEach((pt) => { pt.plotY = pt.y * scale; });
      const t = TREATMENT[p.treatment] || TREATMENT[''];
      return { id: p.id, name: p.name, treatment: p.treatment, label: t.label, color: t.color, points };
    })
    .filter((s) => s.points.length);

  return { series, notes, xKey, capillary: capY ? capillary : null, normalise };
}

/* ------------------------------------------------------- the graph */

function el(name, attrs = {}) {
  const node = document.createElementNS(SVG_NS, name);
  Object.entries(attrs).forEach(([key, value]) => node.setAttribute(key, value));
  return node;
}

function label(content, attrs) {
  const node = el('text', attrs);
  node.textContent = content;
  return node;
}

function niceTicks(min, max, count = 8) {
  const raw = (max - min) / count;
  const magnitude = Math.pow(10, Math.floor(Math.log10(raw)));
  const step = [1, 2, 2.5, 5, 10].map((m) => m * magnitude).find((s) => s >= raw) || magnitude * 10;
  const ticks = [];
  for (let v = Math.ceil(min / step) * step; v <= max + step / 1000; v += step) ticks.push(Number(v.toFixed(6)));
  return ticks;
}

function renderGraph() {
  const slot = $('xrd-plot');
  const { series, notes, xKey, capillary, normalise } = buildSeries();
  lastSeries = series;
  slot.innerHTML = '';

  const wavelength = xKey === 'xcu' ? cuWavelength : 1;
  const sample = currentSample();
  $('xrd-graph-sub').textContent = series.length
    ? `${sample} · ${series.map((s) => (TREATMENT[s.treatment] || TREATMENT['']).short).join(', ')} · ` +
      (capillary ? `capillary ${capillary.name} subtracted` : 'capillary NOT subtracted') +
      ` · 2θ at λ = ${wavelength} Å` + (normalise ? ' · each normalised to 100' : '') +
      (notes.length ? ` · ${notes.join(' ')}` : '')
    : 'One sample, its four treatments stacked for comparison.';

  if (!series.length) {
    slot.innerHTML = `<p class="chart-empty">${patterns.length
      ? 'Choose a sample, and tick at least one treatment to show.'
      : 'Import .jas files to draw the XRD patterns.'}</p>`;
    $('xrd-readout').textContent = '';
    return;
  }

  const width = 960;
  const margin = { top: 40, right: 170, bottom: 52, left: 28 };
  const allX = series.flatMap((s) => [s.points[0].x, s.points[s.points.length - 1].x]);
  const xLo = Math.min(...allX);
  const xHi = Math.max(...allX);

  // Air-dried on top, then glycol, 400 °C and 550 °C below it: the order the
  // treatments were done, read from top to bottom.
  const tops = series.map((s) => Math.max(...s.points.map((p) => p.plotY)));
  const lows = series.map((s) => Math.min(...s.points.map((p) => p.plotY)));
  const tallest = Math.max(...tops.map((t, i) => t - Math.min(lows[i], 0)), 1e-9);
  const step = tallest * parseFloat($('xrd-offset').value);
  const shiftOf = (index) => (series.length - 1 - index) * step;
  const yLo = Math.min(...lows, 0);
  const yHi = Math.max(...series.map((s, i) => tops[i] + shiftOf(i)));
  const headroom = (yHi - yLo) * 0.08;

  const plotH = Math.max(300, Math.min(160 + series.length * 130, 900));
  const height = plotH + margin.top + margin.bottom;
  const plotW = width - margin.left - margin.right;
  const x = (v) => margin.left + ((v - xLo) / (xHi - xLo || 1)) * plotW;
  const y = (v) => margin.top + plotH - ((v - yLo) / (yHi + headroom - yLo || 1)) * plotH;

  const svg = el('svg', {
    viewBox: `0 0 ${width} ${height}`, role: 'img',
    'aria-label': `XRD patterns of ${sample}: ${series.map((s) => s.label).join(', ')}`,
  });
  const text = cssVar('--text-primary') || '#1a1a19';
  const muted = cssVar('--text-muted') || '#6b6a65';
  const grid = cssVar('--gridline') || '#e4e3dc';
  const surface = cssVar('--surface-1') || '#ffffff';
  svg.appendChild(el('rect', { x: 0, y: 0, width, height, fill: surface }));

  // x axis
  const axisY = margin.top + plotH;
  niceTicks(xLo, xHi).forEach((t) => {
    svg.appendChild(el('line', { x1: x(t), x2: x(t), y1: margin.top, y2: axisY, stroke: grid, 'stroke-width': 1 }));
    svg.appendChild(el('line', { x1: x(t), x2: x(t), y1: axisY, y2: axisY + 5, stroke: muted, 'stroke-width': 1 }));
    svg.appendChild(label(String(t), { x: x(t), y: axisY + 18, 'text-anchor': 'middle', 'font-size': 12, fill: muted }));
  });
  svg.appendChild(el('line', { x1: margin.left, x2: margin.left + plotW, y1: axisY, y2: axisY, stroke: text, 'stroke-width': 1 }));
  svg.appendChild(label(`2θ (°)   λ = ${wavelength} Å${xKey === 'xcu' ? ' (Cu Kα)' : ''}`,
    { x: margin.left + plotW / 2, y: height - 10, 'text-anchor': 'middle', 'font-size': 13, fill: text }));
  svg.appendChild(label(normalise ? 'Intensity, normalised (offset)' : 'Intensity (a.u., offset)', {
    x: 14, y: margin.top + plotH / 2, 'text-anchor': 'middle', 'font-size': 13, fill: text,
    transform: `rotate(-90 14 ${margin.top + plotH / 2})`,
  }));
  svg.appendChild(label(sample, { x: margin.left, y: 18, 'font-size': 14, 'font-weight': 700, fill: text }));

  // The patterns
  series.forEach((s, index) => {
    const shift = shiftOf(index);
    const d = s.points.map((p, i) => `${i ? 'L' : 'M'}${x(p.x).toFixed(1)} ${y(p.plotY + shift).toFixed(1)}`).join('');
    svg.appendChild(el('path', { d, fill: 'none', stroke: s.color, 'stroke-width': 1.15, 'stroke-linejoin': 'round' }));
    const last = s.points[s.points.length - 1];
    svg.appendChild(label(s.label, {
      x: x(last.x) + 8, y: y(last.plotY + shift) + 4, 'font-size': 12.5, 'font-weight': 600, fill: s.color,
    }));
  });

  // Mineral markers from the identification
  if ($('xrd-markers').checked && identification && identification.sample === sample) {
    const placed = [];
    series.forEach((s, index) => {
      const shift = shiftOf(index);
      const xs = s.points.map((p) => p.x);
      const ys = s.points.map((p) => p.plotY);
      identification.result.minerals.forEach((mineral) => {
        mineral.marks.filter((m) => m.treatment === (s.treatment || 'AD')).forEach((mark) => {
          const at = twoThetaFor(mark.d, wavelength);
          if (Number.isNaN(at) || at < xLo || at > xHi) return;
          const peakY = interpolate(xs, ys, at);
          if (Number.isNaN(peakY)) return;
          const px = x(at);
          const py = y(peakY + shift) - 4;
          // A label runs ~60 px upward from its peak: skip one that would cross another
          if (placed.some((p) => Math.abs(p.x - px) < 11 && Math.abs(p.y - py) < 95)) return;
          placed.push({ x: px, y: py });
          const dim = mineral.status !== 'identified';
          svg.appendChild(el('line', { x1: px, x2: px, y1: py, y2: py - 10, stroke: text, 'stroke-width': 1, opacity: dim ? 0.5 : 0.9 }));
          svg.appendChild(label(`${mineral.code} ${mark.d.toFixed(2)}`, {
            x: px + 3, y: py - 13, 'font-size': 10, 'font-weight': dim ? 400 : 700, fill: text,
            opacity: dim ? 0.6 : 1, transform: `rotate(-90 ${px + 3} ${py - 13})`,
          }));
        });
      });
    });
  }

  // Pointer readout
  const cursor = el('line', { x1: 0, x2: 0, y1: margin.top, y2: axisY, stroke: muted, 'stroke-width': 1, 'stroke-dasharray': '4 3', visibility: 'hidden' });
  svg.appendChild(cursor);
  const hit = el('rect', { x: margin.left, y: margin.top, width: plotW, height: plotH, fill: 'transparent' });
  svg.appendChild(hit);
  hit.addEventListener('mousemove', (event) => {
    const box = svg.getBoundingClientRect();
    const px = ((event.clientX - box.left) / box.width) * width;
    const twoTheta = xLo + ((px - margin.left) / plotW) * (xHi - xLo);
    cursor.setAttribute('x1', px);
    cursor.setAttribute('x2', px);
    cursor.setAttribute('visibility', 'visible');
    const values = series.map((s) => {
      const v = interpolate(s.points.map((p) => p.x), s.points.map((p) => p.y), twoTheta);
      return Number.isNaN(v) ? null : `${escapeHtml((TREATMENT[s.treatment] || TREATMENT['']).short)} ${v.toFixed(1)}`;
    }).filter(Boolean);
    $('xrd-readout').innerHTML =
      `<strong>2θ = ${twoTheta.toFixed(3)}°</strong> · <strong>d = ${dSpacing(twoTheta, wavelength).toFixed(3)} Å</strong>` +
      (values.length ? ` · ${values.join(' · ')}` : '');
  });
  hit.addEventListener('mouseleave', () => {
    cursor.setAttribute('visibility', 'hidden');
    $('xrd-readout').textContent = 'Move the pointer over the graph to read 2θ and the d-spacing.';
  });

  slot.appendChild(svg);
}

/* ------------------------------------------- automatic identification */

async function runIdentification() {
  const sample = currentSample();
  const run = ++identifyRun;
  if (!sample) {
    identification = null;
    renderIdentification();
    return;
  }
  const capillary = capillaryPattern();
  const params = new URLSearchParams({
    sample,
    capillary: capillary ? capillary.id : '',
    intensity: $('xrd-yaxis').value,
    sensitivity: $('xrd-sensitivity').value,
  });
  $('xrd-id-sub').textContent = 'Identifying…';
  const { ok, body } = await api(`/api/xrd-identify?${params}`);
  if (run !== identifyRun) return;   // a newer request has started
  identification = ok ? { sample, result: body } : null;
  if (!ok) showBanner('error', 'The minerals could not be identified.', errorsOf(body));
  renderIdentification();
  renderGraph();
}

function renderIdentification() {
  const tbody = $('xrd-id-table').querySelector('tbody');
  if (!identification) {
    $('xrd-id-sub').textContent = 'From how each peak responds to the four treatments, and from d(060).';
    tbody.innerHTML = '<tr><td colspan="3">Import a sample to identify its minerals.</td></tr>';
    $('xrd-id-notes').innerHTML = '';
    $('xrd-d060').innerHTML = '';
    $('xrd-peaks').innerHTML = '';
    return;
  }
  const { sample, result } = identification;
  const used = Object.keys(result.patterns || {});
  $('xrd-id-sub').textContent =
    `${sample}: ${used.map((c) => (TREATMENT[c] || TREATMENT['']).label).join(', ') || 'no patterns'}.`;

  $('xrd-id-notes').innerHTML = (result.notes || []).length
    ? `<div class="banner warn xrd-id-banner"><ul>${result.notes.map((n) => `<li>${escapeHtml(n)}</li>`).join('')}</ul></div>`
    : '';

  tbody.innerHTML = result.minerals.length
    ? result.minerals.map((m) => `
        <tr>
          <td><strong>${escapeHtml(m.mineral)}</strong> <span class="legend-code">${escapeHtml(m.code)}</span>
              ${m.clay ? '' : '<span class="chip info-chip">not a clay</span>'}</td>
          <td><span class="chip ${m.status === 'identified' ? 'good-chip' : 'warn-chip'}">${
            m.status === 'identified' ? 'Identified' : 'Possible'}</span></td>
          <td><ul class="xrd-evidence">${m.evidence.map((e) => `<li>${escapeHtml(e)}</li>`).join('')}</ul></td>
        </tr>`).join('')
    : '<tr><td colspan="3">No clay mineral reflections were recognised. Try a higher peak sensitivity.</td></tr>';

  const d060 = result.d060;
  $('xrd-d060').innerHTML = d060
    ? `<p><strong>d(060) = ${d060.d.toFixed(3)} Å</strong> (${escapeHtml(d060.treatment)}, 2θ at Cu Kα ≈ ${
        twoThetaFor(d060.d, cuWavelength).toFixed(2)}°) → <strong>${escapeHtml(d060.octahedral)}</strong></p>` +
      (d060.matches.length
        ? `<table class="sample-table xrd-d060-table"><thead><tr><th>Closest in Table 7.4</th><th class="num">d(060) Å</th><th class="num">2θ (Cu)</th><th class="num">Difference</th></tr></thead><tbody>${
          d060.matches.map((m) => `<tr><td>${escapeHtml(m.mineral)}</td><td class="num">${m.d060}</td><td class="num">${m.two_theta_cu}</td><td class="num">${m.difference.toFixed(4)} Å</td></tr>`).join('')
        }</tbody></table>`
        : '<p class="hint">No mineral in Table 7.4 within ±0.004 Å.</p>') +
      `<p class="hint">${escapeHtml(d060.source)}</p>`
    : '<p class="hint">No d(060) peak found near 1.49–1.56 Å.</p>';

  const peaks = result.peaks || {};
  $('xrd-peaks').innerHTML = Object.keys(peaks).map((code) => `
    <h4>${escapeHtml((TREATMENT[code] || TREATMENT['']).label)}</h4>
    <p class="xrd-peak-list">${peaks[code].length
      ? peaks[code].map((p) => `<span class="chip">${p.d.toFixed(2)} Å <span class="hint">(${p.relative}%)</span></span>`).join(' ')
      : '<span class="hint">no peaks above the threshold</span>'}</p>`).join('');
}

/* ------------------------------------------------------- exports */

function downloadCsv() {
  if (!lastSeries.length) return;
  const { capillary } = buildSeries();
  const lines = [['sample', 'treatment', 'pattern', '2theta_1A_deg', '2theta_shown_deg', 'd_A',
    'I_sample', 'I_capillary', 'I_corrected'].join(',')];
  lastSeries.forEach((s) => {
    s.points.forEach((p) => {
      lines.push([
        `"${currentSample().replace(/"/g, '""')}"`, s.treatment || 'not set', `"${s.name.replace(/"/g, '""')}"`,
        p.x1a, p.x, dSpacing(p.x1a, 1).toFixed(4), p.raw,
        p.cap === null ? '' : p.cap.toFixed(3), p.y.toFixed(3),
      ].join(','));
    });
  });
  const note = capillary ? 'capillary_subtracted' : 'no_capillary';
  downloadBlob(new Blob([lines.join('\n')], { type: 'text/csv' }), `${currentSample()}_xrd_${note}.csv`);
}

/* ------------------------------------------------------- events */

function refresh() {
  renderTreatmentToggles();
  renderGraph();
  runIdentification();
}

function wire() {
  const zone = $('xrd-dropzone');
  const input = $('xrd-files');
  zone.addEventListener('click', (event) => { if (event.target.tagName !== 'INPUT') input.click(); });
  zone.addEventListener('keydown', (event) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      input.click();
    }
  });
  ['dragenter', 'dragover'].forEach((name) => zone.addEventListener(name, (event) => {
    event.preventDefault();
    zone.classList.add('dragging');
  }));
  ['dragleave', 'drop'].forEach((name) => zone.addEventListener(name, (event) => {
    event.preventDefault();
    zone.classList.remove('dragging');
  }));
  zone.addEventListener('drop', (event) => importFiles(event.dataTransfer.files));
  input.addEventListener('change', (event) => {
    importFiles(event.target.files);
    event.target.value = '';
  });

  $('xrd-check-all').addEventListener('change', (event) => {
    patterns.forEach((p) => { if (event.target.checked) picked.add(p.id); else picked.delete(p.id); });
    renderTable();
  });
  $('xrd-delete').addEventListener('click', deleteSelected);

  $('xrd-sample').addEventListener('change', refresh);
  ['xrd-capillary', 'xrd-yaxis', 'xrd-sensitivity'].forEach((id) => $(id).addEventListener('change', () => {
    renderGraph();
    runIdentification();
  }));
  ['xrd-xaxis', 'xrd-normalize', 'xrd-markers'].forEach((id) => $(id).addEventListener('change', renderGraph));
  ['xrd-offset', 'xrd-xmin', 'xrd-xmax'].forEach((id) => $(id).addEventListener('input', renderGraph));

  $('xrd-png').addEventListener('click', () => {
    const svg = $('xrd-plot').querySelector('svg');
    if (svg) svgToPng(svg, `${currentSample() || 'xrd'}_patterns.png`);
  });
  $('xrd-csv').addEventListener('click', downloadCsv);

  if (window.matchMedia) {
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', renderGraph);
  }
}

wire();
load();
