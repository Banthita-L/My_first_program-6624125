/* ------------------------------------------------------------------
   charts.js — two small SVG charts for the Analysis page.

   No charting library: plain SVG built in the browser, so the app runs
   with no internet connection in the lab. Colours come from the CSS
   custom properties on .viz-root, so light and dark both work.
------------------------------------------------------------------- */

import { cssVar } from './common.js';

const SVG_NS = 'http://www.w3.org/2000/svg';

/* The categorical order is fixed: a series keeps its colour no matter how
   the table is filtered. Scatter forms cap at three series, so a fourth
   borehole folds into "Other" rather than inventing a hue. */
const SERIES_VARS = ['--series-1', '--series-2', '--series-3'];
const MAX_SERIES = 3;

function el(name, attrs = {}) {
  const node = document.createElementNS(SVG_NS, name);
  Object.entries(attrs).forEach(([key, value]) => node.setAttribute(key, value));
  return node;
}


function niceTicks(min, max, count = 5) {
  if (min === max) {
    const pad = Math.abs(min) > 0 ? Math.abs(min) * 0.2 : 1;
    min -= pad;
    max += pad;
  }
  const raw = (max - min) / count;
  const magnitude = Math.pow(10, Math.floor(Math.log10(raw)));
  const step = [1, 2, 2.5, 5, 10].map((m) => m * magnitude).find((s) => s >= raw) || magnitude * 10;
  const start = Math.floor(min / step) * step;
  const end = Math.ceil(max / step) * step;
  const ticks = [];
  for (let value = start; value <= end + step / 1000; value += step) {
    ticks.push(Number(value.toFixed(10)));
  }
  return { ticks, start, end };
}

function tickLabel(value) {
  if (Math.abs(value) >= 1000) return value.toLocaleString();
  return String(Number(value.toFixed(2)));
}

/* --------------------------------------------------------- tooltip layer */

const tooltip = () => document.getElementById('chart-tooltip');

function attachTooltip(node, html) {
  const box = tooltip();
  const show = (event) => {
    box.innerHTML = html;
    box.hidden = false;
    const rect = box.getBoundingClientRect();
    const x = Math.min(event.clientX + 14, window.innerWidth - rect.width - 8);
    const y = Math.max(event.clientY - rect.height - 12, 8);
    box.style.left = `${x}px`;
    box.style.top = `${y}px`;
  };
  node.addEventListener('mouseenter', show);
  node.addEventListener('mousemove', show);
  node.addEventListener('mouseleave', () => { box.hidden = true; });
  node.addEventListener('focus', show);
  node.addEventListener('blur', () => { box.hidden = true; });
}

function emptyChart(slot, message) {
  slot.innerHTML = `<p class="chart-empty">${message}</p>`;
}

/* ------------------------------------------------- chart 1: CEC vs depth */

/**
 * `area` (optional) limits the chart to one area code, e.g. 'CRI1', so all of
 * that area's boreholes share one chart. A borehole is identified by area +
 * code, because the same code (BH_1) is reused in different areas.
 */
export function drawCecDepth(slotId, legendId, samples, { area = '' } = {}) {
  const slot = document.getElementById(slotId);
  const legend = document.getElementById(legendId);
  legend.innerHTML = '';

  const wantArea = area.trim().toUpperCase();
  const points = samples
    .filter((s) => s.average_cec !== null && s.depth_from !== null)
    .filter((s) => !wantArea || (s.area_code || '').trim().toUpperCase() === wantArea)
    .map((s) => {
      const code = (s.borehole_code || '').trim() || 'Unassigned';
      const areaCode = (s.area_code || '').trim().toUpperCase();
      return {
        cec: s.average_cec,
        // Plotted at the middle of the interval, labelled with the interval itself
        depth: s.depth_to !== null ? (s.depth_from + s.depth_to) / 2 : s.depth_from,
        depthLabel: s.depth_display || `${s.depth_from} m`,
        name: s.sample_name,
        // One area chosen: the code alone is enough. All areas: say which area.
        borehole: wantArea || !areaCode ? code : `${areaCode} · ${code}`,
        clay: s.clay_label,
      };
    });

  if (!points.length) {
    emptyChart(slot, wantArea
      ? `No samples in ${wantArea} with both a CEC value and a depth.`
      : 'No samples with both a CEC value and a depth yet.');
    return;
  }

  // Series order: alphabetical (BH_1, BH_2, BH_3) when one area is chosen,
  // otherwise by sample count. Past three, the rest fold into Other.
  const counts = new Map();
  points.forEach((p) => counts.set(p.borehole, (counts.get(p.borehole) || 0) + 1));
  const byName = (a, b) => a[0].localeCompare(b[0], undefined, { numeric: true });
  const ordered = [...counts.entries()]
    .sort((a, b) => (wantArea ? byName(a, b) : b[1] - a[1] || byName(a, b)))
    .map(([name]) => name);
  const named = ordered.slice(0, MAX_SERIES);
  const hasOther = ordered.length > MAX_SERIES;

  const otherColor = cssVar('--text-muted');
  const colorOf = (borehole) => {
    const index = named.indexOf(borehole);
    return index === -1 ? otherColor : cssVar(SERIES_VARS[index]);
  };
  const seriesKey = (borehole) => (named.includes(borehole) ? borehole : 'Other');

  const width = 460;
  const height = 300;
  const margin = { top: 12, right: 18, bottom: 44, left: 56 };
  const plotW = width - margin.left - margin.right;
  const plotH = height - margin.top - margin.bottom;

  const xScaleInfo = niceTicks(0, Math.max(...points.map((p) => p.cec)), 5);
  const yScaleInfo = niceTicks(0, Math.max(...points.map((p) => p.depth)), 5);

  const x = (value) => margin.left + ((value - xScaleInfo.start) / (xScaleInfo.end - xScaleInfo.start)) * plotW;
  const y = (value) => margin.top + ((value - yScaleInfo.start) / (yScaleInfo.end - yScaleInfo.start)) * plotH;

  const svg = el('svg', {
    viewBox: `0 0 ${width} ${height}`,
    role: 'img',
    'aria-label': 'Dot plot of average CEC against sample depth, coloured by borehole',
  });

  const grid = cssVar('--gridline');
  const axis = cssVar('--baseline');
  const muted = cssVar('--text-muted');
  const surface = cssVar('--surface-1');

  // Recessive grid + axis labels
  xScaleInfo.ticks.forEach((tick) => {
    svg.appendChild(el('line', {
      x1: x(tick), x2: x(tick), y1: margin.top, y2: margin.top + plotH,
      stroke: grid, 'stroke-width': 1,
    }));
    const label = el('text', {
      x: x(tick), y: margin.top + plotH + 16, 'text-anchor': 'middle',
      fill: muted, 'font-size': 10,
    });
    label.textContent = tickLabel(tick);
    svg.appendChild(label);
  });

  yScaleInfo.ticks.forEach((tick) => {
    svg.appendChild(el('line', {
      x1: margin.left, x2: margin.left + plotW, y1: y(tick), y2: y(tick),
      stroke: grid, 'stroke-width': 1,
    }));
    const label = el('text', {
      x: margin.left - 8, y: y(tick) + 3, 'text-anchor': 'end',
      fill: muted, 'font-size': 10,
    });
    label.textContent = tickLabel(tick);
    svg.appendChild(label);
  });

  svg.appendChild(el('line', {
    x1: margin.left, x2: margin.left, y1: margin.top, y2: margin.top + plotH,
    stroke: axis, 'stroke-width': 1,
  }));
  svg.appendChild(el('line', {
    x1: margin.left, x2: margin.left + plotW, y1: margin.top + plotH, y2: margin.top + plotH,
    stroke: axis, 'stroke-width': 1,
  }));

  const xTitle = el('text', {
    x: margin.left + plotW / 2, y: height - 6, 'text-anchor': 'middle',
    fill: muted, 'font-size': 10.5,
  });
  xTitle.textContent = 'Average CEC (meq/100 g)';
  svg.appendChild(xTitle);

  const yTitle = el('text', {
    x: 12, y: margin.top + plotH / 2, 'text-anchor': 'middle',
    fill: muted, 'font-size': 10.5,
    transform: `rotate(-90 12 ${margin.top + plotH / 2})`,
  });
  yTitle.textContent = 'Depth (m)';
  svg.appendChild(yTitle);

  // Dot plot: one dot per sample, coloured by borehole, no line joining them
  const groups = new Map();
  points.forEach((p) => {
    const key = seriesKey(p.borehole);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(p);
  });

  groups.forEach((groupPoints, key) => {
    const sorted = [...groupPoints].sort((a, b) => a.depth - b.depth);
    const color = key === 'Other' ? otherColor : colorOf(key);

    sorted.forEach((p) => {
      // 2px surface ring keeps overlapping markers readable
      const dot = el('circle', {
        cx: x(p.cec), cy: y(p.depth), r: 5,
        fill: color, stroke: surface, 'stroke-width': 2,
        tabindex: 0, role: 'graphics-symbol',
        'aria-label': `${p.name}, borehole ${p.borehole}, ${p.cec.toFixed(2)} meq per 100 grams at ${p.depthLabel} metres`,
      });
      attachTooltip(dot,
        `<strong>${p.name}</strong><span>${p.borehole} &middot; ${p.depthLabel} m<br>` +
        `CEC ${p.cec.toFixed(2)} meq/100 g<br>${p.clay}</span>`);
      svg.appendChild(dot);
    });
  });

  slot.innerHTML = '';
  slot.appendChild(svg);

  // A legend is always present for two or more series
  const entries = [...named.filter((n) => groups.has(n)), ...(hasOther ? ['Other'] : [])];
  if (entries.length > 1) {
    legend.innerHTML = entries.map((name) => {
      const color = name === 'Other' ? otherColor : colorOf(name);
      const label = name === 'Other' ? 'Other boreholes' : name;
      return `<span class="legend-item"><span class="legend-swatch" style="background:${color}"></span>${label}</span>`;
    }).join('');
  }
}

/* --------------------------------------------- chart 2: clay mineral types */

export function drawClayDistribution(slotId, samples) {
  const slot = document.getElementById(slotId);

  const counts = new Map();
  samples.forEach((sample) => {
    (sample.clay_names || []).forEach((name) => {
      counts.set(name, (counts.get(name) || 0) + 1);
    });
  });

  const rows = [...counts.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  if (!rows.length) {
    emptyChart(slot, 'No classified samples yet.');
    return;
  }

  const barH = 22;
  const gap = 10;
  const margin = { top: 8, right: 34, bottom: 8, left: 104 };
  const width = 460;
  const plotW = width - margin.left - margin.right;
  const height = margin.top + margin.bottom + rows.length * barH + (rows.length - 1) * gap;

  const max = Math.max(...rows.map(([, count]) => count));
  const svg = el('svg', {
    viewBox: `0 0 ${width} ${height}`,
    role: 'img',
    'aria-label': 'Number of samples matching each clay mineral type',
  });

  const muted = cssVar('--text-muted');
  const secondary = cssVar('--text-secondary');
  const gridColor = cssVar('--gridline');
  const barColor = cssVar('--series-1');

  svg.appendChild(el('line', {
    x1: margin.left, x2: margin.left, y1: margin.top, y2: height - margin.bottom,
    stroke: gridColor, 'stroke-width': 1,
  }));

  rows.forEach(([name, count], index) => {
    const top = margin.top + index * (barH + gap);
    const barW = Math.max((count / max) * plotW, 3);
    const isUnclassified = name === 'None-classified';

    const label = el('text', {
      x: margin.left - 10, y: top + barH / 2 + 4, 'text-anchor': 'end',
      fill: secondary, 'font-size': 11,
    });
    label.textContent = name;
    svg.appendChild(label);

    // 4px rounded data-end, anchored flat against the baseline
    const bar = el('rect', {
      x: margin.left, y: top, width: barW, height: barH,
      rx: 4, fill: isUnclassified ? muted : barColor,
      tabindex: 0, role: 'graphics-symbol',
      'aria-label': `${name}: ${count} sample${count === 1 ? '' : 's'}`,
    });
    attachTooltip(bar,
      `<strong>${name}</strong><span>${count} sample${count === 1 ? '' : 's'}</span>`);
    svg.appendChild(bar);

    // Square off the baseline edge so the bar grows from the axis
    svg.appendChild(el('rect', {
      x: margin.left, y: top, width: Math.min(4, barW), height: barH,
      fill: isUnclassified ? muted : barColor,
    }));

    const value = el('text', {
      x: margin.left + barW + 7, y: top + barH / 2 + 4,
      fill: secondary, 'font-size': 11, 'font-weight': 600,
    });
    value.textContent = count;
    svg.appendChild(value);
  });

  slot.innerHTML = '';
  slot.appendChild(svg);
}
