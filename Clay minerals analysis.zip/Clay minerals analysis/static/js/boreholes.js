/* ------------------------------------------------------------------
   boreholes.js — the Borehole Information section.

   A borehole needs a position before it can appear on the map. The user
   may type latitude and longitude, or UTM, which the server converts.
------------------------------------------------------------------- */

import { $, api, errorsOf, escapeHtml, fmt, showBanner } from './common.js';

export class BoreholePanel {
  constructor({ onChange }) {
    this.onChange = onChange;
    this.rows = [];
    this.wire();
  }

  wire() {
    $('borehole-form').addEventListener('submit', (event) => {
      event.preventDefault();
      this.save();
    });

    $('bh-clear').addEventListener('click', () => this.clearForm());

    document.querySelectorAll('input[name="coord-mode"]').forEach((radio) => {
      radio.addEventListener('change', () => this.switchMode(radio.value));
    });

    $('bh-import-file').addEventListener('change', (event) => {
      const file = event.target.files[0];
      if (file) this.importFile(file);
      event.target.value = '';
    });
  }

  switchMode(mode) {
    $('latlon-fields').hidden = mode !== 'latlon';
    $('utm-fields').hidden = mode !== 'utm';
  }

  clearForm() {
    ['bh_code', 'bh_area', 'bh_lat', 'bh_lon', 'bh_easting', 'bh_northing',
     'bh_zone', 'bh_elevation', 'bh_total_depth'].forEach((id) => { $(id).value = ''; });
    $('bh_hemisphere').value = 'N';
  }

  fill(row) {
    $('bh_code').value = row.borehole_code || '';
    $('bh_area').value = row.area_code || '';
    $('bh_lat').value = row.latitude ?? '';
    $('bh_lon').value = row.longitude ?? '';
    $('bh_easting').value = row.utm_easting ?? '';
    $('bh_northing').value = row.utm_northing ?? '';
    $('bh_zone').value = row.utm_zone ?? '';
    $('bh_hemisphere').value = row.utm_hemisphere || 'N';
    $('bh_elevation').value = row.ground_elevation ?? '';
    $('bh_total_depth').value = row.total_depth ?? '';

    const useUtm = (row.latitude === null || row.latitude === undefined)
      && row.utm_easting !== null && row.utm_easting !== undefined;
    document.querySelector(`input[name="coord-mode"][value="${useUtm ? 'utm' : 'latlon'}"]`).checked = true;
    this.switchMode(useUtm ? 'utm' : 'latlon');

    $('bh_code').focus();
    $('bh_code').scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  async save() {
    const mode = document.querySelector('input[name="coord-mode"]:checked').value;
    const payload = {
      borehole_code: $('bh_code').value.trim(),
      area_code: $('bh_area').value.trim(),
      ground_elevation: $('bh_elevation').value,
      total_depth: $('bh_total_depth').value,
    };

    if (mode === 'latlon') {
      payload.latitude = $('bh_lat').value;
      payload.longitude = $('bh_lon').value;
    } else {
      payload.utm_easting = $('bh_easting').value;
      payload.utm_northing = $('bh_northing').value;
      payload.utm_zone = $('bh_zone').value;
      payload.utm_hemisphere = $('bh_hemisphere').value;
    }

    const { ok, body } = await api('/api/boreholes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!ok) {
      showBanner('error', 'The borehole was not saved:', errorsOf(body));
      return;
    }

    const extra = body.latitude !== null
      ? ` Position: ${Number(body.latitude).toFixed(6)}, ${Number(body.longitude).toFixed(6)}.`
      : '';
    showBanner(body.latitude === null ? 'warn' : 'success', body.message + extra);

    this.clearForm();
    this.render(body.boreholes);
    if (this.onChange) this.onChange(body.boreholes);
  }

  async importFile(file) {
    const form = new FormData();
    form.append('file', file);
    const { ok, body } = await api('/api/boreholes/import', { method: 'POST', body: form });

    if (!ok) {
      showBanner('error', 'The coordinates were not imported:', errorsOf(body));
      return;
    }

    showBanner(body.warnings && body.warnings.length ? 'warn' : 'success',
      body.message, body.warnings || []);
    this.render(body.boreholes);
    if (this.onChange) this.onChange(body.boreholes);
  }

  async load() {
    const { ok, body } = await api('/api/boreholes');
    if (ok) {
      this.render(body.boreholes);
      return body.boreholes;
    }
    return [];
  }

  render(rows) {
    this.rows = rows || [];
    const body = $('borehole-body');
    $('borehole-empty').hidden = this.rows.length > 0;

    body.innerHTML = this.rows.map((row) => {
      const label = row.label || row.borehole_code;
      const positioned = row.has_position;
      const status = positioned
        ? '<span class="chip good-chip">on the map</span>'
        : '<span class="chip warn-chip">no coordinates</span>';
      const error = row.coordinate_error
        ? `<div class="hint">${escapeHtml(row.coordinate_error)}</div>` : '';
      return `
        <tr>
          <td><strong>${escapeHtml(row.borehole_code)}</strong></td>
          <td>${escapeHtml(row.area_code || '—')}</td>
          <td class="num">${row.latitude_resolved === null || row.latitude_resolved === undefined
              ? '—' : Number(row.latitude_resolved).toFixed(6)}</td>
          <td class="num">${row.longitude_resolved === null || row.longitude_resolved === undefined
              ? '—' : Number(row.longitude_resolved).toFixed(6)}</td>
          <td class="num">${row.sample_count ?? 0}</td>
          <td class="num">${fmt(row.average_cec)}</td>
          <td><span class="clay-dot" style="background:${escapeHtml(row.color || '#898781')}"></span>
              ${escapeHtml(row.dominant_clay || '—')}</td>
          <td>${status}${error}</td>
          <td class="actions-col">
            <span class="row-actions">
              <button type="button" class="icon-btn edit bh-edit" data-code="${escapeHtml(row.borehole_code)}"
                      data-area="${escapeHtml(row.area_code || '')}"
                      title="Edit ${escapeHtml(label)}" aria-label="Edit ${escapeHtml(label)}">&#9998;</button>
              <button type="button" class="icon-btn bh-delete" data-code="${escapeHtml(row.borehole_code)}"
                      data-area="${escapeHtml(row.area_code || '')}"
                      title="Remove ${escapeHtml(label)} from the map"
                      aria-label="Remove ${escapeHtml(label)} from the map">&#128465;</button>
            </span>
          </td>
        </tr>`;
    }).join('');

    // A hole is area + code: BH_1 in CRI1 and BH_1 in PCMI2 are two rows
    const find = (button) => this.rows.find((r) =>
      r.borehole_code === button.dataset.code && (r.area_code || '') === button.dataset.area);

    body.querySelectorAll('.bh-edit').forEach((button) => {
      button.addEventListener('click', () => {
        const row = find(button);
        if (row) this.fill(row);
      });
    });

    body.querySelectorAll('.bh-delete').forEach((button) => {
      button.addEventListener('click', () => this.remove(button.dataset.code, button.dataset.area));
    });
  }

  async remove(code, area) {
    const { ok, body } = await api(
      `/api/boreholes/${encodeURIComponent(code)}?area=${encodeURIComponent(area || '')}`,
      { method: 'DELETE' });
    if (!ok) {
      showBanner('error', 'That borehole could not be removed.', errorsOf(body));
      return;
    }
    showBanner('success', body.message);
    this.render(body.boreholes);
    if (this.onChange) this.onChange(body.boreholes);
  }
}
