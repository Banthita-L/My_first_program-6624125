/* ------------------------------------------------------------------
   strat-cards.js — every borehole's stratigraphy, one card per hole.

   Used by the Map page and the Analysis page so both look the same.
   A hole is one borehole code *in one area*: BH_1 in CRI1 and BH_1 in
   PCMI2 are different holes and are never merged. They are numbered:

       1    CRI1
       1.1    BH_1
       1.2    BH_2
       2    PCMI2
       2.1    BH_1
------------------------------------------------------------------- */

import { $, escapeHtml, fmt, svgToPng, trimNum } from './common.js';
import { drawColumn, drawStepPlot, drawClayLegend } from './strat.js';

/** Hover / focus tooltip for one SVG mark, using the page's #chart-tooltip. */
export function attachTooltip(node, html) {
  const box = $('chart-tooltip');
  if (!box) return;

  const show = (event) => {
    box.innerHTML = html;
    box.hidden = false;
    const rect = box.getBoundingClientRect();
    const anchor = node.getBoundingClientRect();
    const x = event.clientX ?? anchor.left;
    const y = event.clientY ?? anchor.top;
    box.style.left = `${Math.min(x + 14, window.innerWidth - rect.width - 8)}px`;
    box.style.top = `${Math.max(y - rect.height - 12, 8)}px`;
  };
  node.addEventListener('mouseenter', show);
  node.addEventListener('mousemove', show);
  node.addEventListener('mouseleave', () => { box.hidden = true; });
  node.addEventListener('focus', show);
  node.addEventListener('blur', () => { box.hidden = true; });
}

/** Stable id for a hole's card, so the map can scroll to it. */
export function holeId(area, code) {
  return `hole-${String(area || 'none')}-${String(code)}`.replace(/[^A-Za-z0-9_-]/g, '_');
}

/**
 * Draw every area and its holes into `slot`.
 *
 *   data      the body of GET /api/stratigraphy
 *   keep      optional (area, code) => bool, to show only some holes;
 *             the numbering is redone over what is shown
 *   onSample  called with a sample id when a block in a column is clicked
 *   details   true to add the transitions and sample tables under each hole
 *
 * Returns the number of holes drawn.
 */
export function renderStratigraphy(slot, legendSlot, data, { keep, onSample, details = false } = {}) {
  const clayColors = data.clay_colors || {};
  const clayRanges = data.clay_ranges || [];

  const areas = (data.areas || [])
    .map((area) => ({
      ...area,
      boreholes: (area.boreholes || [])
        .filter((hole) => !keep || keep(hole.area_code, hole.borehole_code)),
    }))
    .filter((area) => area.boreholes.length);

  slot.innerHTML = '';
  if (!areas.length) {
    slot.innerHTML = '<p class="chart-empty">No boreholes to draw. Samples need a borehole ' +
      'code and a depth to appear here.</p>';
    if (legendSlot) legendSlot.innerHTML = '';
    return 0;
  }

  // An outline of the numbering, so the reader can jump to any hole
  const outline = document.createElement('nav');
  outline.className = 'strat-outline';
  outline.setAttribute('aria-label', 'Boreholes by area');
  outline.innerHTML = areas.map((area, a) => `
    <div class="strat-outline-area">
      <span class="strat-num">${a + 1}</span>
      <strong>${escapeHtml(area.area_code || 'No area code')}</strong>
      ${area.boreholes.map((hole, h) => `
        <a href="#${holeId(hole.area_code, hole.borehole_code)}" class="strat-outline-hole">
          <span class="strat-num">${a + 1}.${h + 1}</span>${escapeHtml(hole.borehole_code)}
        </a>`).join('')}
    </div>`).join('');
  slot.appendChild(outline);

  const usedClays = new Set();
  let drawn = 0;

  areas.forEach((area, a) => {
    const group = document.createElement('section');
    group.className = 'strat-area';
    group.innerHTML =
      `<h3 class="strat-area-title"><span class="strat-num">${a + 1}</span>` +
      `Area ${escapeHtml(area.area_code || '(no area code)')}` +
      ` <span class="count">· ${area.boreholes.length} borehole${area.boreholes.length === 1 ? '' : 's'}</span></h3>`;
    slot.appendChild(group);

    area.boreholes.forEach((hole, h) => {
      (hole.detail.samples || []).forEach((s) =>
        (s.clay_names || []).forEach((name) => usedClays.add(name)));
      group.appendChild(holeCard(`${a + 1}.${h + 1}`, hole, { clayRanges, clayColors, onSample, details }));
      drawn += 1;
    });
  });

  if (legendSlot) {
    const codes = Object.fromEntries(clayRanges.map((range) => [range.name, range.code]));
    drawClayLegend(legendSlot, clayColors, [...usedClays].sort(), { codes });
  }
  return drawn;
}

function holeCard(number, hole, { clayRanges, clayColors, onSample, details }) {
  const { area_code: area, borehole_code: code, detail } = hole;
  const card = document.createElement('article');
  card.className = 'strat-borehole';
  card.id = holeId(area, code);
  card.dataset.borehole = code;
  card.dataset.area = area || '';

  const bits = [`${detail.sample_count} sample${detail.sample_count === 1 ? '' : 's'}`];
  if (detail.max_depth !== null && detail.max_depth !== undefined) {
    bits.push(`logged to ${trimNum(detail.max_depth)} m`);
  }
  if (detail.average_cec !== null && detail.average_cec !== undefined) {
    bits.push(`average CEC ${fmt(detail.average_cec)}`);
  }
  if (detail.dominant_clay) bits.push(`mostly ${detail.dominant_clay}`);

  const reportUrl = `/boreholes/${encodeURIComponent(code)}/report?area=${encodeURIComponent(area || '')}`;

  card.innerHTML = `
    <div class="strat-borehole-head">
      <div>
        <h4><span class="strat-num">${number}</span>${escapeHtml(code)}
            <span class="muted-cell">· ${escapeHtml(area || 'no area code')}</span></h4>
        <p class="sub">${escapeHtml(bits.join(' · '))}</p>
      </div>
      <div class="actions">
        <a class="btn btn-quiet btn-small" href="${reportUrl}" target="_blank" rel="noopener">Export report as PDF</a>
        <button type="button" class="btn btn-quiet btn-small save-png">Save strip plot as PNG</button>
      </div>
    </div>
    <div class="strat-layout">
      <figure class="strat-figure">
        <figcaption>
          <span class="chart-title">Core column</span>
          <span class="chart-sub">Coloured by type of clay mineral</span>
        </figcaption>
        <div class="chart-slot column-slot"></div>
      </figure>
      <figure class="strat-figure strat-plot">
        <figcaption>
          <span class="chart-title">Depth vs CEC</span>
          <span class="chart-sub">One point per sample; bar shows its depth interval</span>
        </figcaption>
        <div class="chart-slot step-slot"></div>
      </figure>
    </div>
    ${details ? detailTables(detail, clayColors) : ''}`;

  const scale = drawColumn(card.querySelector('.column-slot'), detail, {
    tooltip: attachTooltip,
    onSample,
  });

  drawStepPlot(card.querySelector('.step-slot'), null, [{
    borehole_code: `${area ? `${area} ` : ''}${code}`,
    steps: detail.steps,
    samples: detail.samples,
  }], {
    ranges: clayRanges,
    transitions: detail.transitions,
    tooltip: attachTooltip,
    scale,
  });

  card.querySelector('.save-png').addEventListener('click', () => {
    const svg = card.querySelector('.step-slot svg');
    if (svg) svgToPng(svg, `${area ? `${area}_` : ''}${code}_depth_vs_CEC.png`);
  });

  if (onSample) {
    card.querySelectorAll('tr[data-id]').forEach((row) => {
      row.addEventListener('click', () => onSample(Number(row.dataset.id)));
    });
  }

  return card;
}

function detailTables(detail, clayColors) {
  const transitions = detail.transitions || [];
  const samples = detail.samples || [];
  const dot = (name) =>
    `<span class="clay-dot" style="background:${escapeHtml(clayColors[(name || '').split(',')[0].trim()] || '#898781')}"></span>`;

  const transitionRows = transitions.length
    ? transitions.map((t) => `
        <tr>
          <td><strong>${escapeHtml(t.range_display)}</strong></td>
          <td class="num">${trimNum(Number(t.depth).toFixed(1))} m</td>
          <td>${dot(t.above)}${escapeHtml(t.above)}</td>
          <td>${dot(t.below)}${escapeHtml(t.below)}</td>
          <td class="muted-cell">${escapeHtml(t.above_sample)} → ${escapeHtml(t.below_sample)}</td>
        </tr>`).join('')
    : '<tr><td colspan="5">The clay mineral type is the same all the way down this borehole.</td></tr>';

  const sampleRows = samples.length
    ? samples.map((s) => `
        <tr data-id="${s.id}" style="cursor:pointer">
          <td><button type="button" class="link-btn">${escapeHtml(s.sample_name)}</button></td>
          <td class="num">${escapeHtml(s.depth_display || '—')}</td>
          <td class="num">${fmt(s.average_cec)}</td>
          <td><span class="clay-dot" style="background:${escapeHtml(s.clay_color || '#898781')}"></span>
              ${escapeHtml(s.clay_label)}</td>
        </tr>`).join('')
    : '<tr><td colspan="4">No samples in this borehole.</td></tr>';

  return `
    <details class="strat-details">
      <summary>Clay mineral transitions (${transitions.length}) and samples (${samples.length})</summary>
      <div class="table-scroll">
        <table class="sample-table">
          <thead><tr><th>Depth range (m)</th><th class="num">About</th><th>Above</th><th>Below</th><th>Between samples</th></tr></thead>
          <tbody>${transitionRows}</tbody>
        </table>
      </div>
      <div class="table-scroll">
        <table class="sample-table">
          <thead><tr><th>Sample</th><th class="num">Depth (m)</th><th class="num">CEC (meq/100 g)</th><th>Clay mineral</th></tr></thead>
          <tbody>${sampleRows}</tbody>
        </table>
      </div>
    </details>`;
}
