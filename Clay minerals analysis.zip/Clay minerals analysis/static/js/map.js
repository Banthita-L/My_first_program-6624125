/* ------------------------------------------------------------------
   map.js — Page 3: the borehole map and every borehole's stratigraphy.

   Leaflet is loaded from the project's own static/vendor folder, so the
   page works with no internet connection. Map tiles do need the internet;
   when they cannot load, the markers are still placed and the page says so.

   Below the map, every hole is drawn on its own, grouped and numbered by
   area (1 CRI1 → 1.1 BH_1, 1.2 BH_2 …). A borehole code reused in two
   areas is two holes and is never merged.
------------------------------------------------------------------- */

import { $, api, escapeHtml, fmt, showBanner, trimNum } from './common.js';
import { drawClayLegend } from './strat.js';
import { renderStratigraphy } from './strat-cards.js';
import { openSampleDetail, openZoom, wireDetailModal } from './sample-detail.js';

let map = null;
let markerLayer = null;
let boreholes = [];
let clayColors = {};
let strat = null;   // body of /api/stratigraphy

/* ---------------------------------------------------------- the map */

function cecColor(value, maxCec) {
  // One hue, light to dark: the usual way to show a magnitude
  const steps = ['#cde2fb', '#9ec5f4', '#6da7ec', '#3987e5', '#256abf', '#184f95', '#0d366b'];
  if (value === null || value === undefined) return '#898781';
  const index = Math.min(steps.length - 1,
    Math.floor((value / Math.max(maxCec, 1)) * steps.length));
  return steps[index];
}

/** The stratigraphy number of a hole, e.g. "1.2", for the marker tooltip. */
function holeNumber(area, code) {
  for (const group of (strat && strat.areas) || []) {
    for (const hole of group.boreholes || []) {
      if (hole.area_code === area && hole.borehole_code === code) return hole.number;
    }
  }
  return null;
}

/** One marker per hole: BH_1 in CRI1 and BH_1 in PCMI2 are two markers. */
function markerFor(row, maxCec) {
  const mode = $('color-mode').value;
  const color = mode === 'cec' ? cecColor(row.average_cec, maxCec) : (row.color || '#898781');
  const label = row.label || row.borehole_code;

  const icon = window.L.divIcon({
    className: 'bh-marker',
    html: `<span class="bh-dot" style="background:${escapeHtml(color)}"></span>
           <span class="bh-label">${escapeHtml(label)}</span>`,
    iconSize: [18, 18],
    iconAnchor: [9, 9],
  });

  const number = holeNumber(row.area_code || '', row.borehole_code);
  const marker = window.L.marker([row.latitude_resolved, row.longitude_resolved], { icon });
  marker.bindTooltip(
    `<strong>${number ? `${escapeHtml(number)} · ` : ''}${escapeHtml(label)}</strong><br>` +
    `${row.sample_count || 0} sample${row.sample_count === 1 ? '' : 's'}<br>` +
    `Average CEC ${fmt(row.average_cec)}<br>${escapeHtml(row.dominant_clay || '')}`,
    { direction: 'top', offset: [0, -10] }
  );
  marker.on('click', () => focusBorehole(row.borehole_code, row.area_code || ''));
  return marker;
}

function renderMap() {
  const positioned = boreholes.filter((row) => row.has_position);
  const missing = boreholes.filter((row) => !row.has_position);

  $('map-empty').hidden = positioned.length > 0;
  if (!positioned.length) {
    $('map-empty').innerHTML = boreholes.length
      ? 'None of your boreholes have coordinates yet. ' +
        '<a href="/collection?tab=boreholes">Add them in Borehole Information</a> and they will appear here. ' +
        'The stratigraphy of every borehole is shown below either way.'
      : 'No boreholes yet. <a href="/collection">Add a sample</a> to get started.';
  }

  $('map-sub').textContent = positioned.length
    ? `${positioned.length} borehole${positioned.length === 1 ? '' : 's'} on the map. Click a marker to jump to its core column.`
    : 'Nothing to show on the map yet.';

  if (missing.length) {
    showBanner('warn',
      `${missing.length} borehole${missing.length === 1 ? ' has' : 's have'} no coordinates yet.`,
      [missing.map((r) => r.label || r.borehole_code).join(', ')],
      ' <p style="margin:8px 0 0"><a href="/collection?tab=boreholes">Add their positions &rarr;</a></p>');
  }

  if (!window.L) {
    $('map').innerHTML = '<p class="chart-empty">The map library could not be loaded. ' +
      'Check that static/vendor/leaflet.js is still in the project folder.</p>';
    return;
  }

  if (!map) {
    map = window.L.map('map', { scrollWheelZoom: true });
    const street = window.L.tileLayer(
      'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      { maxZoom: 19, attribution: '&copy; OpenStreetMap contributors' }
    );
    const satellite = window.L.tileLayer(
      'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      { maxZoom: 19, attribution: 'Imagery &copy; Esri' }
    );
    street.addTo(map);
    window.L.control.layers({ 'Street map': street, 'Satellite': satellite }).addTo(map);
    map.setView([13.75, 100.5], 6);

    // Tiles need the internet; markers do not
    let failed = 0;
    street.on('tileerror', () => {
      failed += 1;
      if (failed === 4) {
        $('map-sub').textContent =
          'Map tiles could not be downloaded, so the background is blank. ' +
          'The borehole positions below are still correct.';
      }
    });
  }

  if (markerLayer) markerLayer.remove();
  markerLayer = window.L.layerGroup().addTo(map);

  const maxCec = Math.max(...positioned.map((r) => r.average_cec || 0), 1);
  positioned.forEach((row) => markerFor(row, maxCec).addTo(markerLayer));

  if (positioned.length === 1) {
    map.setView([positioned[0].latitude_resolved, positioned[0].longitude_resolved], 15);
  } else if (positioned.length > 1) {
    map.fitBounds(
      positioned.map((r) => [r.latitude_resolved, r.longitude_resolved]),
      { padding: [48, 48], maxZoom: 16 }
    );
  }

  renderMapLegend(maxCec);
  setTimeout(() => map.invalidateSize(), 60);
}

function renderMapLegend(maxCec) {
  const slot = $('map-legend');
  if ($('color-mode').value === 'cec') {
    const steps = [0, 0.2, 0.4, 0.6, 0.8].map((fraction) => ({
      label: `${trimNum((fraction * maxCec).toFixed(1))}+`,
      color: cecColor(fraction * maxCec + 0.001, maxCec),
    }));
    slot.innerHTML = '<span class="legend-title">Average CEC (meq/100 g)</span>' + steps.map((step) =>
      `<span class="legend-item"><span class="legend-swatch" style="background:${step.color}"></span>${step.label}</span>`
    ).join('');
  } else {
    const used = [...new Set(boreholes.filter((r) => r.has_position).map((r) => r.dominant_clay))];
    slot.innerHTML = '<span class="legend-title">Dominant clay mineral</span>';
    const temp = document.createElement('span');
    drawClayLegend(temp, clayColors, used);
    slot.innerHTML += temp.innerHTML;
  }
}

/* ------------------------------------------------- stratigraphy */

function buildAreaFilter() {
  const select = $('strat-area-filter');
  const current = select.value;
  const areas = (strat.areas || []).map((a) => a.area_code);
  select.innerHTML = '<option value="">All areas</option>' + areas.map((code) =>
    `<option value="${escapeHtml(code)}">${escapeHtml(code || '(no area code)')}</option>`).join('');
  if (areas.includes(current)) select.value = current;
}

function drawAllStratigraphy() {
  if (!strat) return;
  const onlyArea = $('strat-area-filter').value;
  const keep = onlyArea === '' ? null : (area) => area === onlyArea;

  const count = renderStratigraphy($('strat-groups'), $('strat-legend'), strat, {
    keep,
    onSample: openSample,
    details: true,
  });

  const areaCount = onlyArea === '' ? (strat.areas || []).length : 1;
  $('strat-sub').textContent =
    `${count} borehole${count === 1 ? '' : 's'} in ${areaCount} area${areaCount === 1 ? '' : 's'}, ` +
    'each drawn on its own. A borehole code used in two areas is two separate holes.';
}

/** Scroll to the holes with this code (one per area) and flash them. */
function focusBorehole(code, area) {
  if (area !== undefined && $('strat-area-filter').value && $('strat-area-filter').value !== area) {
    $('strat-area-filter').value = '';
    drawAllStratigraphy();
  }

  const cards = [...document.querySelectorAll('.strat-borehole')]
    .filter((card) => card.dataset.borehole === code &&
      (area === undefined || card.dataset.area === area));
  if (!cards.length) {
    showBanner('warn', `No samples with a depth for ${code} yet, so there is no column to show.`);
    return;
  }

  cards[0].scrollIntoView({ behavior: 'smooth', block: 'start' });
  cards.forEach((card) => {
    card.classList.remove('flash');
    void card.offsetWidth;   // restart the animation
    card.classList.add('flash');
  });
}

async function openSample(id) {
  if (!id) return;
  const { ok, body } = await api(`/api/samples/${id}`);
  if (ok) openSampleDetail(body, { onZoom: openZoom });
}

/* ---------------------------------------------------------- events */

$('color-mode').addEventListener('change', renderMap);
$('strat-area-filter').addEventListener('change', drawAllStratigraphy);

if (window.matchMedia) {
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    renderMap();
    drawAllStratigraphy();
  });
}

window.addEventListener('resize', () => {
  const box = $('chart-tooltip');
  if (box) box.hidden = true;
});

/* -------------------------------------------------------- start-up */

async function init() {
  wireDetailModal();

  const [mapResult, stratResult] = await Promise.all([api('/api/map'), api('/api/stratigraphy')]);

  if (!mapResult.ok) {
    showBanner('error', 'The map data could not be loaded.');
  } else {
    boreholes = mapResult.body.boreholes || [];
    clayColors = mapResult.body.clay_colors || {};
  }

  if (!stratResult.ok) {
    $('strat-groups').innerHTML = '<p class="chart-empty">The stratigraphy could not be loaded.</p>';
  } else {
    strat = stratResult.body;
    buildAreaFilter();
    drawAllStratigraphy();
  }

  if (mapResult.ok) renderMap();

  // /map?borehole=BH_1&area=CRI1 jumps straight to that hole
  const params = new URLSearchParams(window.location.search);
  const wanted = params.get('borehole');
  if (wanted) {
    const area = params.has('area') ? (params.get('area') || '').toUpperCase() : undefined;
    setTimeout(() => focusBorehole(wanted, area), 150);
  } else if (window.location.hash) {
    const target = document.getElementById(window.location.hash.slice(1));
    if (target) target.scrollIntoView();
  }
}

init();
