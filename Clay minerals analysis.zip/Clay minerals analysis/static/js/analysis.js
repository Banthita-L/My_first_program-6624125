/* ------------------------------------------------------------------
   analysis.js — Page 2: browsing and reviewing saved samples.

   Read-only by design. The only writes here are Delete (one sample, or
   every selected sample at once), which always asks for confirmation,
   and Edit, which hands the sample back to Page 1.
------------------------------------------------------------------- */

import { $, api, errorsOf, escapeHtml, fmt, showBanner } from './common.js';
import { drawCecDepth, drawClayDistribution } from './charts.js';
import { renderStratigraphy as drawStratigraphy } from './strat-cards.js';
import { openSampleDetail, closeSampleDetail, openZoom, wireDetailModal } from './sample-detail.js';

let allSamples = [];
let visibleSamples = [];
let sortKey = null;
let sortDirection = 1;
let pendingDeleteIds = [];
const selected = new Set();

// Every hole's stratigraphy, one per area + borehole (GET /api/stratigraphy)
let strat = null;

/* --------------------------------------------------------- data loading */

async function loadSamples() {
  const [samples, stratigraphy] = await Promise.all([api('/api/samples'), api('/api/stratigraphy')]);
  if (!samples.ok) {
    allSamples = [];
    showBanner('error', 'The sample list could not be loaded.', errorsOf(samples.body));
  } else {
    allSamples = samples.body;
  }
  strat = stratigraphy.ok ? stratigraphy.body : null;

  // Forget selections for samples that no longer exist
  const ids = new Set(allSamples.map((s) => s.id));
  [...selected].forEach((id) => { if (!ids.has(id)) selected.delete(id); });

  buildFilterOptions();
  applyFilters();
}

function buildFilterOptions() {
  const boreholes = [...new Set(allSamples.map((s) => s.borehole_code).filter(Boolean))].sort();
  const minerals = [...new Set(allSamples.flatMap((s) => s.clay_names || []))].sort();

  const fill = (select, values, allLabel) => {
    const current = select.value;
    select.innerHTML = `<option value="">${allLabel}</option>` +
      values.map((v) => `<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`).join('');
    if (values.includes(current)) select.value = current;
  };

  const areas = [...new Set(allSamples.map((s) => (s.area_code || '').trim().toUpperCase())
    .filter(Boolean))].sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

  fill($('borehole-filter'), boreholes, 'All boreholes');
  fill($('clay-filter'), minerals, 'All minerals');
  fill($('cec-depth-area'), areas, 'All areas');
}

/* -------------------------------------------------- filtering & sorting */

function applyFilters() {
  const query = $('search').value.trim().toLowerCase();
  const borehole = $('borehole-filter').value;
  const clay = $('clay-filter').value;

  visibleSamples = allSamples.filter((sample) => {
    if (borehole && sample.borehole_code !== borehole) return false;
    if (clay && !(sample.clay_names || []).includes(clay)) return false;
    if (!query) return true;
    return [sample.sample_name, sample.area_code, sample.borehole_code]
      .some((field) => String(field || '').toLowerCase().includes(query));
  });

  if (sortKey) {
    visibleSamples = [...visibleSamples].sort((a, b) => compare(a, b) * sortDirection);
  }

  renderTable();
  renderCharts();
  renderCount();
  renderStratigraphy();
}

function compare(a, b) {
  const left = a[sortKey];
  const right = b[sortKey];
  const leftEmpty = left === null || left === undefined || left === '';
  const rightEmpty = right === null || right === undefined || right === '';
  if (leftEmpty && rightEmpty) return 0;
  if (leftEmpty) return 1;   // blanks always sink to the bottom
  if (rightEmpty) return -1;
  if (typeof left === 'number' && typeof right === 'number') return left - right;
  return String(left).localeCompare(String(right), undefined, { numeric: true });
}

function renderCount() {
  const total = allSamples.length;
  const shown = visibleSamples.length;
  $('result-count').textContent = total === 0
    ? ''
    : shown === total
      ? `Showing all ${total} sample${total === 1 ? '' : 's'}.`
      : `Showing ${shown} of ${total} samples.`;
}

/* ------------------------------------------------------------- the table */

const COLUMN_COUNT = 9;

function renderTable() {
  const body = $('sample-body');
  body.innerHTML = '';
  $('empty-state').hidden = visibleSamples.length > 0;

  if (!visibleSamples.length) {
    $('empty-state').innerHTML = allSamples.length
      ? 'No samples match these filters. <button type="button" class="link-btn" id="inline-clear">Clear the filters</button> to see them all.'
      : 'No samples yet. <a href="/collection">Add your first sample</a>, or <a href="/collection?tab=import">import a lab file</a>.';
    const inlineClear = $('inline-clear');
    if (inlineClear) inlineClear.addEventListener('click', clearFilters);
    updateSelectionUi();
    return;
  }

  // Samples stay grouped by borehole unless an explicit sort is in force
  if (sortKey) {
    visibleSamples.forEach((sample) => body.appendChild(sampleRow(sample)));
    updateSelectionUi();
    return;
  }

  groupByBorehole(visibleSamples).forEach(({ area, code, rows }) => {
    const label = `${area || 'No area code'} · ${code || 'Unassigned'}`;
    const header = document.createElement('tr');
    header.className = 'group-row';
    header.innerHTML =
      `<td colspan="${COLUMN_COUNT}"><input type="checkbox" class="group-select" ` +
      `aria-label="Select every sample in ${escapeHtml(label)}">` +
      `${escapeHtml(label)} <span class="count">· ${rows.length} sample${rows.length === 1 ? '' : 's'}</span>` +
      (code ? ` <a class="group-link" href="/map?borehole=${encodeURIComponent(code)}` +
        `&area=${encodeURIComponent(area.toUpperCase())}">see on the map →</a>` : '') +
      '</td>';

    const box = header.querySelector('.group-select');
    box.dataset.ids = rows.map((s) => s.id).join(',');
    box.addEventListener('change', () => {
      rows.forEach((s) => (box.checked ? selected.add(s.id) : selected.delete(s.id)));
      updateSelectionUi();
    });

    body.appendChild(header);
    rows.forEach((sample) => body.appendChild(sampleRow(sample)));
  });

  updateSelectionUi();
}

/**
 * One group per borehole *within an area*. The same code can be reused in
 * different areas (BH_2 in CRI1 and BH_2 in PCMI2 are two different holes),
 * so area + borehole together identify one hole.
 */
function groupByBorehole(samples) {
  const groups = new Map();
  samples.forEach((sample) => {
    const area = (sample.area_code || '').trim();
    const code = (sample.borehole_code || '').trim();
    const key = `${area}\u0000${code}`;
    if (!groups.has(key)) groups.set(key, { area, code, rows: [] });
    groups.get(key).rows.push(sample);
  });
  const order = (text) => (text ? text : '￿');   // blanks sort last
  return [...groups.values()].sort((a, b) =>
    order(a.area).localeCompare(order(b.area), undefined, { numeric: true }) ||
    order(a.code).localeCompare(order(b.code), undefined, { numeric: true }));
}

function sampleRow(sample) {
  const row = document.createElement('tr');
  row.dataset.id = sample.id;
  const classified = sample.clay_label !== 'None-classified';
  const imported = sample.cec_imported
    ? ' <span class="chip info-chip" title="CEC imported from a lab file, not recalculated">file</span>'
    : '';

  row.innerHTML = `
    <td class="select-col"><input type="checkbox" class="row-select"
        aria-label="Select ${escapeHtml(sample.sample_name)}"></td>
    <td><button type="button" class="link-btn open-detail">${escapeHtml(sample.sample_name)}</button></td>
    <td>${escapeHtml(sample.area_code || '—')}</td>
    <td>${escapeHtml(sample.borehole_code || '—')}</td>
    <td class="num">${escapeHtml(sample.depth_display || '—')}</td>
    <td class="num">${fmt(sample.average_cec)}${imported}</td>
    <td><span class="chip${classified ? '' : ' none'}">
        <span class="clay-dot" style="background:${escapeHtml(sample.clay_color || '#898781')}"></span>
        ${escapeHtml(sample.clay_label)}</span></td>
    <td class="num">${fmt(sample.mt_resistivity)}</td>
    <td class="actions-col">
      <span class="row-actions">
        <a class="icon-btn edit" href="/collection?id=${sample.id}" title="Edit ${escapeHtml(sample.sample_name)}" aria-label="Edit ${escapeHtml(sample.sample_name)}">&#9998;</a>
        <button type="button" class="icon-btn delete" title="Delete ${escapeHtml(sample.sample_name)}" aria-label="Delete ${escapeHtml(sample.sample_name)}">&#128465;</button>
      </span>
    </td>`;

  const box = row.querySelector('.row-select');
  box.addEventListener('change', () => {
    if (box.checked) selected.add(sample.id);
    else selected.delete(sample.id);
    updateSelectionUi();
  });

  row.querySelector('.open-detail').addEventListener('click',
    () => openSampleDetail(sample, { onZoom: openZoom }));
  row.querySelector('.delete').addEventListener('click', () => askDelete([sample]));
  return row;
}

/* ------------------------------------------------------------ selection */

function updateSelectionUi() {
  // Row checkboxes and highlight
  document.querySelectorAll('#sample-body tr[data-id]').forEach((row) => {
    const on = selected.has(Number(row.dataset.id));
    row.classList.toggle('selected', on);
    row.querySelector('.row-select').checked = on;
  });

  // Borehole group checkboxes: ticked, empty, or half-ticked
  document.querySelectorAll('#sample-body .group-select').forEach((box) => {
    const ids = box.dataset.ids.split(',').map(Number);
    const count = ids.filter((id) => selected.has(id)).length;
    box.checked = count > 0 && count === ids.length;
    box.indeterminate = count > 0 && count < ids.length;
  });

  // Header "select all shown"
  const shownIds = visibleSamples.map((s) => s.id);
  const shownSelected = shownIds.filter((id) => selected.has(id)).length;
  const all = $('select-all');
  all.checked = shownIds.length > 0 && shownSelected === shownIds.length;
  all.indeterminate = shownSelected > 0 && shownSelected < shownIds.length;
  all.disabled = shownIds.length === 0;

  // Toolbar
  const total = selected.size;
  const hidden = total - shownSelected;
  const label = $('selected-count');
  label.classList.toggle('active', total > 0);
  label.textContent = total === 0
    ? 'No samples selected'
    : `${total} sample${total === 1 ? '' : 's'} selected` +
      (hidden > 0 ? ` (${hidden} hidden by the filters)` : '');

  $('delete-selected').disabled = total === 0;
  $('delete-selected').textContent = total ? `Delete selected (${total})` : 'Delete selected';
  $('clear-selection').disabled = total === 0;
  $('select-visible').disabled = shownIds.length === 0 || shownSelected === shownIds.length;
}

function selectShown(on) {
  visibleSamples.forEach((s) => (on ? selected.add(s.id) : selected.delete(s.id)));
  updateSelectionUi();
}

/* --------------------------------------------------------------- delete */

function askDelete(samples) {
  pendingDeleteIds = samples.map((s) => s.id);
  const many = samples.length > 1;

  $('confirm-title').textContent = many
    ? `Delete ${samples.length} samples?`
    : 'Delete this sample?';

  if (many) {
    const names = samples.slice(0, 8)
      .map((s) => `${s.sample_name} (${s.borehole_code || 'no borehole'})`).join(', ');
    const more = samples.length > 8 ? ` and ${samples.length - 8} more` : '';
    $('confirm-text').textContent =
      `${names}${more} will be removed permanently, with their XRD images. This cannot be undone.`;
    $('confirm-ok').textContent = `Delete ${samples.length} samples`;
  } else {
    const sample = samples[0];
    $('confirm-text').textContent =
      `“${sample.sample_name}” (${sample.borehole_code || 'no borehole'}) and its XRD image will be removed permanently.`;
    $('confirm-ok').textContent = 'Delete';
  }

  $('confirm').hidden = false;
  $('confirm-cancel').focus();
}

function askDeleteSelected() {
  const chosen = allSamples.filter((s) => selected.has(s.id));
  if (chosen.length) askDelete(chosen);
}

function cancelDelete() {
  pendingDeleteIds = [];
  $('confirm').hidden = true;
}

async function confirmDelete() {
  if (!pendingDeleteIds.length) return;
  const ids = pendingDeleteIds;
  pendingDeleteIds = [];
  $('confirm-ok').disabled = true;

  const { ok, body } = ids.length === 1
    ? await api(`/api/samples/${ids[0]}`, { method: 'DELETE' })
    : await api('/api/samples/delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids }),
    });

  $('confirm-ok').disabled = false;
  $('confirm').hidden = true;

  if (!ok) {
    showBanner('error', ids.length === 1
      ? 'That sample could not be deleted.'
      : 'The selected samples could not be deleted.', errorsOf(body));
    return;
  }

  ids.forEach((id) => selected.delete(id));
  showBanner('success', body.message || 'Sample deleted.');
  closeSampleDetail();
  await loadSamples();
}

/* --------------------------------------------------------------- charts */

function renderCharts() {
  drawCecDepth('chart-cec-depth', 'legend-cec-depth', visibleSamples,
    { area: $('cec-depth-area').value });
  drawClayDistribution('chart-clay', visibleSamples);
}

/* ------------------------------------------- stratigraphy, per borehole */

/** Draw the holes that have at least one sample showing in the table. */
function renderStratigraphy() {
  if (!strat) {
    $('strat-groups').innerHTML = '<p class="chart-empty">The stratigraphy could not be loaded.</p>';
    return;
  }
  const shown = new Set(visibleSamples.map((s) =>
    `${(s.area_code || '').trim().toUpperCase()}\u0000${(s.borehole_code || '').trim()}`));

  const byId = new Map(allSamples.map((s) => [s.id, s]));
  drawStratigraphy($('strat-groups'), $('strat-legend'), strat, {
    keep: (area, code) => shown.has(`${area}\u0000${code}`),
    onSample: (id) => {
      const sample = byId.get(id);
      if (sample) openSampleDetail(sample, { onZoom: openZoom });
    },
  });
}

/* ---------------------------------------------------------------- events */

function clearFilters() {
  $('search').value = '';
  $('borehole-filter').value = '';
  $('clay-filter').value = '';
  sortKey = null;
  updateSortIndicators();
  applyFilters();
}

function updateSortIndicators() {
  document.querySelectorAll('#sample-table th.sortable').forEach((th) => {
    const arrow = th.querySelector('.arrow');
    if (arrow) arrow.remove();
    th.removeAttribute('aria-sort');
    if (th.dataset.sort === sortKey) {
      const span = document.createElement('span');
      span.className = 'arrow';
      span.textContent = sortDirection === 1 ? '▲' : '▼';
      th.appendChild(span);
      th.setAttribute('aria-sort', sortDirection === 1 ? 'ascending' : 'descending');
    }
  });
}

document.querySelectorAll('#sample-table th.sortable').forEach((th) => {
  th.addEventListener('click', () => {
    const key = th.dataset.sort;
    if (sortKey === key) {
      sortDirection *= -1;
    } else {
      sortKey = key;
      sortDirection = 1;
    }
    updateSortIndicators();
    applyFilters();
  });
});

['search', 'borehole-filter', 'clay-filter'].forEach((id) => {
  $(id).addEventListener('input', applyFilters);
});
$('clear-filters').addEventListener('click', clearFilters);
$('cec-depth-area').addEventListener('change', renderCharts);

$('select-all').addEventListener('change', (event) => selectShown(event.target.checked));
$('select-visible').addEventListener('click', () => selectShown(true));
$('clear-selection').addEventListener('click', () => {
  selected.clear();
  updateSelectionUi();
});
$('delete-selected').addEventListener('click', askDeleteSelected);

$('confirm-cancel').addEventListener('click', cancelDelete);
$('confirm-ok').addEventListener('click', confirmDelete);

document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && !$('confirm').hidden) cancelDelete();
});

if (window.matchMedia) {
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
    renderCharts();
    renderStratigraphy();
  });
}

window.addEventListener('resize', () => { $('chart-tooltip').hidden = true; });

wireDetailModal();
loadSamples();
