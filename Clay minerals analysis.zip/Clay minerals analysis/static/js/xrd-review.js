/* ------------------------------------------------------------------
   xrd-review.js — the "read the XRD image" screen.

   Two steps, both of which the user controls:

     1. calibrate: click two points on each axis and type their values
     2. review:    the program digitises the curve, finds peaks and
                   proposes percentages; the user edits anything and accepts

   Nothing reaches the sample form until Accept is pressed, which is what the
   requirements ask for. The canvas draws the uploaded image with the
   calibration marks, the plot box, and the detected peaks on top of it.
------------------------------------------------------------------- */

import { $, $$, api, errorsOf, escapeHtml, fmt, num } from './common.js';

const STEPS = ['x1', 'x2', 'y1', 'y2'];

const STEP_HINTS = {
  x1: 'Click a point on the x axis where you know the 2θ value, then type it.',
  x2: 'Click a second point on the x axis, further along, and type its value.',
  y1: 'Click a point on the y axis where you know the intensity (the baseline, usually 0).',
  y2: 'Click a second point higher up the y axis and type its value.',
  done: 'Calibration complete. Press "Read the pattern".',
};

export class XrdReview {
  constructor({ onAccept }) {
    this.onAccept = onAccept;
    this.reset();
    this.wire();
  }

  reset() {
    this.filename = null;
    this.imageUrl = null;
    this.image = null;
    this.plotBox = null;
    this.marks = {};          // step -> {x, y} in image pixels
    this.step = 0;
    this.result = null;
    this.peaks = [];
    this.reference = [];
    this.draggingBox = null;
  }

  /* ------------------------------------------------------------ wiring */

  wire() {
    this.canvas = $('xrd-canvas');
    this.context = this.canvas.getContext('2d');

    this.canvas.addEventListener('click', (event) => this.onCanvasClick(event));

    STEPS.forEach((step) => {
      $(`cal-${step}`).addEventListener('input', () => this.updateReadyState());
    });

    $('calib-reset').addEventListener('click', () => {
      this.marks = {};
      this.step = 0;
      STEPS.forEach((step) => { $(`cal-${step}`).value = ''; });
      this.updateReadyState();
      this.draw();
    });

    $('xrd-analyse').addEventListener('click', () => this.analyse());
    $('xrd-close').addEventListener('click', () => this.close());
    $('xrd-cancel').addEventListener('click', () => this.close());
    $('xrd-accept').addEventListener('click', () => this.accept());

    $('xrd-sensitivity').addEventListener('change', () => {
      if (this.result) this.analyse();
    });
    $('xrd-wavelength').addEventListener('change', () => {
      if (this.result) this.reidentify();
    });
    $('xrd-background').addEventListener('change', () => {
      if (this.result) this.analyse();
    });

    $('ref-add').addEventListener('click', () => {
      this.reference.push({ mineral: '', d_spacing: null, two_theta: null, tolerance: 0.4, rir: 1 });
      this.renderReference();
    });
    $('ref-save').addEventListener('click', () => this.saveReference());
    $('ref-reset').addEventListener('click', () => this.resetReference());

    $('xrd-modal').addEventListener('click', (event) => {
      if (event.target === $('xrd-modal')) this.close();
    });
  }

  /* ------------------------------------------------------------- open */

  async open(file) {
    this.reset();
    $('xrd-results').hidden = true;
    $('xrd-download').hidden = true;
    $('xrd-accept').disabled = true;
    STEPS.forEach((step) => { $(`cal-${step}`).value = ''; });

    $('xrd-modal').hidden = false;
    $('xrd-step-note').textContent = 'Uploading the image…';

    const form = new FormData();
    form.append('image', file);
    const { ok, body } = await api('/api/xrd/upload', { method: 'POST', body: form });

    if (!ok) {
      $('xrd-step-note').textContent = errorsOf(body)[0];
      return;
    }

    this.filename = body.filename;
    this.imageUrl = body.url;
    this.plotBox = body.plot_box;
    this.reference = body.reference || [];
    this.renderReference();

    const image = new Image();
    image.onload = () => {
      this.image = image;
      this.layoutCanvas();
      this.draw();
      this.updateReadyState();
      $('xrd-step-note').textContent =
        'Step 1 of 2 — calibrate the axes by clicking two points on each.';
    };
    image.onerror = () => {
      $('xrd-step-note').textContent = 'That image could not be displayed.';
    };
    image.src = this.imageUrl;
  }

  close() {
    $('xrd-modal').hidden = true;
  }

  /* ----------------------------------------------------------- canvas */

  layoutCanvas() {
    const wrap = this.canvas.parentElement;
    const maxWidth = wrap.clientWidth || 560;
    this.scale = Math.min(1, maxWidth / this.image.width);
    this.canvas.width = Math.round(this.image.width * this.scale);
    this.canvas.height = Math.round(this.image.height * this.scale);
  }

  toImagePixels(event) {
    const rect = this.canvas.getBoundingClientRect();
    return {
      x: (event.clientX - rect.left) * (this.canvas.width / rect.width) / this.scale,
      y: (event.clientY - rect.top) * (this.canvas.height / rect.height) / this.scale,
    };
  }

  onCanvasClick(event) {
    if (!this.image) return;
    const point = this.toImagePixels(event);

    if (this.result) {
      this.addPeakAt(point);
      return;
    }

    if (this.step >= STEPS.length) return;
    this.marks[STEPS[this.step]] = point;
    this.step += 1;
    this.draw();
    this.updateReadyState();

    const next = STEPS[this.step];
    $('xrd-hint').textContent = next ? STEP_HINTS[next] : STEP_HINTS.done;
    const field = next ? null : $(`cal-${STEPS[this.step - 1]}`);
    if (field) field.focus();
  }

  draw() {
    if (!this.image) return;
    const ctx = this.context;
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    ctx.scale(this.scale, this.scale);
    ctx.drawImage(this.image, 0, 0);

    // The plot box the program will read inside
    if (this.plotBox) {
      const { left, top, right, bottom } = this.plotBox;
      ctx.strokeStyle = 'rgba(42, 120, 214, 0.85)';
      ctx.setLineDash([6 / this.scale, 4 / this.scale]);
      ctx.lineWidth = 1.5 / this.scale;
      ctx.strokeRect(left, top, right - left, bottom - top);
      ctx.setLineDash([]);
    }

    // Calibration marks
    const colors = { x1: '#eb6834', x2: '#eb6834', y1: '#1baf7a', y2: '#1baf7a' };
    STEPS.forEach((step, index) => {
      const mark = this.marks[step];
      if (!mark) return;
      ctx.strokeStyle = colors[step];
      ctx.fillStyle = colors[step];
      ctx.lineWidth = 1.5 / this.scale;
      const size = 9 / this.scale;
      ctx.beginPath();
      ctx.moveTo(mark.x - size, mark.y); ctx.lineTo(mark.x + size, mark.y);
      ctx.moveTo(mark.x, mark.y - size); ctx.lineTo(mark.x, mark.y + size);
      ctx.stroke();
      ctx.font = `${13 / this.scale}px system-ui, sans-serif`;
      ctx.fillText(String(index + 1), mark.x + size + 2 / this.scale, mark.y - 3 / this.scale);
    });

    // Detected peaks, once there are any
    if (this.result && this.peaks.length) {
      const cal = this.calibration();
      if (cal) {
        ctx.strokeStyle = 'rgba(227, 73, 72, 0.9)';
        ctx.fillStyle = 'rgba(227, 73, 72, 0.9)';
        ctx.lineWidth = 1.2 / this.scale;
        this.peaks.forEach((peak) => {
          const pixel = this.valueToPixelX(peak.two_theta, cal);
          if (pixel === null) return;
          ctx.beginPath();
          ctx.moveTo(pixel, this.plotBox ? this.plotBox.top : 0);
          ctx.lineTo(pixel, this.plotBox ? this.plotBox.bottom : this.image.height);
          ctx.stroke();
        });
      }
    }

    ctx.restore();
  }

  valueToPixelX(value, cal) {
    const [p0, p1] = cal.x_points;
    if (Math.abs(p1.value - p0.value) < 1e-9) return null;
    return p0.pixel + (value - p0.value) * (p1.pixel - p0.pixel) / (p1.value - p0.value);
  }

  /* ------------------------------------------------------ calibration */

  calibration() {
    const values = {};
    for (const step of STEPS) {
      const mark = this.marks[step];
      const value = num($(`cal-${step}`).value);
      if (!mark || value === null) return null;
      values[step] = { mark, value };
    }
    return {
      x_points: [
        { pixel: values.x1.mark.x, value: values.x1.value },
        { pixel: values.x2.mark.x, value: values.x2.value },
      ],
      y_points: [
        { pixel: values.y1.mark.y, value: values.y1.value },
        { pixel: values.y2.mark.y, value: values.y2.value },
      ],
    };
  }

  updateReadyState() {
    const ready = this.calibration() !== null;
    $('xrd-analyse').disabled = !ready;

    STEPS.forEach((step, index) => {
      const row = document.querySelector(`#calib-list li[data-step="${step}"]`);
      if (!row) return;
      row.classList.toggle('done', Boolean(this.marks[step]) && num($(`cal-${step}`).value) !== null);
      row.classList.toggle('current', index === this.step && !this.result);
    });

    const next = STEPS[this.step];
    $('xrd-hint').textContent = next ? STEP_HINTS[next] : STEP_HINTS.done;
  }

  /* --------------------------------------------------------- analysis */

  async analyse() {
    const calibration = this.calibration();
    if (!calibration) return;

    $('xrd-analyse').disabled = true;
    $('xrd-step-note').textContent = 'Reading the pattern…';

    const { ok, body } = await api('/api/xrd/analyse', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        filename: this.filename,
        calibration,
        plot_box: this.plotBox,
        reference: this.reference,
        wavelength: num($('xrd-wavelength').value),
        background: $('xrd-background').value,
        sensitivity: num($('xrd-sensitivity').value) / 100,
      }),
    });

    $('xrd-analyse').disabled = false;

    if (!ok) {
      $('xrd-step-note').textContent = errorsOf(body)[0];
      return;
    }

    this.result = body;
    this.peaks = body.peaks || [];
    this.plotBox = body.plot_box || this.plotBox;

    $('xrd-step-note').textContent =
      `Step 2 of 2 — ${this.peaks.length} peak${this.peaks.length === 1 ? '' : 's'} found. ` +
      `Check them, then accept.`;
    $('xrd-hint').textContent = 'Click anywhere on the image to add a peak at that 2θ.';
    $('xrd-results').hidden = false;
    $('xrd-accept').disabled = false;

    this.setupDownload(body.curve);
    this.renderPeaks();
    this.renderEstimates(body.estimates);
    $('xrd-note').textContent = body.note || '';
    this.draw();
  }

  setupDownload(curve) {
    const csv = ['two_theta_deg,intensity']
      .concat((curve || []).map(([x, y]) => `${x},${y}`))
      .join('\n');
    const link = $('xrd-download');
    if (link.dataset.url) URL.revokeObjectURL(link.dataset.url);
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    link.href = url;
    link.dataset.url = url;
    link.download = 'xrd_digitised.csv';
    link.hidden = false;
  }

  /** Re-run only the matching step, keeping the digitised curve as it is. */
  async reidentify() {
    const { ok, body } = await api('/api/xrd/reidentify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        peaks: this.peaks,
        reference: this.reference,
        wavelength: num($('xrd-wavelength').value),
      }),
    });
    if (!ok) return;
    this.peaks = body.peaks || [];
    this.renderPeaks();
    this.renderEstimates(body.estimates);
    this.draw();
  }

  addPeakAt(point) {
    const cal = this.calibration();
    if (!cal || !this.result) return;

    const [p0, p1] = cal.x_points;
    const twoTheta = p0.value + (point.x - p0.pixel) * (p1.value - p0.value) / (p1.pixel - p0.pixel);

    // Take the height from the digitised curve rather than from the click,
    // so a hand-added peak carries a real intensity.
    const curve = this.result.curve || [];
    let nearest = null;
    for (const [x, y] of curve) {
      if (!nearest || Math.abs(x - twoTheta) < Math.abs(nearest[0] - twoTheta)) nearest = [x, y];
    }

    this.peaks.push({
      two_theta: Number(twoTheta.toFixed(3)),
      intensity: nearest ? nearest[1] : 0,
      area: nearest ? nearest[1] : 0,
      edited: true,
    });
    this.peaks.sort((a, b) => a.two_theta - b.two_theta);
    this.reidentify();
  }

  renderPeaks() {
    const body = $('peak-table').querySelector('tbody');
    if (!this.peaks.length) {
      body.innerHTML = '<tr><td colspan="6">No peaks found. Lower the sensitivity, or click the image to add one.</td></tr>';
      return;
    }

    body.innerHTML = this.peaks.map((peak, index) => {
      const confidence = peak.confidence === null || peak.confidence === undefined
        ? '—' : fmt(peak.confidence, 2);
      const low = peak.confidence !== null && peak.confidence !== undefined && peak.confidence < 0.45;
      const alternatives = (peak.alternatives || []).map((a) => a.mineral);
      const ambiguous = alternatives.length
        ? `<div class="hint">could also be ${escapeHtml(alternatives.join(' or '))}</div>` : '';
      return `
        <tr${low || alternatives.length ? ' class="low-confidence"' : ''}>
          <td>${fmt(peak.two_theta, 2)}</td>
          <td>${fmt(peak.d_spacing, 3)}</td>
          <td>${fmt(peak.intensity, 1)}</td>
          <td><input type="text" class="peak-mineral" data-index="${index}"
                     value="${escapeHtml(peak.mineral || '')}" placeholder="unassigned">${ambiguous}</td>
          <td>${confidence}${low ? ' <span class="chip warn-chip">low</span>' : ''}</td>
          <td><button type="button" class="icon-btn remove-peak" data-index="${index}"
                      aria-label="Remove this peak">&times;</button></td>
        </tr>`;
    }).join('');

    body.querySelectorAll('.remove-peak').forEach((button) => {
      button.addEventListener('click', () => {
        this.peaks.splice(Number(button.dataset.index), 1);
        this.reidentify();
      });
    });

    body.querySelectorAll('.peak-mineral').forEach((input) => {
      input.addEventListener('change', () => {
        const peak = this.peaks[Number(input.dataset.index)];
        peak.mineral = input.value.trim();
        peak.mineral_locked = Boolean(peak.mineral);
        this.reidentify();
      });
    });
  }

  renderEstimates(estimates) {
    this.estimates = estimates || [];
    const body = $('estimate-table').querySelector('tbody');

    if (!this.estimates.length) {
      body.innerHTML = '<tr><td colspan="3">No peaks matched a mineral in the reference table.</td></tr>';
      $('xrd-accept').textContent = 'Accept peaks only';
      return;
    }

    $('xrd-accept').textContent = 'Accept and fill the form';
    body.innerHTML = this.estimates.map((row) => `
      <tr${row.low_confidence ? ' class="low-confidence"' : ''}>
        <td>${escapeHtml(row.mineral)}</td>
        <td><strong>${fmt(row.percent)}</strong></td>
        <td>${row.confidence === null ? '—' : fmt(row.confidence, 2)}
            ${row.low_confidence ? '<span class="chip warn-chip">low</span>' : ''}</td>
      </tr>`).join('');
  }

  /* ------------------------------------------------- reference table */

  renderReference() {
    const body = $('reference-table').querySelector('tbody');
    body.innerHTML = this.reference.map((row, index) => `
      <tr>
        <td><input type="text" data-field="mineral" data-index="${index}"
                   value="${escapeHtml(row.mineral || '')}"></td>
        <td><input type="number" step="0.01" data-field="d_spacing" data-index="${index}"
                   value="${row.d_spacing ?? ''}"></td>
        <td><input type="number" step="0.01" data-field="two_theta" data-index="${index}"
                   value="${row.two_theta ?? ''}"></td>
        <td><input type="number" step="0.05" data-field="tolerance" data-index="${index}"
                   value="${row.tolerance ?? 0.4}"></td>
        <td><input type="number" step="0.05" data-field="rir" data-index="${index}"
                   value="${row.rir ?? 1}"></td>
        <td><button type="button" class="icon-btn remove-ref" data-index="${index}"
                    aria-label="Remove this mineral">&times;</button></td>
      </tr>`).join('');

    body.querySelectorAll('input').forEach((input) => {
      input.addEventListener('change', () => {
        const row = this.reference[Number(input.dataset.index)];
        const field = input.dataset.field;
        row[field] = field === 'mineral' ? input.value.trim() : num(input.value);
      });
    });

    body.querySelectorAll('.remove-ref').forEach((button) => {
      button.addEventListener('click', () => {
        this.reference.splice(Number(button.dataset.index), 1);
        this.renderReference();
      });
    });
  }

  async saveReference() {
    const { ok, body } = await api('/api/mineral-reference', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows: this.reference }),
    });
    if (ok) {
      this.reference = body.rows || this.reference;
      this.renderReference();
      if (this.result) this.reidentify();
      $('xrd-note').textContent = 'Reference table saved.';
    } else {
      $('xrd-note').textContent = errorsOf(body)[0];
    }
  }

  async resetReference() {
    const { ok, body } = await api('/api/mineral-reference', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reset: true }),
    });
    if (ok) {
      this.reference = body.rows || [];
      this.renderReference();
      if (this.result) this.reidentify();
    }
  }

  /* ------------------------------------------------------------ accept */

  accept() {
    if (!this.result) return;
    this.onAccept({
      filename: this.filename,
      url: this.imageUrl,
      estimates: this.estimates || [],
      peaks: this.peaks,
      scan: {
        wavelength: num($('xrd-wavelength').value),
        calibration: this.calibration(),
        curve: this.result.curve,
      },
    });
    this.close();
  }
}
