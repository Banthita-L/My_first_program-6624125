/* ------------------------------------------------------------------
   strat.js — the two drawings on the Map page.

     drawColumn()   a vertical core log, coloured by clay mineral type,
                    with lithology names beside it and transition markers
     drawStepPlot() depth against CEC as a strip plot: one point per sample
                    at its mid-depth, with a bar over its depth interval

   Both share one depth scale so the two line up side by side, which is the
   whole point of putting them next to each other.
------------------------------------------------------------------- */

import { cssVar, escapeHtml, fmt, trimNum } from './common.js';

const SVG_NS = 'http://www.w3.org/2000/svg';
const SERIES_VARS = ['--series-1', '--series-2', '--series-3'];

function el(name, attrs = {}) {
  const node = document.createElementNS(SVG_NS, name);
  Object.entries(attrs).forEach(([key, value]) => node.setAttribute(key, value));
  return node;
}

function text(content, attrs) {
  const node = el('text', attrs);
  node.textContent = content;
  return node;
}

/** Round the depth range outwards to a tidy number, and never to zero height. */
function depthScale(min, max, height, top) {
  let lo = Math.min(min, 0);
  let hi = Math.max(max, lo + 1);
  const pad = (hi - lo) * 0.04;
  hi += pad;
  return (depth) => top + ((depth - lo) / (hi - lo)) * height;
}

function depthTicks(min, max) {
  const span = Math.max(max - min, 1);
  const step = span <= 6 ? 1 : span <= 15 ? 2 : span <= 40 ? 5 : 10;
  const ticks = [];
  for (let d = 0; d <= max + step; d += step) {
    if (d >= min - step) ticks.push(d);
  }
  return ticks;
}

/* ============================================ USGS clay pattern */

/*
 * Clay intervals are filled with the USGS lithologic pattern 620,
 * "Clay or clay shale" (FGDC Digital Cartographic Standard for Geologic Map
 * Symbolization, FGDC-STD-013-2006, section 37): short horizontal dashes in
 * staggered rows. The standard has one clay pattern, not one per mineral,
 * so the mineral is shown by the fill colour underneath and by its IMA
 * symbol (Kln, Sme, Ilt, Chl, Vrm; Warr 2021) printed on the block.
 */
export const CLAY_PATTERN = {
  id: 'fgdc-620',
  name: 'USGS FGDC pattern 620 — Clay or clay shale',
  width: 16,
  height: 8,
  // two staggered dashes per tile: one on the upper row, one offset below
  dashes: [[1, 2, 7, 2], [9, 6, 15, 6]],
};

let patternCounter = 0;

/** Add the 620 pattern to an SVG's <defs> and return its url() reference. */
function addClayPattern(svg) {
  const id = `${CLAY_PATTERN.id}-${++patternCounter}`;
  const defs = el('defs');
  const pattern = el('pattern', {
    id, patternUnits: 'userSpaceOnUse',
    width: CLAY_PATTERN.width, height: CLAY_PATTERN.height,
  });
  CLAY_PATTERN.dashes.forEach(([x1, y1, x2, y2]) => {
    pattern.appendChild(el('line', {
      x1, y1, x2, y2, stroke: '#1a1a19', 'stroke-width': 1.1,
      'stroke-linecap': 'butt', opacity: 0.7,
    }));
  });
  defs.appendChild(pattern);
  svg.appendChild(defs);
  return `url(#${id})`;
}

/** The same pattern as a CSS background, for legend swatches. */
export function clayPatternCss() {
  const lines = CLAY_PATTERN.dashes.map(([x1, y1, x2, y2]) =>
    `<line x1='${x1}' y1='${y1}' x2='${x2}' y2='${y2}' stroke='%231a1a19' stroke-width='1.1' opacity='0.7'/>`).join('');
  return `url("data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' width='${CLAY_PATTERN.width}' ` +
    `height='${CLAY_PATTERN.height}'>${lines}</svg>")`;
}

/** IMA mineral symbol(s) for a block: 'Kln', 'Kln, Mix', or 'n.c.' when unclassified. */
function mineralSymbol(block) {
  const label = (block.clay_label || '').trim();
  if (!label || /^none/i.test(label)) return 'n.c.';
  return label;
}

/* ================================================== the core column */

export function drawColumn(slot, detail, { onSample, tooltip } = {}) {
  const column = detail.column || {};
  const blocks = column.blocks || [];
  const beds = column.lithology || [];
  const transitions = column.transitions || [];

  slot.innerHTML = '';
  if (!blocks.length && !beds.length) {
    slot.innerHTML = '<p class="chart-empty">No sample depths recorded for this borehole.</p>';
    return null;
  }

  const hasBeds = beds.length > 0;
  const width = hasBeds ? 300 : 230;
  const margin = { top: 24, right: hasBeds ? 150 : 78, bottom: 20, left: 46 };
  const plotH = Math.max(280, Math.min(640, (blocks.length + beds.length) * 34 + 120));
  const height = plotH + margin.top + margin.bottom;

  const maxDepth = Math.max(column.depth_max || 0, detail.total_depth || 0);
  const y = depthScale(column.depth_min || 0, maxDepth, plotH, margin.top);

  const svg = el('svg', {
    viewBox: `0 0 ${width} ${height}`,
    role: 'img',
    'aria-label': `Core column for ${detail.borehole_code}, coloured by clay mineral type`,
  });

  const muted = cssVar('--text-muted');
  const grid = cssVar('--gridline');
  const surface = cssVar('--surface-1');
  const secondary = cssVar('--text-secondary');

  const barLeft = margin.left;
  const barWidth = 58;
  const bedLeft = barLeft + barWidth + 10;
  const bedWidth = hasBeds ? 26 : 0;

  // Depth axis
  depthTicks(column.depth_min || 0, maxDepth).forEach((depth) => {
    const py = y(depth);
    if (py > margin.top + plotH + 2) return;
    svg.appendChild(el('line', {
      x1: barLeft - 5, x2: barLeft, y1: py, y2: py, stroke: grid, 'stroke-width': 1,
    }));
    svg.appendChild(text(trimNum(depth), {
      x: barLeft - 9, y: py + 3.5, 'text-anchor': 'end', 'font-size': 10, fill: muted,
    }));
  });
  svg.appendChild(text('Depth (m)', {
    x: 2, y: margin.top - 10, 'text-anchor': 'start', 'font-size': 10, fill: muted,
  }));

  // Lithology beds, drawn behind the sample blocks
  beds.forEach((bed) => {
    const top = y(bed.depth_from);
    const bottom = Math.max(y(bed.depth_to), top + 2);
    svg.appendChild(el('rect', {
      x: bedLeft, y: top, width: bedWidth, height: bottom - top,
      fill: bed.color || '#c3c2b7', stroke: surface, 'stroke-width': 1,
    }));
    if (bottom - top > 11) {
      svg.appendChild(text(bed.description || '', {
        x: bedLeft + bedWidth + 7, y: (top + bottom) / 2 + 3.5,
        'font-size': 9.5, fill: secondary,
      }));
    }
  });

  // Sample intervals: mineral colour, USGS clay pattern 620 over it, IMA symbol on top
  const clayFill = addClayPattern(svg);
  let lastSideLabel = -Infinity;
  blocks.forEach((block) => {
    const top = y(block.depth_from);
    const bottom = Math.max(y(block.depth_to), top + 3);
    const symbol = mineralSymbol(block);

    const rect = el('rect', {
      x: barLeft, y: top, width: barWidth, height: bottom - top,
      fill: block.color, stroke: surface, 'stroke-width': 1,
      tabindex: 0, role: 'graphics-symbol', style: 'cursor:pointer',
      'aria-label': `${block.sample_name}, ${block.depth_display} metres, ${block.clay_label}`,
    });

    if (tooltip) {
      tooltip(rect, `<strong>${escapeHtml(block.sample_name)}</strong>` +
        `<span>${escapeHtml(block.depth_display)} m<br>` +
        `CEC ${fmt(block.average_cec)} meq/100 g<br>` +
        `${escapeHtml(block.clay_names.join(', '))}</span>`);
    }
    if (onSample) {
      rect.addEventListener('click', () => onSample(block.sample_id));
      rect.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') onSample(block.sample_id);
      });
    }
    svg.appendChild(rect);

    // The clay pattern, drawn over the colour; clicks pass through to the block
    svg.appendChild(el('rect', {
      x: barLeft, y: top, width: barWidth, height: bottom - top,
      fill: clayFill, 'pointer-events': 'none',
    }));

    // IMA mineral symbol: inside a tall block, otherwise beside it. Labels
    // that would overlap the one above are skipped; the tooltip still has it.
    const middle = (top + bottom) / 2;
    if (bottom - top >= 13) {
      const fontSize = symbol.length > 8 ? 7.5 : 8.5;
      svg.appendChild(text(symbol, {
        x: barLeft + barWidth / 2, y: middle + fontSize / 2.8,
        'text-anchor': 'middle', 'font-size': fontSize, 'font-weight': 700,
        fill: '#ffffff', stroke: '#1a1a19', 'stroke-width': 2.4,
        'paint-order': 'stroke', 'stroke-linejoin': 'round',
        'pointer-events': 'none',
      }));
    } else if (!hasBeds && middle - lastSideLabel >= 11) {
      svg.appendChild(el('line', {
        x1: barLeft + barWidth, x2: barLeft + barWidth + 5, y1: middle, y2: middle,
        stroke: secondary, 'stroke-width': 1,
      }));
      svg.appendChild(text(symbol, {
        x: barLeft + barWidth + 8, y: middle + 3.3,
        'font-size': 9, 'font-weight': 700, fill: secondary, 'pointer-events': 'none',
      }));
      lastSideLabel = middle;
    }
  });

  svg.appendChild(el('rect', {
    x: barLeft, y: margin.top, width: barWidth, height: plotH,
    fill: 'none', stroke: cssVar('--baseline'), 'stroke-width': 1,
  }));

  // Transition markers
  transitions.forEach((transition) => {
    const top = y(transition.from_depth);
    const bottom = y(transition.to_depth);

    svg.appendChild(el('rect', {
      x: barLeft - 4, y: top, width: barWidth + 8, height: Math.max(bottom - top, 1.5),
      fill: cssVar('--text-primary'), opacity: 0.12,
    }));
    svg.appendChild(el('line', {
      x1: barLeft - 4, x2: barLeft + barWidth + 4,
      y1: (top + bottom) / 2, y2: (top + bottom) / 2,
      stroke: cssVar('--critical'), 'stroke-width': 2, 'stroke-dasharray': '5 3',
    }));
  });

  slot.appendChild(svg);
  return { y, plotH, margin, maxDepth, depthMin: column.depth_min || 0 };
}

/* ================================================= the strip plot */

export function drawStepPlot(slot, legendSlot, series, options = {}) {
  const { ranges = [], transitions = [], tooltip, scale } = options;

  slot.innerHTML = '';
  if (legendSlot) legendSlot.innerHTML = '';

  const usable = (series || []).filter((s) => (s.steps || []).length);
  if (!usable.length) {
    slot.innerHTML = '<p class="chart-empty">No samples with both a depth and a CEC value.</p>';
    return;
  }

  const allSteps = usable.flatMap((s) => s.steps);
  const maxCec = Math.max(...allSteps.map((p) => p.cec), 1);
  const maxDepth = Math.max(...allSteps.map((p) => p.depth), scale ? scale.maxDepth : 0, 1);
  const minDepth = Math.min(...allSteps.map((p) => p.depth), scale ? scale.depthMin : 0);

  const width = 430;
  const margin = { top: scale ? scale.margin.top : 24, right: 16, bottom: 42, left: 52 };
  const plotH = scale ? scale.plotH : 400;
  const height = plotH + margin.top + margin.bottom;
  const plotW = width - margin.left - margin.right;

  const xMax = niceCeiling(maxCec);
  const x = (value) => margin.left + (value / xMax) * plotW;
  const y = scale ? scale.y : depthScale(minDepth, maxDepth, plotH, margin.top);

  const svg = el('svg', {
    viewBox: `0 0 ${width} ${height}`,
    role: 'img',
    'aria-label': 'Cation exchange capacity against depth, drawn as a strip plot of samples',
  });

  const grid = cssVar('--gridline');
  const muted = cssVar('--text-muted');
  const surface = cssVar('--surface-1');

  // Shaded CEC bands for each clay mineral range
  ranges.forEach((range, index) => {
    const left = x(Math.min(range.min, xMax));
    const right = x(Math.min(range.max, xMax));
    if (right <= left) return;
    svg.appendChild(el('rect', {
      x: left, y: margin.top, width: right - left, height: plotH,
      fill: range.color, opacity: 0.08,
    }));
    if (right - left > 26) {
      svg.appendChild(text(range.code, {
        x: (left + right) / 2, y: margin.top - 6, 'text-anchor': 'middle',
        'font-size': 9, fill: muted,
      }));
    }
  });

  // Grid and axes
  const xTicks = tickValues(xMax);
  xTicks.forEach((value) => {
    svg.appendChild(el('line', {
      x1: x(value), x2: x(value), y1: margin.top, y2: margin.top + plotH,
      stroke: grid, 'stroke-width': 1,
    }));
    svg.appendChild(text(String(value), {
      x: x(value), y: margin.top + plotH + 15, 'text-anchor': 'middle',
      'font-size': 10, fill: muted,
    }));
  });

  // The depth axis is always labelled, even when the core column beside it
  // carries the same scale: the plot has to stand on its own when it is
  // exported as a PNG, or when the layout stacks on a narrow screen.
  depthTicks(minDepth, maxDepth).forEach((depth) => {
    const py = y(depth);
    if (py > margin.top + plotH + 2) return;
    svg.appendChild(el('line', {
      x1: margin.left, x2: margin.left + plotW, y1: py, y2: py,
      stroke: grid, 'stroke-width': 1,
    }));
    svg.appendChild(text(trimNum(depth), {
      x: margin.left - 8, y: py + 3.5, 'text-anchor': 'end', 'font-size': 10, fill: muted,
    }));
  });

  svg.appendChild(el('line', {
    x1: margin.left, x2: margin.left, y1: margin.top, y2: margin.top + plotH,
    stroke: cssVar('--baseline'), 'stroke-width': 1,
  }));
  svg.appendChild(el('line', {
    x1: margin.left, x2: margin.left + plotW, y1: margin.top + plotH, y2: margin.top + plotH,
    stroke: cssVar('--baseline'), 'stroke-width': 1,
  }));
  svg.appendChild(text('Depth (m)', {
    x: 2, y: margin.top - 10, 'text-anchor': 'start',
    'font-size': 10, fill: muted,
  }));
  svg.appendChild(text('CEC (meq/100 g)', {
    x: margin.left + plotW / 2, y: height - 8, 'text-anchor': 'middle',
    'font-size': 10.5, fill: muted,
  }));

  // Transition markers, lined up with the column beside it
  transitions.forEach((transition) => {
    const py = y(transition.depth);
    svg.appendChild(el('line', {
      x1: margin.left, x2: margin.left + plotW, y1: py, y2: py,
      stroke: cssVar('--critical'), 'stroke-width': 1.5, 'stroke-dasharray': '5 3', opacity: 0.8,
    }));
  });

  // Strip plot: one point per sample, no line joining them. A thin bar
  // behind each point marks the depth interval the sample covers.
  usable.forEach((entry, index) => {
    const color = cssVar(SERIES_VARS[index % SERIES_VARS.length]);

    (entry.samples || []).forEach((sample) => {
      if (sample.average_cec === null || sample.average_cec === undefined) return;
      if (sample.depth_from === null || sample.depth_from === undefined) return;

      const hasBottom = sample.depth_to !== null && sample.depth_to !== undefined;
      const midDepth = hasBottom ? (sample.depth_from + sample.depth_to) / 2 : sample.depth_from;
      const cx = x(Math.min(sample.average_cec, xMax));

      if (hasBottom && sample.depth_to > sample.depth_from) {
        svg.appendChild(el('line', {
          x1: cx, x2: cx, y1: y(sample.depth_from), y2: y(sample.depth_to),
          stroke: color, 'stroke-width': 2.5, 'stroke-linecap': 'butt', opacity: 0.45,
        }));
      }

      const dot = el('circle', {
        cx, cy: y(midDepth), r: 4.5,
        fill: color, stroke: surface, 'stroke-width': 2,
        tabindex: 0, role: 'graphics-symbol',
        'aria-label': `${sample.sample_name}, ${sample.depth_display} metres, ` +
                      `${fmt(sample.average_cec)} meq per 100 grams`,
      });
      if (tooltip) {
        tooltip(dot, `<strong>${escapeHtml(sample.sample_name)}</strong>` +
          `<span>${escapeHtml(entry.borehole_code)} · ${escapeHtml(sample.depth_display)} m<br>` +
          `CEC ${fmt(sample.average_cec)} meq/100 g<br>` +
          `${escapeHtml((sample.clay_names || []).join(', '))}</span>`);
      }
      svg.appendChild(dot);
    });
  });

  slot.appendChild(svg);

  if (legendSlot && usable.length > 1) {
    legendSlot.innerHTML = usable.map((entry, index) => {
      const color = cssVar(SERIES_VARS[index % SERIES_VARS.length]);
      return `<span class="legend-item"><span class="legend-swatch" style="background:${color}"></span>` +
             `${escapeHtml(entry.borehole_code)}</span>`;
    }).join('');
  }

  return svg;
}

function niceCeiling(value) {
  if (value <= 1) return 1;
  const magnitude = Math.pow(10, Math.floor(Math.log10(value)));
  return Math.ceil(value / magnitude) * magnitude;
}

function tickValues(max) {
  const count = 5;
  const raw = max / count;
  const magnitude = Math.pow(10, Math.floor(Math.log10(raw)));
  const step = [1, 2, 2.5, 5, 10].map((m) => m * magnitude).find((s) => s >= raw) || magnitude * 10;
  const ticks = [];
  for (let value = 0; value <= max + step / 1000; value += step) {
    ticks.push(Number(value.toFixed(10)));
  }
  return ticks;
}

/* ============================================ the clay colour legend */

/**
 * Legend of clay minerals.
 *
 * With `codes` ({name: 'Kln', ...}) each entry also shows its IMA symbol and a
 * swatch carrying the USGS 620 clay pattern, matching the core column.
 */
export function drawClayLegend(slot, colors, used, { codes = null } = {}) {
  const names = used && used.length ? used : Object.keys(colors || {});
  const pattern = codes ? clayPatternCss() : null;

  const items = names.map((name) => {
    const color = (colors || {})[name] || '#898781';
    // escaped as a whole: the data URI holds quotes and angle brackets
    const background = escapeHtml(pattern ? `${pattern}, ${color}` : color);
    const code = codes ? (codes[name] || (/^none/i.test(name) ? 'n.c.' : '')) : '';
    return `<span class="legend-item"><span class="legend-swatch${pattern ? ' patterned' : ''}" ` +
      `style="background:${background}"></span>${escapeHtml(name)}` +
      `${code ? ` <strong class="legend-code">${escapeHtml(code)}</strong>` : ''}</span>`;
  }).join('');

  slot.innerHTML = items + (pattern
    ? `<span class="legend-note">Fill: ${escapeHtml(CLAY_PATTERN.name)} (FGDC-STD-013-2006). ` +
      'Symbols: IMA mineral abbreviations (Warr 2021); Mix = mixed-layer, n.c. = not classified.</span>'
    : '');
}
