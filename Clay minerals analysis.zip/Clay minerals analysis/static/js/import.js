/* ------------------------------------------------------------------
   import.js — the bulk import screen.

   Upload, inspect, fix the column mapping if needed, review every row,
   then commit. The server never saves anything during inspection, so the
   user can change their mind at any point before pressing Import.
------------------------------------------------------------------- */

import { $, api, errorsOf, escapeHtml, fmt, showBanner } from './common.js';

export class BulkImport {
  constructor({ onImported, fields }) {
    this.onImported = onImported;
    this.fields = fields || [];
    this.file = null;
    this.preview = null;
    this.overrides = {};
    this.wire();
  }

  wire() {
    const zone = $('dropzone');
    const input = $('import-file');

    zone.addEventListener('click', (event) => {
      if (event.target.tagName !== 'INPUT') input.click();
    });
    zone.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        input.click();
      }
    });

    ['dragenter', 'dragover'].forEach((name) => {
      zone.addEventListener(name, (event) => {
        event.preventDefault();
        zone.classList.add('dragging');
      });
    });
    ['dragleave', 'drop'].forEach((name) => {
      zone.addEventListener(name, (event) => {
        event.preventDefault();
        zone.classList.remove('dragging');
      });
    });
    zone.addEventListener('drop', (event) => {
      const file = event.dataTransfer.files[0];
      if (file) this.load(file);
    });

    input.addEventListener('change', (event) => {
      const file = event.target.files[0];
      if (file) this.load(file);
    });

    $('sheet-select').addEventListener('change', () => this.inspect());
    $('remap-btn').addEventListener('click', () => {
      this.overrides = this.readMapping();
      this.inspect();
    });
    $('check-all').addEventListener('change', (event) => {
      const checked = event.target.checked;
      $('preview-body').querySelectorAll('.row-check').forEach((box) => {
        if (!box.disabled) box.checked = checked;
      });
      this.syncActions();
    });
    $('apply-area').addEventListener('click', () => this.inspect());
    $('default-area').addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        this.inspect();
      }
    });
    $('import-btn').addEventListener('click', () => this.commit());
    $('cancel-import').addEventListener('click', () => this.clear());
  }

  clear() {
    this.file = null;
    this.preview = null;
    this.overrides = {};
    $('import-file').value = '';
    $('default-area').value = '';
    $('import-filename').textContent = 'No file chosen yet.';
    $('sheet-picker').hidden = true;
    $('mapping-card').hidden = true;
    $('preview-card').hidden = true;
  }

  async load(file) {
    this.file = file;
    this.overrides = {};
    $('default-area').value = '';
    $('import-filename').textContent = file.name;

    if (/\.(xlsx|xlsm|xls)$/i.test(file.name)) {
      const form = new FormData();
      form.append('file', file);
      const { ok, body } = await api('/api/import/sheets', { method: 'POST', body: form });
      const sheets = (ok && body.sheets) || [];
      if (sheets.length > 1) {
        $('sheet-select').innerHTML = sheets
          .map((name) => `<option value="${escapeHtml(name)}">${escapeHtml(name)}</option>`)
          .join('');
        $('sheet-picker').hidden = false;
      } else {
        $('sheet-picker').hidden = true;
      }
    } else {
      $('sheet-picker').hidden = true;
    }

    this.inspect();
  }

  async inspect() {
    if (!this.file) return;

    $('import-filename').textContent = `${this.file.name} — reading…`;

    const form = new FormData();
    form.append('file', this.file);
    if (!$('sheet-picker').hidden) form.append('sheet', $('sheet-select').value);
    if (Object.keys(this.overrides).length) {
      form.append('mapping', JSON.stringify(this.overrides));
    }
    const typedArea = $('default-area').value.trim();
    if (typedArea) form.append('default_area', typedArea);

    const { ok, body } = await api('/api/import/inspect', { method: 'POST', body: form });
    $('import-filename').textContent = this.file.name;

    if (!ok) {
      showBanner('error', 'That file could not be read:', errorsOf(body));
      $('preview-card').hidden = true;
      $('mapping-card').hidden = true;
      return;
    }

    this.preview = body;
    this.renderMapping();
    this.renderPreview();
  }

  /* ------------------------------------------------------- mapping UI */

  renderMapping() {
    const headers = this.preview.header_row || [];
    const mapping = this.preview.mapping || {};
    const grid = $('mapping-grid');

    grid.innerHTML = this.fields.map(({ field, label }) => {
      const selected = mapping[field];
      const options = ['<option value="">(not in this file)</option>'].concat(
        headers.map((header, index) => {
          const text = header || `Column ${index + 1}`;
          const isOn = selected === index ? ' selected' : '';
          return `<option value="${index}"${isOn}>${escapeHtml(text)}</option>`;
        })
      ).join('');
      return `
        <label class="field">
          <span class="label">${escapeHtml(label)}</span>
          <select data-field="${field}">${options}</select>
        </label>`;
    }).join('');

    // Only push the mapping screen in front of the user when it is needed
    $('mapping-card').hidden = !this.preview.needs_mapping;
    if (this.preview.needs_mapping) {
      showBanner('warn', 'Some columns could not be matched automatically.',
        ['Please pick the right column for each field below, then press Apply mapping.']);
    }
  }

  readMapping() {
    const overrides = {};
    $('mapping-grid').querySelectorAll('select').forEach((select) => {
      overrides[select.dataset.field] = select.value === '' ? null : Number(select.value);
    });
    return overrides;
  }

  /* ------------------------------------------------------- preview UI */

  renderPreview() {
    const { rows, summary, warnings } = this.preview;

    $('preview-card').hidden = false;
    const areas = summary.areas || [];
    $('import-summary').textContent =
      `${summary.row_count} row${summary.row_count === 1 ? '' : 's'} found in ` +
      `${summary.borehole_count} borehole${summary.borehole_count === 1 ? '' : 's'}` +
      (areas.length ? ` across ${areas.length} area${areas.length === 1 ? '' : 's'}` : '') +
      (summary.error_count ? `, ${summary.error_count} with errors` : '') +
      (summary.warning_count ? `, ${summary.warning_count} with warnings` : '') + '.';

    // Which area codes were read, and from where
    const missing = summary.rows_without_area || 0;
    $('area-found').innerHTML =
      (areas.length
        ? `Area code${areas.length === 1 ? '' : 's'} read: ` +
          areas.map((a) => `<span class="chip">${escapeHtml(a)}</span>`).join('')
        : '<span class="area-missing">No area code found in this file.</span>') +
      (missing && areas.length
        ? ` <span class="area-missing">· ${missing} row${missing === 1 ? '' : 's'} without one</span>`
        : '');

    const notes = [...(warnings || [])];
    if (summary.imported_cec_count) {
      notes.push(
        `${summary.imported_cec_count} row${summary.imported_cec_count === 1 ? ' has' : 's have'} ` +
        `no W_clay or W_MeB, so the CEC from the file will be kept and marked ` +
        `"imported, not recalculated". You can add the weights later to recalculate.`
      );
    }
    $('import-warnings').innerHTML = notes.length
      ? `<div class="banner warn" style="margin-bottom:14px"><ul>${
          notes.map((n) => `<li>${escapeHtml(n)}</li>`).join('')}</ul></div>`
      : '';

    $('duplicate-picker').hidden = summary.duplicate_count === 0;
    if (summary.duplicate_count) {
      $('duplicate-picker').querySelector('.label').textContent =
        `${summary.duplicate_count} sample${summary.duplicate_count === 1 ? '' : 's'} already saved`;
    }

    $('preview-body').innerHTML = rows.map((row, index) => {
      const level = worstLevel(row.issues);
      const notesHtml = row.issues.map((issue) =>
        `<span class="issue ${issue.level}">${escapeHtml(issue.message)}</span>`).join('');
      const blocked = row.action === 'skip';
      return `
        <tr class="preview-row ${level}">
          <td><input type="checkbox" class="row-check" data-index="${index}"
                     ${blocked ? 'disabled' : 'checked'} aria-label="Include row ${row.row_number}"></td>
          <td class="num muted-cell">${row.row_number}</td>
          <td>${row.area_code
            ? `${escapeHtml(row.area_code)}${AREA_SOURCE[row.area_source]
              ? `<span class="area-source">${AREA_SOURCE[row.area_source]}</span>` : ''}`
            : '<span class="area-missing">none</span>'}</td>
          <td>${escapeHtml(row.borehole_code || '—')}</td>
          <td><strong>${escapeHtml(row.sample_name || '(no name)')}</strong></td>
          <td class="num">${escapeHtml(row.depth_display || '—')}</td>
          <td class="num">${fmt(row.v_meb)}</td>
          <td class="num">${fmt(row.cec)}</td>
          <td>${escapeHtml(row.clay_label || '—')}</td>
          <td class="issue-cell">${notesHtml || '<span class="hint">ok</span>'}</td>
        </tr>`;
    }).join('');

    $('preview-body').querySelectorAll('.row-check').forEach((box) => {
      box.addEventListener('change', () => this.syncActions());
    });
    this.syncActions();
  }

  syncActions() {
    const boxes = [...$('preview-body').querySelectorAll('.row-check')];
    const chosen = boxes.filter((box) => box.checked && !box.disabled).length;
    $('import-btn').disabled = chosen === 0;
    $('import-btn').textContent = chosen
      ? `Import ${chosen} sample${chosen === 1 ? '' : 's'}`
      : 'Nothing selected';
  }

  /* ---------------------------------------------------------- commit */

  async commit() {
    const boxes = [...$('preview-body').querySelectorAll('.row-check')];
    const rows = this.preview.rows.map((row, index) => ({
      ...row,
      action: boxes[index] && boxes[index].checked && !boxes[index].disabled ? 'import' : 'skip',
    }));

    $('import-btn').disabled = true;
    $('import-btn').textContent = 'Importing…';

    const { ok, body } = await api('/api/import/commit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows, duplicate_policy: $('duplicate-policy').value }),
    });

    $('import-btn').disabled = false;
    this.syncActions();

    if (!ok) {
      showBanner('error', 'The import failed:', errorsOf(body));
      return;
    }

    showBanner(body.warnings && body.warnings.length ? 'warn' : 'success',
      body.message, body.warnings || [],
      ' <p style="margin:8px 0 0"><a href="/analysis">See them on the Analysis page &rarr;</a> ' +
      '&middot; <a href="/map">Open the map &rarr;</a></p>');

    this.clear();
    if (this.onImported) this.onImported(body);
  }
}

// Shown under the area code so the user can see where it was read from
const AREA_SOURCE = {
  column: 'from column',
  sheet: 'from sheet name',
  typed: 'typed in',
};

function worstLevel(issues) {
  if (issues.some((i) => i.level === 'error')) return 'error';
  if (issues.some((i) => i.level === 'warn')) return 'warn';
  if (issues.some((i) => i.level === 'info')) return 'info';
  return '';
}
