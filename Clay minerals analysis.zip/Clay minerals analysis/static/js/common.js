/* ------------------------------------------------------------------
   common.js — small helpers shared by every page.
------------------------------------------------------------------- */

export const $ = (id) => document.getElementById(id);
export const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

export function escapeHtml(text) {
  return String(text ?? '').replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
  ));
}

export function num(value) {
  if (value === null || value === undefined) return null;
  const text = String(value).trim();
  if (text === '') return null;
  const parsed = Number(text);
  return Number.isFinite(parsed) ? parsed : null;
}

/** Fixed decimals, or an em-dash when there is nothing to show. */
export function fmt(value, digits = 2) {
  return value === null || value === undefined ? '—' : Number(value).toFixed(digits);
}

/** Trim trailing zeros: 0.9000 becomes 0.9, 2.0 becomes 2. */
export function trimNum(value) {
  if (value === null || value === undefined || value === '') return '';
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) return '';
  return String(Number(parsed.toFixed(4)));
}

export function depthText(from, to) {
  if (from === null && to === null) return '—';
  if (to === null || to === undefined) return `${trimNum(from)}`;
  if (from === null || from === undefined) return `${trimNum(to)}`;
  return `${trimNum(from)} – ${trimNum(to)}`;
}

/* ------------------------------------------------------------- banner */

let bannerTimer = null;

export function showBanner(kind, title, items = [], extraHtml = '') {
  const banner = $('banner');
  if (!banner) return;

  clearTimeout(bannerTimer);
  banner.className = `banner ${kind}`;
  const list = items && items.length
    ? `<ul>${items.map((i) => `<li>${escapeHtml(i)}</li>`).join('')}</ul>`
    : '';
  banner.innerHTML = `<strong>${escapeHtml(title)}</strong>${list}${extraHtml}`;
  banner.hidden = false;
  window.scrollTo({ top: 0, behavior: 'smooth' });

  if (kind === 'success') {
    bannerTimer = setTimeout(() => { banner.hidden = true; }, 7000);
  }
}

export function hideBanner() {
  const banner = $('banner');
  if (banner) banner.hidden = true;
}

/* --------------------------------------------------------------- fetch */

/**
 * Call the app's own API and always come back with a usable object.
 *
 * A network failure is turned into the same shape as a validation failure,
 * so callers never have to tell the two apart.
 */
export async function api(url, options = {}) {
  try {
    const response = await fetch(url, options);
    const text = await response.text();
    let body = {};
    if (text) {
      try {
        body = JSON.parse(text);
      } catch (error) {
        body = { errors: ['The server sent back something unexpected.'] };
      }
    }
    return { ok: response.ok, status: response.status, body };
  } catch (error) {
    return {
      ok: false,
      status: 0,
      body: { errors: ['Could not reach the program. Check that it is still running in the terminal.'] },
    };
  }
}

export function errorsOf(body, fallback = 'Something went wrong.') {
  if (!body) return [fallback];
  if (Array.isArray(body.errors) && body.errors.length) return body.errors;
  if (body.error) return [body.error];
  return [fallback];
}

/* --------------------------------------------------------------- misc */

export function cssVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

export function debounce(fn, wait = 200) {
  let timer = null;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn(...args), wait);
  };
}

/** Download a blob the browser already has in memory. */
export function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/** Turn an inline SVG element into a PNG the user can save. */
export function svgToPng(svg, filename, scale = 2) {
  const clone = svg.cloneNode(true);
  const box = svg.getBoundingClientRect();
  const width = Math.max(box.width, 320);
  const height = Math.max(box.height, 240);

  clone.setAttribute('width', width);
  clone.setAttribute('height', height);
  clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');

  // The PNG leaves the page, so the theme colours must be baked in
  const background = cssVar('--surface-1') || '#ffffff';
  const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
  rect.setAttribute('width', '100%');
  rect.setAttribute('height', '100%');
  rect.setAttribute('fill', background);
  clone.insertBefore(rect, clone.firstChild);

  const source = new XMLSerializer().serializeToString(clone);
  const image = new Image();
  image.onload = () => {
    const canvas = document.createElement('canvas');
    canvas.width = width * scale;
    canvas.height = height * scale;
    const context = canvas.getContext('2d');
    context.scale(scale, scale);
    context.drawImage(image, 0, 0);
    canvas.toBlob((blob) => blob && downloadBlob(blob, filename), 'image/png');
  };
  image.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(source);
}
